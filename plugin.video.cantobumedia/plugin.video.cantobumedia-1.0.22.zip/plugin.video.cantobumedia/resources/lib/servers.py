# -*- coding: utf-8 -*-
import urllib,urllib2,urlfetch, re, os, json, requests
from time import sleep
from utils import *
from urlfetch import get,post

import random
import xbmc, xbmcaddon
					
def gibberishAES(string, key=''):
	import ctypes
	def aa(l,s=4):
		a=[]
		for i in range(0,len(l),s):a.append((l[i:i+s]))
		return a

	def j2p(v):return ctypes.c_int(v).value
	def rshift(val, n): return (val % 0x100000000) >> n

	e = 14
	r = 8
	n = False
		
	def f(e):
		#try:result=urllib.quote(e)
		#except:result=str(e)
		return str(e)
		
	def c(e):
		#try:result=urllib.quote(e, safe='~()*!.\'')
		#except:result=str(e)
		return str(e)

	def t(e):
		f = [0]*len(e)
		if 16 >len(e):
			r = 16 - len(e)
			f = [r, r, r, r, r, r, r, r, r, r, r, r, r, r, r, r]
		for n in range(len(e)):f[n] = e[n]
		return f

	def o(e):
		n = ""
		for r in len(e):n += ("0" if 16 > e[r] else "") + format(e[r], 'x')
		return n

	def u(e, r):
		c = []
		if not r:e=f(e)
		for n in range(len(e)):c.append(ord(e[n]))
		return c

	def i(n):
		if n==128:e = 10; r = 4
		elif n==192:e = 12;r = 6
		elif n==256:e = 14;r = 8

	def b(e):
		n = []
		for r in range(e):n.append(256)
		return n

	def h(n, f):
		d=[];t= 3 if e >= 12 else 2; i = n + f; d.append(L(i));u=[c for c in d[0]]
		for c in range(1,t):d.append(L(d[c - 1] + i));u+=d[c]
		return {'key': u[0 : 4 * r],'iv': u[4 * r : 4 * r + 16]}

	def a1(e, r=False):
		c = ""
		if (r):
			n = e[15]
			#if n > 16:print "Decryption error: Maybe bad key"
			if 16 != n:
				for f in range(16 - n):c += chr(e[f])
		else:
			for f in range(16):c += chr(e[f])
		return c

	def a(e, r=False):
		if not r:c=''.join(chr(e[f])for f in range(16))
		elif 16!=e[15]:c=''.join(chr(e[f]) for f in range(16-e[15]))
		else:c=''
		return c

	def v(e, r, n, f=''):
		r = S(r); o = len(e) / 16; u = [0]*o
		d=[e[16 * t: 16 * (t + 1)] for t in range(o)]
		for t in range(len(d) - 1,-1,-1):
			u[t] = p(d[t], r)
			u[t] = x(u[t], n) if 0 == t else x(u[t], d[t - 1])
		
		i=''.join(a(u[t]) for t in range(o-1))
		i += a(u[o-1], True)
		return i if f else c(i)

	def s(r, f):
		n = False
		t = M(r, f, 0)
		for c in (1, e + 1 ,1):
			t = g(t)
			t = y(t)
			if e > c:t = k(t)
			t = M(t, f, c)
		return t

	def p(r, f):
		n = True
		t = M(r, f, e)
		for c in range(e - 1,-1,-1):
			t = y(t,n)
			t = g(t,n)
			t = M(t, f, c)
			if c > 0 : t = k(t,n)
		return t

	def g(e,n=True):#OK
		f = D if n else B; c = [0]*16
		for r in range(16):c[r] = f[e[r]]
		return c

	def y(e,n=True):
		f = []
		if n: c = [0, 13, 10, 7, 4, 1, 14, 11, 8, 5, 2, 15, 12, 9, 6, 3] 
		else:c =[0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
		for r in range(16):f.append(e[c[r]])
		return f

	def k(e,n=True):
		f = [0]*16
		if (n):
			for r in range(4):
				f[4 * r] = F[e[4 * r]] ^ R[e[1 + 4 * r]] ^ j[e[2 + 4 * r]] ^ z[e[3 + 4 * r]]
				f[1 + 4 * r] = z[e[4 * r]] ^ F[e[1 + 4 * r]] ^ R[e[2 + 4 * r]] ^ j[e[3 + 4 * r]]
				f[2 + 4 * r] = j[e[4 * r]] ^ z[e[1 + 4 * r]] ^ F[e[2 + 4 * r]] ^ R[e[3 + 4 * r]]
				f[3 + 4 * r] = R[e[4 * r]] ^ j[e[1 + 4 * r]] ^ z[e[2 + 4 * r]] ^ F[e[3 + 4 * r]]
		else:
			for r in range(4):
				f[4 * r] = E[e[4 * r]] ^ U[e[1 + 4 * r]] ^ e[2 + 4 * r] ^ e[3 + 4 * r]
				f[1 + 4 * r] = e[4 * r] ^ E[e[1 + 4 * r]] ^ U[e[2 + 4 * r]] ^ e[3 + 4 * r]
				f[2 + 4 * r] = e[4 * r] ^ e[1 + 4 * r] ^ E[e[2 + 4 * r]] ^ U[e[3 + 4 * r]]
				f[3 + 4 * r] = U[e[4 * r]] ^ e[1 + 4 * r] ^ e[2 + 4 * r] ^ E[e[3 + 4 * r]]
		return f	

	def M(e, r, n):#OK
		c = [0]*16
		for f in range(16):c[f] = e[f] ^ r[n][f]
		return c

	def x(e, r):
		f = [0]*16
		for n in  range(16):f[n] = e[n] ^ r[n]
		return f

	def S(n):#r=8;e=14
		o=[[n[4 * f + i] for i in range(4)] for f in range(r)]
		
		for f in range(r,4 * (e + 1)):
			d=[t for t in o[f-1]]
			if 0 == f % r:d = m(w(d)); d[0] ^= K[f / r - 1]
			elif r > 6 and 4 == f % r : d = m(d)
			o.append([o[f - r][t] ^ d[t] for t in range(4)])
		
		u = []
		for f in range(e + 1):
			u.append([])
			for a in range(4):u[f]+=o[4 * f + a]
		return u

	def m(e):
		return [B[e[r]] for r in range(4)]

	def w(e):
		e.insert(4,e[0])
		e.remove(e[4])
		return e

	def A(e, r):return [int(e[n:n+r], 16) for n in range(0,len(e),r)]

	def C(e):
		n=[0]*len(e)
		for r in range(len(e)):n[e[r]] = r
		return n

	def I(e, r):
		f=0
		for n in range(8):
			f = f ^ e if 1 == (1 & r) else f
			e = j2p(283 ^ e << 1) if e > 127 else j2p(e << 1)
			r >>= 1
		return f

	def O(e):
		n = [0]*256
		for r in range(256):n[r] = I(e, r)
		return n

	B = A("637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16", 2)
	D = C(B)
	K = A("01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591", 2)
	E = O(2)
	U = O(3)
	z = O(9)
	R = O(11)
	j = O(13)
	F = O(14)

	def G(e, r, n):
		c = b(8); t = h(u(r, n), c); a = t.key; o = t.iv; d = [83, 97, 108, 116, 101, 100, 95, 95]+c
		e = u(e, n)
		f = l(e, a, o)
		f = d+f
		return T.encode(f)

	def H(e, r, n=''):
		f = decode(e)
		c = f[8 : 16]
		t = h(u(r, n), c)
		a = t['key']
		o = t['iv']
		f = f[16 : len(f)]
		return v(f, a, o, n)

	def decode(r):#OK
		def indexOfchar(n):
			try:a=e.index(r[n])
			except:a=-1
			return a
		
		e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
		r=r.replace('\n','');f=[];c=[0]*4
		for n in range(0,len(r),4):
			for i in range(len(c)):c[i]=indexOfchar(n+i)
			f.append(j2p(c[0]<<2|c[1]>>4))
			f.append(j2p((15&c[1])<<4|c[2]>>2))
			f.append(j2p((3&c[2])<<6|c[3]))
		return f[0:len(f)-len(f)%16]

	def L(e):
		def r(e, r):return j2p(e << r) | j2p(rshift(e, 32-r))

		def n(e, r):
			c = 2147483648 & e
			t = 2147483648 & r
			n = 1073741824 & e
			f = 1073741824 & r
			a = (1073741823 & e) + (1073741823 & r)
			i = 2147483648^a^c^t
			j = 3221225472^a^c^t
			k = 1073741824^a^c^t
			return j2p(i if n & f else ((j if 1073741824 & a else k) if n | f else a^c^t))		

		def f(e, r, n):return j2p(e & r) | j2p(~e & n)

		def c(e, r, n):return j2p(e & n) | j2p(r & ~n)

		def t(e, r, n):return e ^ r ^ n

		def a(e, r, n):return r ^ (e | ~n)

		def o(e, c, t, a, o, d, u):
			e = n(e, n(n(f(c, t, a), o), u))
			return n(r(e, d), c)

		def d(e, f, t, a, o, d, u):
			e = n(e, n(n(c(f, t, a), o), u))
			return n(r(e, d), f)

		def u(e, f, c, a, o, d, u):
				e = n(e, n(n(t(f, c, a), o), u))
				return n(r(e, d), f)

		def i(e, f, c, t, o, d, u):
			e = n(e, n(n(a(f, c, t), o), u))
			return n(r(e, d), f)

		def b(e):
			n=len(e); f = n + 8; c = (f - f % 64) / 64; t = 16 * (c + 1); a = [0]*t; o = 0
			for d in range(n):r = (d - d % 4) / 4; o = 8 * (d % 4);	a[r] = a[r] | j2p(e[d] << o)
			d+=1
			r = (d - d % 4) / 4
			o = 8 * (d % 4)
			a[r] = a[r] | j2p(128 << o)
			a[t - 2] = j2p(n << 3)
			a[t - 1] = j2p(rshift(n,29))
			return a

		def h(e):
			f = []
			for n in range(4):
				r = j2p(255 & rshift(e, 8 * n))
				f.append(r)
			return f

		m = A("67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391", 8)
		S = [];  S = b(e); y = m[0]; k = m[1]; M = m[2]; x = m[3]; l = 0
		for l in range(0,len(S),16):
			v = y
			s = k
			p = M
			g = x
			y = o(y, k, M, x, S[l + 0], 7, m[4])
			x = o(x, y, k, M, S[l + 1], 12, m[5])
			M = o(M, x, y, k, S[l + 2], 17, m[6])
			k = o(k, M, x, y, S[l + 3], 22, m[7])
			y = o(y, k, M, x, S[l + 4], 7, m[8])
			x = o(x, y, k, M, S[l + 5], 12, m[9])
			M = o(M, x, y, k, S[l + 6], 17, m[10])
			k = o(k, M, x, y, S[l + 7], 22, m[11])
			y = o(y, k, M, x, S[l + 8], 7, m[12])
			x = o(x, y, k, M, S[l + 9], 12, m[13])
			M = o(M, x, y, k, S[l + 10], 17, m[14])
			k = o(k, M, x, y, S[l + 11], 22, m[15])
			y = o(y, k, M, x, S[l + 12], 7, m[16])
			x = o(x, y, k, M, S[l + 13], 12, m[17])
			M = o(M, x, y, k, S[l + 14], 17, m[18])
			k = o(k, M, x, y, S[l + 15], 22, m[19])
			y = d(y, k, M, x, S[l + 1], 5, m[20])
			x = d(x, y, k, M, S[l + 6], 9, m[21])
			M = d(M, x, y, k, S[l + 11], 14, m[22])
			k = d(k, M, x, y, S[l + 0], 20, m[23])
			y = d(y, k, M, x, S[l + 5], 5, m[24])
			x = d(x, y, k, M, S[l + 10], 9, m[25])
			M = d(M, x, y, k, S[l + 15], 14, m[26])
			k = d(k, M, x, y, S[l + 4], 20, m[27])
			y = d(y, k, M, x, S[l + 9], 5, m[28])
			x = d(x, y, k, M, S[l + 14], 9, m[29])
			M = d(M, x, y, k, S[l + 3], 14, m[30])
			k = d(k, M, x, y, S[l + 8], 20, m[31])
			y = d(y, k, M, x, S[l + 13], 5, m[32])
			x = d(x, y, k, M, S[l + 2], 9, m[33])
			M = d(M, x, y, k, S[l + 7], 14, m[34])
			k = d(k, M, x, y, S[l + 12], 20, m[35])
			y = u(y, k, M, x, S[l + 5], 4, m[36])
			x = u(x, y, k, M, S[l + 8], 11, m[37])
			M = u(M, x, y, k, S[l + 11], 16, m[38])
			k = u(k, M, x, y, S[l + 14], 23, m[39])
			y = u(y, k, M, x, S[l + 1], 4, m[40])
			x = u(x, y, k, M, S[l + 4], 11, m[41])
			M = u(M, x, y, k, S[l + 7], 16, m[42])
			k = u(k, M, x, y, S[l + 10], 23, m[43])
			y = u(y, k, M, x, S[l + 13], 4, m[44])
			x = u(x, y, k, M, S[l + 0], 11, m[45])
			M = u(M, x, y, k, S[l + 3], 16, m[46])
			k = u(k, M, x, y, S[l + 6], 23, m[47])
			y = u(y, k, M, x, S[l + 9], 4, m[48])
			x = u(x, y, k, M, S[l + 12], 11, m[49])
			M = u(M, x, y, k, S[l + 15], 16, m[50])
			k = u(k, M, x, y, S[l + 2], 23, m[51])
			y = i(y, k, M, x, S[l + 0], 6, m[52])
			x = i(x, y, k, M, S[l + 7], 10, m[53])
			M = i(M, x, y, k, S[l + 14], 15, m[54])
			k = i(k, M, x, y, S[l + 5], 21, m[55])
			y = i(y, k, M, x, S[l + 12], 6, m[56])
			x = i(x, y, k, M, S[l + 3], 10, m[57])
			M = i(M, x, y, k, S[l + 10], 15, m[58])
			k = i(k, M, x, y, S[l + 1], 21, m[59])
			y = i(y, k, M, x, S[l + 8], 6, m[60])
			x = i(x, y, k, M, S[l + 15], 10, m[61])
			M = i(M, x, y, k, S[l + 6], 15, m[62])
			k = i(k, M, x, y, S[l + 13], 21, m[63])
			y = i(y, k, M, x, S[l + 4], 6, m[64])
			x = i(x, y, k, M, S[l + 11], 10, m[65])
			M = i(M, x, y, k, S[l + 2], 15, m[66])
			k = i(k, M, x, y, S[l + 9], 21, m[67])
			y = n(y, v)
			k = n(k, s)
			M = n(M, p)
			x = n(x, g)
		return h(y)+h(k)+h(M)+h(x)

		
	def recode(b):
		def getcode(s):
			w, i, s, e=s.split(',')
			a=b=c=0;d=[];f=[]
			while True:
				if a < 5:f.append(w[a])
				elif a < len(w):d.append(w[a])
				a+=1
				
				if  b < 5 :f.append(i[b])
				elif  b < len(i):d.append(i[b])
				b+=1
				
				if  c < 5:f.append(s[c])
				elif  c < len(s):d.append(s[c])
				c+=1
				
				if len(w) + len(i) + len(s) + len(e) == len(d) + len(f) + len(e):break

			k=''.join(s for s in d);m=''.join(s for s in f);b=0;o=[]
			for a in range(0,len(d),2):
				n = -1
				if ord(m[b]) % 2:n = 1
				o.append(chr(int(k[a:a+2], 36) - n))
				b+=1
				if b >= len(f):b = 0
			return ''.join(s for s in o)
		l=0
		while l<5 or 'decodeLink' not in b:
			try:b=getcode(xsearch("(\w{100,},\w+,\w+,\w+)",b.replace("'",'')));l+=1
			except:break
		return b
	
	return H(string, key) if key else recode(string)
		
def	getInfo(id,href,titleVn,titleEn,img,year,eps='',quocgia='',theloai='',daodien='',dienvien='',thoiluong='',IMDb='',desc=''):
	info='{'
	info+='"id":"%s"'%id
	info+=',"href":[%s]'%href
	info+=',"titleVn":'+json.dumps(titleVn)		
	info+=',"titleEn":'+json.dumps(titleEn)
	info+=',"thumb":'+json.dumps(img)	
	info+=',"year":'+json.dumps(year)	
	info+=',"episode":'+json.dumps(eps)	
	
	info+=',"country":'+json.dumps(quocgia)
	info+=',"genre":'+json.dumps(theloai)
	info+=',"writer":'+json.dumps(daodien)
	info+=',"director":'+json.dumps(dienvien)
	info+=',"duration":'+json.dumps(thoiluong)
	info+=',"rating":'+json.dumps(IMDb)				
	info+=',"plot":'+json.dumps(desc)
	info+='}'
	info=info.replace('/','\/')	
	
	return info
	
def additems2(url,page=1,pages=0):
	body = xread(url);items=[]
	
	if 'fptplay' in url:
		if 'danet' in url:			
			data='id=%s'%xsearch("danet/(\w+)/danet",url)
			b=xread('https://fptplay.net/show/tabdanet',data=data)			
		else:
			data='type=new&stucture_id=%s&page=%d'%(xsearch("/(\w+)/",url),page)		
			b=xread('https://fptplay.net/show/more',data=data)
		log(data)				
		s=xsearch('(<div id="wrap_content".+?"footer box">)',b,1,re.S,result=b)
		items2=re.findall('(<a.+?/a>)',s,re.S)
		for s in items2:
			if '"https://fptplay.net/epl_img/lockepl.png"' in s:continue
			title=vnu(xsearch('title="([^"]+?)"',s))
			if not title:title=vnu(xsearch('alt="([^"]+?)"',s))
			href=xsearch('href="([^"]+?)"',s)
			if not href:href=xsearch('data-href="(.+?)"',s)

			if not title or not href or 'javascript' in href:continue
			label=[re.sub('<.+?>','',i) for i in re.findall('(<p.+?/p>)',s)]
			label=' '.join(i for i in label if i not in title)
			img=xsearch('src="(.+?\.jpg)',s,result=xsearch('original="([^"]+?\.jpg)',s))
			if not img:img=xsearch('original="([^"]+?\.png)',s)
			
			dir=True if 'tập' in (title+label).lower() else False
			if xsearch('(\d+/\d+)',label):dir=True		
			if 'Đang diễn ra' in s:dir=None

			if dir or 'truyen-van-hoc'  in url or 'truyen-co-tich' in url:
				isFolder=True
			else:isFolder=False
				#id=re.search(r'\-([\w]+)\.html', href).group(1)+'?1'
			items.append((title,href,img,isFolder))
			
		if len(items2) > 29:			
			title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
			items.append((title,url,'search_result&page=%d'%(page+1),True))	
				
	elif 'hdvietnam' in url:
		hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.hdvietnam.com/forums/'}
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		
		content=xread(url,hd).split('<div class="titleBar">')[-1]
		items=[]
		for s in [i for i in re.findall('(<li id="thread.+?/li>)',content,re.S) if 'class="sticky"' not in i]:
			id=xsearch('id="thread-(.+?)"',s)
			
			b=xsearch('<h3 class="title">(.+?)</h3>',s,1,re.DOTALL)
			
			href='http://www.hdvietnam.com/'+xsearch('<a href="(.+?)"',b)				
			title=xsearch('data-previewUrl=".*">(.+?)</a>',b)
			#img=xsearch('<img src="(.+?)"',content)
			img='http://www.hdvietnam.com/styles/hdvn/hd-vietnam-logo.png'
			items.append((cleans(title),href,img,True))
			
		pn=xsearch('<a href="(.+?)" class="text">Ti.+ &gt;</a>',content)
		if pn:
			href='http://www.hdvietnam.com/'+pn
			#pagenext=xsearch('/page-(\d+)',href)
			
			title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
			items.append((title,href,'search_result&page=%d'%(page+1),True))	
			
		return items	
		
	elif 'hdonline' in url:
		for content in re.findall('<li>\s*<div class="tn-bxitem">(.+?)</ul>',body,re.S):
			titleVn=xsearch('<p class="name-en">(.+?)</p>',content).strip()
			titleEn=xsearch('<p class="name-vi">(.+?)</p>',content).strip()
			
			href='http://hdonline.vn'+xsearch('<a href="(.+?)"',content).strip()
			year=xsearch('<p>Năm sản xuất:(.+?) </p>',content).strip()
			if year in titleVn:titleVn=titleVn.replace(year,'').strip()			
			if year in titleEn:titleEn=titleEn.replace(year,'').strip()			
												
			img=xsearch('<img src="(.+?)"',content).strip()
			
			#lay desc truc tiep thau </li> = <div class="clearfix"> o content
			#desc=xsearch('<div class="tn-contentdecs mb10">(.+?)</div>',content,1,re.DOTALL)											
			
			if 'Cinderella Girls 2nd Season' in titleVn:titleVn='The iDOLM@STER Cinderella Girls 2nd Season'
			if 'Cinderella Girls 2nd Season' in titleEn:titleEn='The iDOLM@STER Cinderella Girls 2nd Season'
			
			log(re.search('.hụ .ề .iệt',content))
			if re.search('.huyết .inh',content):
				label='Thuyết minh'
			elif re.search('.hụ .ề .iệt',content):
				label='Phụ đề Việt'
			else:label=''
			#label=xsearch('<span title="Chất lượng HD (.+?)"',content)
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			
			IMDb = xsearch('Đánh giá: (.+?) </p>',content)				
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
			
			eps = xsearch('Số Tập: (.+?) </p>',content)				
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
						
			if pages:				
				b = xread(href)
				desc=xsearch('itemprop="description">(.+?)</div>',b,1,re.DOTALL)
				desc=re.sub('<(.+?)>','',desc).replace('\n','')

				v_theloai=xsearch('<li>Thể loại:(.+?)</li>',b)
				theloai=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_theloai))
				
				v_quocgia=xsearch('<li>Quốc gia:(.+?)</li>',b)
				quocgia=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_quocgia))
				
				thoiluong=xsearch('<li>Thời lượng: (.+?)</li>',b).strip()
				
				v_daodien=xsearch('Đạo diễn: .*?">(.+?)</li>',b).strip()				
				daodien=', '.join(i.strip() for i in re.findall('<a href=".+?">(.+?)</a>',v_daodien))			
				dienvien=', '.join(i.strip() for i in re.findall('<a href=".+?" class="tn-pcolor1">(.+?)</a>',b))
										
				id= 'hdonline-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)													
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))				
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))			
			
		if not pages:
			#href=xsearch('href="(.+?)">Trang Sau</a></li>',body)
			href=[i for i in re.findall('href="(.+?)">(.+?)</a></li>',body) if i[1] in 'Trang Sau'][0][0]
			if href:
				if not href.startswith('http'):href='http://hdonline.vn'+href
				title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
				items.append((title,href,'search_result&page=%d'%(page+1),True))												
	
	elif 'megabox' in url:		
		for content in re.findall('<div class="item">(.+?)</div><!--',body,re.S):
			item=re.search('src="(.+?)">\s*.*<span class="features">\s*</span>\s*</a>\s*<div class="meta">\s*<h3 class="H3title">\s*<a href="(.+?)">(.+?)</a>',content)
			if item:
				#title=item.group(3)
				href=item.group(2)
				img=item.group(1)							
				
				thoiluong = xsearch('Thời lượng:</strong>(.+?)</li>',content).strip()
				IMDb = xsearch('<span class=\'rate\'>(.+?)</span>',content).strip()
				title=xsearch('<h3 class=\'H3title\'>(.+?)</h3>',content).strip()
				title=vnu(title)				
				id=xsearch('-(\d+?)\.html',href)
				if id == '15740':year='1978'
				else:year = xsearch('Năm phát hành:.*(\d{4})</li>',content).strip()
				if year in title:title=title.replace(year,'').strip()
				quocgia=xsearch('Quốc gia:</strong> (.+?)</li>',content).strip()
				daodien=xsearch('Đạo diễn:</strong> (.+?)</li>',content).strip()
				dienvien=xsearch('Diễn viên:</strong> (.+?)</li>',content).strip()					
			
				theloai=xsearch('Thể loại:</strong> (.+?)</li>',content).strip()
				theloai=theloai.replace('Ma k','K').replace('Khoa học v','V').replace('Sử thi','Lịch sử')
				
				desc=xsearch('<div class=\'des\'>(.+?)</div>',content)
				
				try:					
					titleVn = title.split(" (")[0]
					titleEn = title.split(" (")[1].replace(')','')
					#title = titleVn + ' - ' + titleEn												
				except:titleVn=title;titleEn=''

				eps = xsearch('class=.esp.><i>(.+?)</span>',content).replace('</i>','')					

				id= 'megabox-'+id
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)						
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))											
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))	
	elif 'phimmoi' in url:	
		for s in re.findall('(<li class="movie-item">.+?</li>)',body,re.DOTALL):
			title=vnu(xsearch('title="(.+?)"',s))
			titleVn=xsearch('<span class="movie-title-1">(.+?)</span>',s)
			titleEn=xsearch('<span class="movie-title-2">(.+?)</span>',s)
			if '(' in titleVn and ')' in titleVn:titleVn=titleVn.replace(' (', ' - ').replace(')', '')			
			if '(' in titleEn and ')' in titleEn:titleEn=titleEn.replace(' (', ' - ').replace(')', '')
			#duration=xsearch('>(\d{1,3}.?phút)',s)
			label=xsearch('"ribbon">(.+?)</span>',s)
			href=xsearch('href="(.+?)"',s)
			if 'phimmoi.net' not in href:href='http://www.phimmoi.net/'+href
			img=xsearch('url=(.+?)%',s)					
			
			title = '%s [COLOR green]%s[/COLOR]'%(title,label)														
			#if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
							
			eps=xsearch('Tập ?(\d{,4}/\d{,4}|\?/\d{,4}|\d{,4})',s)
			if not eps:
				epi=xsearch('class="eps">Trọn bộ ?(\d{1,4}) ?tập</div>',s)
				if epi:eps='%s/%s'%(epi,epi)
			else:epi=eps.split('/')[0]
			try:epi=int(epi)
			except:epi=0
			
			if eps:isFolder=True
			else:isFolder=False
						
			
			#if xsearch('<dd class="movie-dd status">Trailer',b,0):continue						
			
			if pages:
				b=xread(href)
				thoiluong = xsearch('Thời lượng:</dt><dd class="movie-dd">(.+?)</dd>',b)
				IMDb = xsearch('<dd class="movie-dd imdb">(.+?)</dd>',b)			
				quocgia=', '.join(i for i in re.findall('<a class="country" href=".+?" title=".+?">(.+?)</a>',b))
															
				theloai = ', '.join(i for i in re.findall('<a class="category" href=".+?" title="(.+?)">',b,re.S) if 'lẻ' not in i and 'bộ' not in i)#Phim bộ Hàn 
				theloai=theloai.replace('Phim Bí ẩn-Siêu nhiên','Phim Bí ẩn').replace('Phim hồi hộp-Gây cấn','Phim hồi hộp')
				theloai=theloai.replace('Phim tình cảm-Lãng mạn','Phim tình cảm').replace('Phim ','')
							
				desc=xsearch('id="film-content"><p>(.+?)\s*</p>',b,1,re.DOTALL)#<br><br>
				desc=re.sub('<(.+?)>','',desc)

				if 'Năm:</dt><dd class="movie-dd">' in b:
					year = xsearch('Năm:</dt><dd class="movie-dd">.+?(\d{1,4})</a>',b,1,re.DOTALL)
				elif 'Ngày phát hành:</dt><dd class="movie-dd">' in b:
					year = xsearch('Ngày phát hành:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)
				else:
					year = xsearch('Ngày ra rạp:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)			
				
				if '(' in titleVn: titleVn=titleVn.replace('(','- ').replace(')','')
				if '(' in titleEn: titleEn=titleEn.replace('(','- ').replace(')','')			
			
				daodien=', '.join(i for i in re.findall('<a class="director" href=".+?" title="(.+?)">',b))
				dienvien=', '.join(i for i in re.findall('<span class="actor-name-a">(.+?)</span>',b))
			
				id= 'phimmoi-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)
							
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))						
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))																
			else:items.append((title,href,img,isFolder))
			
		if not pages:
			href=xsearch('<li><a href="(.+?)">Trang kế.+?</a></li>',body)
			if href:
				if not href.startswith('http'):href='http://www.phimmoi.net/'+href			
				title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
				if href:items.append((title,href,'search_result&page=%d'%(page+1),True))	
				
	elif 'hdviet' in url:		
		s=xsearch('(<[^>]+?box-movie-list.+?)<div class="box[^"]+?">',body,1,re.S)
		for s in re.findall('(<li.+?/li>)',s,re.S):
			log(s)
			titleVn=xsearch('class="mv-namevn" title=".+?">(.+?)</a>',s)
			titleEn=xsearch('class="mv-nameen" title=".+?">(.+?)</a>',s)			
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)
			
			title=xtitle(s).replace('Phim ','');id_film=xsearch('data-id="(.+?)"',s);img=ximg(s)						
			if not title or not id_film:continue			
			href='hdviet.com/'+str(id_film)
			
			eps=xsearch('<span class="labelchap2">(.+?)</span>',s)

			label=xsearch('id="fillprofile" class="icon-(.+?)11">',s)
			label='SD' if 'SD' in label else 'HD%s'%label
			phim18=xsearch('class="children11".+?>(.+?)</label></span>',s)
			TM=xsearch('id="fillaudio" class="icon-(.+?)">',s)
			
			year=xsearch('<span class="chil-date".+?>(.*?)</label></span>',s)
			
			IMDb=xsearch('<span class="fl-left">.+?<span>(.+?)</span>',s)
			upl=xsearch('<span class="fl-right">.+?<span>(.+?)</span>',s)

			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
									
			if eps:
				isFolder=True
				title = '(' + eps + ') ' + title
			else:isFolder=False
					
			if pages:			
				href_=xhref(s)
				b=xread(href_)#them the loai, quoc gia
		
				theloai=', '.join(s for s in re.findall('<p class="ttlcontent">Thể loại</p>\s*<a href="http://movies.hdviet.com/phim-.+?">phim-(.+?)</a>',b))
				quocgia=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/quoc-gia/.+?">(.+?)</a>',b))
				
				daodien=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dien-vien/.+?">(.+?)</a>',s))
				dienvien=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dao-dien/.+?">(.+?)</a>',s))
													
				desc=xsearch('<span class="cot1">(.+?)</span>',s);thoiluong=''
			
				id= 'hdviet-'+id_film
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
													
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))
												
		if not pages:
			s=xsearch('(<ul class="paginglist.+?/ul>)',body,1,re.S)
			href=xsearch('(class="active".+?/ul>)',s,1,re.S)
			href=xsearch('href="(.+?)"',href)
			if href:
				pagelast=xsearch('>(\d+)<.+?/ul>',s)
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				items.append((title,href,'search_result&page=%d'%(page+1),True))
				
	elif 'hayhaytv' in url:
		b=re.sub('>\s*<','><',body)		
		p1='<div class="group-title">';p2='<div class="block-base movie">'
		S=' '.join(i for i in b.split(p1) if p2 in i)
		for s in S.split(p2):
			href=xsearch('href="(.+?)"',s)
			img=xsearch('src="(.+?)"',s)
			title=xsearch('alt="(.+?)"',s)
			if [i for i in (href,img,title) if not i]:continue
			eps=re.sub('<strong>','',xsearch('<span class="label-range">(.+?)</strong>',s).strip())
			if not eps:
				isFolder=False
			else:
				isFolder=True
				title=eps+' '+title			
			items.append((title,href,img,isFolder))
		
		pn=xsearch('<a href="([^"]+?)">Sau</a>',S)
		if pn:
			pagelast=xsearch('<a href="[^"]+page=(\d+)">Cuối</a>',S)
			if 'http' not in pn:href='http://www.hayhaytv.vn'+pn
			
			title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)			
			items.append((title,href,'search_result&page=%d'%(page+1),True))
				
	elif 'phimnhanh' in url:
		for s in re.findall('(<li  class="serial">.+?</li>)',body,re.DOTALL):
			href=xsearch('href="(.+?)"',s)
			#title=xsearch('title="(.+?)"',s)
			titleVn=xsearch('<span class="title display">(.+?)</span>',s)
			titleEn=xsearch('<span class="title real">(.+?) \(\d+\)',s)
			year=xsearch('<span class="title real">.+? \((\d+)\)</span>',s)
			img=xsearch('data-original="(.+?)"',s)
			label=xsearch('<span class="m-label q">(.+?)</span>',s)
			lang=xsearch('<span class="m-label lang">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)											
			
			IMDb=xsearch('<span class="m-label imdb"><span class="rate">(.+?)</span>',s)
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
			
			ep=xsearch('<span class="m-label ep">(.+?)</span>',s)
			if 'tập' in ep:eps=ep;thoiluong='';isFolder=True
			else:thoiluong=ep;eps='';isFolder=False
						
			if pages:
				b=xread(href)		

				v_theloai=xsearch('<p>Thể loại:(.+?)</p>',b)
				theloai=', '.join(i.replace('Kinh Dị - Ma','Kinh Dị').replace('Tâm Lý - Tình Cảm','Tâm Lý, Tình Cảm') for i in re.findall('<a href=".+?" title="(.+?)">',v_theloai))						
				
				v_quocgia=xsearch('<p>Quốc gia:(.+?)</p>',b)
				quocgia=', '.join(i.replace('Mỹ - Châu Âu','Âu-Mỹ') for i in re.findall('<a href=".+?" title="(.+?)">',v_quocgia))
				
				v_daodien=xsearch('<p>Đạo diễn:(.+?)</p>',b)
				daodien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_daodien))
				v_dienvien=xsearch('<p>Diễn viên:(.+?)</p>',b)
				dienvien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_dienvien))		
													
				desc=''#xsearch('<p>(.+?)<br></p>',b,1,re.DOTALL)						
			
				id= 'phimnhanh-'+xsearch("javascript:download\('(.+?)'",b)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
													
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))
						
		if not pages:
			href=xsearch('<a href="([^>]+?)" rel="next">',body)
			if href:
				href=href.replace('amp;','');pn=xsearch('page=(\d+?)\Z',href)
				ps=xsearch('<a href="[^>]+?">(\d+?)</a></li> <li><a href="[^>]+?" rel="next">',body)
				title='[COLOR lime]Trang tiếp theo: %s/%s[/COLOR]'%(pn,ps)
				items.append((title,href,'search_result&page=%d'%(page+1),True))	
	
	elif 'bilutv' in url:
		cl='film-item '
		for s in re.findall('(<li class="%s.+?</li>)'%cl,body,re.DOTALL):
			href='http://bilutv.com/'+xsearch('href="/(.+?)"',s)
			img=xsearch('original="(.+?)"',s)
			titleVn=xsearch('<p class="name">(.+?)</p>',s)
			titleEn=xsearch('<p class="real-name">(.+?)</p>',s)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			#quality=xsearch('<span class="label-quality">(.+?)</span>',s)
			label=xsearch('<label class="current-status">(.+?)</label>',s)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
												
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False

			#if 'Thuyết Minh' in label:title='[COLOR blue]TM[/COLOR] '+title
		
			if pages:
				id= 'bilutv-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not pages:							
			pn=re.search('<a href="/[^<]+?" >(\d+)</a></li><li><a href="/([^<]+?)" class="navigation next" rel="next">',body)
			if pn:
				href='http://bilutv.com/'+pn.group(2);pagelast=pn.group(1)
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				items.append((title,href,'search_result&page=%d'%(page+1),True))
			else:
				pn=re.search('<a href="[^<]+?" >(\d+)</a></li><li><a href="([^<]+?)" class="navigation next" rel="next">',body)
				if pn:
					href=url.split('?')[0]+pn.group(2);pagelast=pn.group(1)
					title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
					items.append((title,href,'search_result&page=%d'%(page+1),True))	
	elif 'phimbathu' in url:
		s=xsearch('(id="content".+?class="right-content")',body,1,re.DOTALL)
		for i in re.findall('(<li class="item.+?/li>)',s,re.DOTALL):
			titleVn=xsearch('title="(.+?)"',i)
			titleEn=xsearch('class="name-real">\s*<span>(.+?)</span>',i)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			label=xsearch('"label">(.+?)<',i)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			#if re.search('.huyết .inh',i):title='[COLOR blue]TM[/COLOR] '+title
			href=xsearch('href="(.+?)"',i)
			if '//' not in href:href='http://phimbathu.com'+href
			img=xsearch('src="(.+?)"',i,result=xsearch('data-original="(.+?)"',i))
							
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False
			
			if pages:
				id= 'phimbathu-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not pages:
			pn=xsearch('<a href="([^<]+?)" class="navigation next"',s)
			if pn:
				pagelast=xsearch('>(\d+?)</a></li><li><a href="[^<]+?" class="navigation next"',s)
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				items.append((title,'http://phimbathu.com'+pn,'search_result&page=%d'%(page+1),True))	
	
	elif 'hdsieunhanh' in url:	
		for s in [i for i in body.split('<div class="block-base movie">') if 'data-id' in i]:
			title=xsearch('alt="(.+?)"',s)
			titleEn=xsearch('class="film-name"><h2>(.+?)</h2>',s)
			titleVn=xsearch('</h2>(.+?)</a>',s).strip()
			href=xsearch('href="(.+?)"',s)
			#if 'html' not in href:href='http://hdsieunhanh.com/'+href
			img=xsearch('src="(.+?)"',s).replace('amp;','')
			rate=xsearch('"rate">([^<]+?)</span>',s)
			label=xsearch('<span class="tag"> (.+?) </span>',s)
			if label:title='%s [COLOR green]%s[/COLOR]'%(title,label)
			eps=' '.join(re.sub('<[^<]+?>','',xsearch('(<span class="label-range">.+?<strong>\d+?</strong>)',s)).split())
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
			
			if pages:
				b=xread(href)				
				v_year=xsearch('Năm phát hành: <strong>(.+?)</strong>',b)
				year=re.findall('<a href=".+?">(.+?)</a>',v_year)[0]						
				thoiluong=xsearch('Thời lượng: <strong>(.+?)</strong>',b)
				IMDb=xsearch('Đánh giá phim: <strong>(.+?)</strong>',b)				
				v_theloai=xsearch('Thể loại: <strong>(.+?)</strong>',b)
				theloai=', '.join(i for i in re.findall('<a href=".+?">(.+?)</a>',v_theloai))									
				v_quocgia=xsearch('Quốc gia: <strong>(.+?)</strong>',b)
				quocgia=', '.join(i for i in re.findall('<a href=".+?">(.+?)</a>',v_quocgia))				
				v_daodien=xsearch('Đạo diễn: <strong>(.+?)</strong>',b)
				daodien=', '.join(i for i in re.findall('<a href=".+?">(.+?)</a>',v_daodien))				
				v_dienvien=xsearch('Diễn viên: <strong>(.+?)</strong>',b)
				dienvien=', '.join(i for i in re.findall('<a href=".+?">(.+?)</a>',v_dienvien))													
				desc=xsearch('Nội dung phim:</h2>(.+?)</div>',b).strip()
			
				id= 'hdsieunhanh-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
													
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))											
			else:items.append((title,href,img,isFolder))
		
		if not pages:				
			pn=xsearch('<a href="([^"]+?)">Sau</a>',body)
			if pn:
				pn='http://hdsieunhanh.com/'+pn.replace('amp;','')
				pagelast=xsearch('=(\d+)">Cuối</a></li></ul>',body)
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				items.append((title,pn,'search_result&page=%d'%(page+1),True))	
				
	elif 'vietsubhd' in url:
		if '/videos' in url:p='(<span class="video.+?/a>)'
		else:p='(<a class="poster".+?/div>)'

		for s in re.findall(p,body,re.S):
			title=xsearch('title="(.+?)"',s)
			titleEn=xsearch('</a> <dfn>(.+?)</dfn>',s)
			titleVn=title.replace(' - '+titleEn,'')
			year=xsearch('</dfn> <dfn>(.+?)</dfn>',s)			
			label=xsearch('<span class="status">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			

			href=xsearch('href="(.+?)"',s)
			img=xsearch('url=([^<]+jpg)',s)
			img=img.replace('w35-h35','w180-h240').replace('Poster.','')
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False
		
			if pages:
				id= 'vietsubhd-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not pages:			
			pn=xsearch('class="current".+?<a href="([^"]+?)"[^<]*?>\d+<',body)
			if pn:
				pagelast=xsearch('-(\d+)\.html" title="Trang cuối">',body)
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				items.append((title,pn,'search_result&page=%d'%(page+1),True))	
	elif 'xemphimbox' in url:
		for s in [i for i in body.split('<div class="item col-lg-3 col-md-3 col-sm-6 col-xs-6">') if '<div class="inner">' in i]:
			href=xsearch('href="(.+?)"',s)
			title=xsearch('title="(.+?)">',s).strip()
			img=xsearch('src="(.+?)"',s)
								
			titleEn=xsearch('</a> <dfn>(.+?)</dfn>',s)
			titleVn=title.replace(' - '+titleEn,'')
			year=xsearch('</dfn> <dfn>(.+?)</dfn>',s)			
			label=xsearch('<span class="status">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			

			if re.search('Tap|Full',no_accent(label)):			
				isFolder=True
				arr=label.split('-')
				try:
					eps=arr[0]
					label=arr[1]
				except:eps=''
			else:isFolder=False;eps=''
		
			if pages:
				b=xread(href)				
				v_year=xsearch('Năm phát hành:(.+?)</dd>',b)
				year=re.findall('title=".+?">(.+?)</a>',v_year)[0]						
				thoiluong=xsearch('Thời lượng: <strong>(.+?)</strong>',b)
				IMDb=xsearch('Đánh giá phim: <strong>(.+?)</strong>',b)				
				v_theloai=xsearch('Thể loại:(.+?)</dd>',b)
				theloai=', '.join(i.replace('Anime - Hoạt Hình','Hoạt Hình') for i in re.findall('title=".+?">(.+?)</a>',v_theloai) if 'Phim' not in i)
				v_quocgia=xsearch('Quốc gia:(.+?)</dd>',b)
				quocgia=', '.join(i for i in re.findall('title=".+?">(.+?)</a>',v_quocgia))			
				v_daodien=xsearch('Đạo diễn:(.+?)</dd>',b)
				daodien=', '.join(i for i in re.findall('title=".+?">(.+?)</a>',v_daodien))				
				v_dienvien=xsearch('Diễn viên:(.+?)</dd>',b)
				dienvien=', '.join(i for i in re.findall('title=".+?">(.+?)</a>',v_dienvien))												
				desc=xsearch('Nội dung Phim:(.+?)</p>',b,1,re.S)
				desc=re.sub('<(.+?)>','',vnu(desc)).replace('\n','').strip()
						
				id= 'xemphimbox-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
													
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))											
			else:items.append((title,href,img,isFolder))
			
		if not pages:							
			pagelast=xsearch('trang-(\d{1,4}).html" title="Trang cuối">',body)
			if pagelast:				
				if 'trang-' not in url:url=url+'trang-%d.html'%page
				href=url.replace('trang-%d.html'%page, 'trang-%d.html'%(page+1))
				
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				if href:items.append((title,href,'search_result&page=%d'%(page+1),True))	
			
			
	elif 'xuongphim' in url:	
		urlhome='http://xuongphim.tv'
		for content in re.findall('<li>\s*<div class="tn-bxitem">(.+?)</ul>',body,re.S):
			titleVn=xsearch('<p class="name-vi">(.+?)</p>',content).strip()
			titleEn=xsearch('<p class="name-en">(.+?)</p>',content).strip()
						
			year=xsearch('( \(\d{4}\))',titleEn)							
			if not year:year=xsearch('( \d{4})',titleEn)
			titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			
			href=urlhome+xsearch('<a href="(.+?)"',content).strip()														
			img=xsearch('<img src="(.+?)"',content).strip()
			
			#lay desc truc tiep thau </li> = <div class="clearfix"> o content
			#desc=xsearch('<div class="tn-contentdecs mb10">(.+?)</div>',content,1,re.DOTALL)											
			
			label=xsearch('<span title="Chất lượng HD (.+?)"',content)			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
						
			#<span class="tn-pcolor1">Phim phim lẻ</span>
			eps = xsearch('S&#7889; T&#7853;p: (.+?)</p>',content)				
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
			
			if pages:pass
			else:items.append((title,href,img,isFolder))		

		if not pages:
			for href, pagenext in re.findall('<a rel=".+?" href="(.+?)">(.+?)</a>',body):
				if pagenext == 'Next':
					href=urlhome+href
					title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
					items.append((title,href,'search_result&page=%d'%(page+1),True))															
			
	elif 'tvhay' in url:
		for s in re.findall('(<div class="inner">.+?</li>)',body,re.DOTALL):
			title=xsearch('title="(.+?)"><span',s)
			titleVn=xsearch('Xem phim </span>(.+?)</a>',s)
			titleEn=xsearch('<div class="name2">\s*(.+?)</div>',s).strip()			
			year=xsearch('<div class="year">\s*(.+?)</div>',s).strip()
			label=xsearch('<div class="status">\s*(.+?)</div>',s).strip()
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			href=xsearch('href="(.+?)"',s);img=xsearch('src=".+?url=(.+?)"',s)
			
			if not img:
				s=[i[1] for i in items if i[0]==href]
				if s:img=s[0]
			
			if href:items.append((title,href,img,False))
			
		last=xsearch('<a class="last" href="(.+?)">',body)		
		if last:
			pagelast=xsearch('/(\d+)/',last)
			href=xsearch('rel="next" href="(.+?)">',body)			
			#page=xsearch('/(\d+)/',href)
			title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
			items.append((title,href,'search_result&page=%d'%(page+1),True))	
			
	elif 'fcine' in url:	
		hd={'User-Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest'}
		b=xread(url,hd).replace('\\n','').replace('\\t','').replace('\\r','')
		try:j=json.loads(b)
		except:j={}
		s = j.get('rows','').encode('utf-8')
		
		S=re.findall('(<div class="esnList_item".+?/ul>)',s,re.S)
		if not S:S=re.findall('(<li.+?/li>)',s,re.S)
		for s in S:
			title=xsearch("title='(.+?)'",s,result=xsearch('title="(.+?)"',s)).replace('&#039;',"'")
			href=xsearch('href="(.+?)"',s)									
			if not title or not href:continue
			
			titleVn=xsearch('<div class="ipsTruncate ipsTruncate_line ipsType_blendLinks ipsType_light".+?>\s*(.+?)</div>',s)			
			titleEn=xsearch('<div class="ipsTruncate ipsTruncate_line" data-ipsTruncate.+?>\s*(.+?)</div>',s).replace('&#039;',"'")
			year=xsearch('( \(\d{4}\))',titleEn)							
			if not year:year=xsearch('( \d{4})',titleEn)
			titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			if 'HDRip.png' in s:label='HDRip'
			elif 'Bluray.png' in s:label='Bluray'
			elif 'WEBrip.png' in s:label='WEBrip'
			elif 'WEB-DL.png' in s:label='WEB-DL'
			elif 'DVDrip.png' in s:label='DVDrip'
			else:label=''						
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			img=xsearch('src="(.+?)"',s);eps=''
					
			if pages:									
				id= 'fcine-'+xsearch('view/(\d+?)-',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
				
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,False))
		
		if not pages:		
			pagination=j.get('pagination','').replace('&amp;','&').encode('utf-8')
			p=xsearch("data-page='(\d+)' data-ipsTooltip title='Next page'",pagination)
			if p:
				href=xsearch("href='([^']+?)' data-page='%s'"%p,pagination)
				title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%p
				if href:items.append((title,href+'&listResort=1','search_result&page=%d'%(page+1),True))
		
	elif 'fsharefilm' in url:
		s=xsearch('(<div class="list-movie.+?class="fb-page")',body,1,re.S)
		for s in re.findall('(<div class="movie.+?\s+</div>)',s,re.S):
			title=xsearch('>([^<]+?)</a></h.>',s)
			if not title:title=xsearch('alt="(.+?)"',s,result=xsearch('>([^<]+?)</h4>',s))
			title=title.replace(' &#8211; ','<br />')			
			label=' '.join(re.sub('<.+?>','',i) for i in re.findall('(<span.+?/span>)',s))
			#if '- TM' in label:title='[COLOR gold]TM[/COLOR] '+title
			#elif '- LỒNG TIẾNG' in label:title='[COLOR gold]LT[/COLOR] '+title
			#elif '- FFVNLT' in label:title='[COLOR gold]FFVNLT[/COLOR] '+title
			#if label:title=title+' [COLOR green]%s[/COLOR]'%label
			if re.search('\d+/\d+|Full|tập|Tập',label):dir=True
			else:dir=False
			href=xhref(s)
			if not title or not href:continue
			img=ximg(s)
						
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')
			#else:year = xsearch('<b>Năm Phát Hành:</b></p>\s*<p class="info">(.+?)</p>',b).strip()			
			
			try:				
				titleVn=title.split('<br />')[0]
				titleEn=title.split('<br />')[1]
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)

									
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			
			
			if pages:
				'''
				b = xread(href)
				
				thoiluong = ''#xsearch('Thời lượng:</strong> (.+?)</li>',b).strip()
				IMDb = xsearch('<b>IMDB:</b></p>\s*<p class="info">(.+?)/10</p>',b).strip()			
				quocgia=xsearch('<b>Quốc Gia:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
				daodien=xsearch('<b>Đạo Diễn:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
				dienvien=xsearch('<b>Diễn Viên:</b></p>\s*<p class="info">(.+?), </p>',b).strip()
				dienvien=dienvien.replace('-trong-vai:-','')
										
				v_theloai=xsearch('<b>Thể Loại:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
				theloai=', '.join(i.replace('Phim','') for i in re.findall('<a href=".+?" rel="category tag">(.+?)</a>',v_theloai))
				
				desc=xsearch('<h2>\s*<p>Cốt Truyện</h2>(.+?)</p>',b)			
				
				eps = ""
				'''

				id= 'fsharefilm-'#+xsearch('#tabs-(.+?)-',b)														
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
				
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,True))				
		
		if not pages:		
			href=xsearch('<a href="([^"]+?)" *>&raquo;</a>',body)
			if href:
				try:pagelast=max(int(i) for i in re.findall('<a[^>]+?>(\d+?)</a></li>',body))
				except:pagelast=0
				
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				if href:items.append((title,href,'search_result&page=%d'%(page+1),True))							
				
	elif '4share' in url:
		for s in [i for i in re.findall('(<li id="thread.+?/li>)',body,re.S) if '"sticky"' not in i]:
			label=xsearch('(<h3.+?/h3>)',s,1,re.S)
			title=xsearch('>([^<]+?)</a>',label)
			href=fixUrl('http://diendan.4share.vn/',xhref(label))
			label=xsearch('data-author="(.+?)"',s)
			title=title+' [COLOR gold]%s[/COLOR]'%label
			items.append((title,href,'',True))
		
		pagelast=xsearch('data-last="(\d+?)"',body)
		if pagelast and int(pagelast)>page:
			url=url.rsplit('/',1)[0]+'/page-%d'%(page+1)
			title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
			items.append((title,href,'search_result&page=%d'%(page+1),True))							
		
	elif 'vaphim' in url:
		pattern='<a data=.+?src="(.+?)[\?|\"].+?<h3.+?><a href="(.+?)" rel=.+?>(.+?)</a></h3>'
		for img,href,title in re.findall(pattern,body,re.DOTALL):
			#if re.search('<.+?>',title):log('1')
			
			title=re.sub('<.+?>','[]',title)
		
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')						
			try:
				titleVn=title.split('[]')[0].strip()
				titleEn=title.split('[]')[1].strip()										
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)					
			
			label=''						
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			
			
			eps = ""
			if pages:
				'''
				b = xread(href);v_b=re.sub('<(.+?)>','',b.replace('<br />','[]'))									
				if not year:
					year = xsearch('Năm sản xuất:(.+?)\[\]',v_b).strip()	
				
				thoiluong = xsearch('Thời lượng:(.+?)\[\]',v_b).strip()
				IMDb = xsearch('Đánh giá:(.+?)/10.*',v_b).strip()
				
				quocgia=xsearch('Quốc gia:(.+?)\[\]',v_b).strip()			
				daodien=xsearch('Đạo diễn:(.+?)\[\]',v_b).strip()
				dienvien=xsearch('Diễn viên:(.+?)\[\]',v_b).strip()				
				dienvien = dienvien.replace('-trong-vai:-','')
				
				theloai=xsearch('Thể loại:(.+?)\[\]',v_b).strip()				
				
				desc=vnu(xsearch('Nội dung:</span></strong></h2>\s*<p>(.+?)</p>',b))
				
																																							
				tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
				if tabs:								
					for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
						content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
						label=subtitle=v_url=''
						for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
							if ('/folder/' in href and 'phim-le' in url) or 'subscene.com' in href:continue#chua xu ly
							elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
								subtitle=href
							elif '/file/' in href:v_url=href;label=tab_label											
							elif '/folder/' in href and 'series' in url:v_url=href;label=tab_label
						
						if v_url:
							tmp='{"label":'+json.dumps(label)+',"url":'+json.dumps(v_url)+',"subtitle":'+json.dumps(subtitle)+'}'
							if v_href:v_href+=','+tmp
							else:v_href=tmp
						
						#break #chi lay tab dau tien
				else:
					pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
					label=subtitle=v_url=''
					for href, fn in re.findall(pattern,b):
						if ('/folder/' in href and 'phim-le' in url) or 'subscene.com' in href:continue#chua xu ly
						elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
							subtitle=href
						elif '/file/' in href:v_url=href;label=''											
						elif '/folder/' in href and 'series' in url:v_url=href;label=tab_label
						
					if v_url:v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(v_url)+',"subtitle":'+json.dumps(subtitle)+'}'

				'''
				id= 'vaphim-'#+xsearch('#tabs-(.+?)-',b)

				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
				
				items.append(('%03d'%(pages),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,True))

		if not pages:
			pagelast=xsearch("<span class='pages'>Trang \d{1,4} của (\d{1,4})</span>",body)
			if pagelast and int(pagelast)>page:				
				if 'page/' not in url:url=url+'page/%d'%page
				href=url.replace('page/%d'%page, 'page/%d'%(page+1))
				
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				if href:items.append((title,href,'search_result&page=%d'%(page+1),True))		
				
	elif 'pubvn.net' in url:	
		b=xread(url)		
		for s in [i for i in b.split('<div class="film" style="">') if '<div class="film_poster">' in i]:
			title=xsearch('<figcaption>(.+?)</figcaption>',s).strip()
			title=re.sub('\(.+?Versions\)|\(.+?Version\)|\(.+?s Cut\)|\(.+?Collection\)|\(.+?Edition\)|\(.+?emastered\)','',title)
			arr=title.replace(')','').split(' (')
			if len(arr)==2:titleEn=titleVn=arr[1];year=arr[1]
			elif len(arr)==3:titleEn=arr[0];titleVn=arr[1];year=arr[2]
			elif len(arr)==4:titleEn=arr[0];titleVn=arr[1];year=arr[3]#phim bo
			else:
				log(title)
				continue
				#http://pubvn.net/phim/270/colombiana-nu-sat-thu-unrated-version-2011.html
				#Colombiana (Nữ Sát Thủ) (Unrated Version) (2011)

			thoiluong = xsearch('Thời lượng: </span>(.+?)</p>',s).strip()								
			theloai=xsearch('Thể loại: </span>(.+?)</p>',s)
			label=thoiluong+' - '+theloai
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			label=''

			IMDb = xsearch('Điểm IMDb: </span><span class=\'ttimdb_score\'>(.+?)</span></p>',s)
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
			
			href=fixUrl('http://pubvn.net/',xsearch('href="(.+?)" class="tool',s))
			if not title or not href:continue
			img=fixUrl('http://pubvn.net/',ximg(s))
			if '"film_series"' in s:			
				eps=xsearch('<p>(\d+/\d+)</p>',s)
				isFolder=True;title='%s [COLOR gold](%s)[/COLOR]'%(title,eps)
			else:eps='';isFolder=False
			

		#<p><span class='tt_bold'>Ngày phát hành: </span>15/01/2011</p>
	   #<p><span class='tt_bold'>Hình ảnh: </span><img class='iconTooltipHD' src='/movie/pictures/features/jzr1367833013.png' height='11'></p>
	   #<p><span class='tt_bold'>Phụ đề: </span>Tiếng Việt</p>	  
				
			if pages:				
				quocgia=xsearch('Quốc gia: </span>(.+?)</p>',s)
				daodien=''
				dienvien=xsearch('Diễn viên: </span>(.+?)</p>',s)
				dienvien=dienvien.replace('&nbsp;',' ')													
														
				desc=xsearch('<p>(.+?)</p>\s*</div>">',s)			
			
				id= 'pubvn-'+xsearch('/phim/(\d+?)/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)													
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))				
				items.append(('%03d'%(pages),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not pages:											
			s=xsearch('(<nav class= main_pager.+?/nav>)',b,1,re.S)
			href=xsearch('<a href="(.+?\.html)" *>Cuối</a>',s)#trangxx.html
			pagelast=xsearch('(\d+)',href,result='0')
			if href and int(pagelast) > page+1:
				title='[COLOR lime]Trang tiếp theo: %d/%s[/COLOR]'%(page+1,pagelast)
				href=xsearch('href="(.+?)" *>%d</a>'%(page+1),s)
				href=url.rsplit('/',1)[0]+'/'+href
				if href:items.append((title,href,'search_result&page=%d'%(page+1),True))
					
	return items			
	
def eps2(url, name=''):
	page=1;items=[]
	
	if 'fptplay' in url:
		hd={'User_Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest','X-KEY':'123456'}
		hd['referer']='https://fptplay.net/'	
		while True:
			data='film_id=%s&page=%d'%(xsearch('(\w{20,30})',url),page)
			b=xread('https://fptplay.net/show/episode',hd,data)
			for s in [i for i in re.findall('(<li.+?/li>)',b,re.S) if '"title_items"' in i]:
				title=xsearch('title="(.+?)"',s)
				epi=xsearch('<p class="title_items">.+? (\d+)',s)
				#href=xsearch('(\w{20,30})',xsearch('href="(.+?)"',s))+'?'+xsearch('id="episode_(\d{1,4})"',s)
				href=xsearch('href="(.+?)"',s)
				items.append((href,epi))
			page+=1			
			if '&rsaquo;&rsaquo;' not in b:break			
			
	elif 'hdonline' in url:			
		id=xsearch('-(\d+)\.html',url)		
		while True:		
			b=xread('http://hdonline.vn/episode/ajax?film=%s&episode=&page=%d&search='%(id,page))
			items+=[('http://hdonline.vn'+j[0],j[1]) for j in re.findall('href="(.+?)".*data-order="(.+?)"',b)]
			page+=1			
			
			pn=xsearch('<a class="active"[^<]+>\d+</a><[^<]+>(\d+)</a>',b)
			if not pn:break
			
	elif 'megabox' in url:				
		content = xread(url)
		match = re.compile("href='(.+?)' >(\d+)<").findall(content)
		for href, epi in match:
			addLink('Tập ' + epi, href, 'stream', img)
		id2=xsearch('-(tap-\d{1,3}-\d{1,6})\.html',href)#xu ly truong hop truoc tap co 2 dau --
			
		id=xsearch('-(\d{1,6})\.html',url);t=1
		while True:
			start=t*30+1
			b=xread('http://phim.megabox.vn/content/ajax_episode?id=%s&start=%s'%(id,start))
			j=json.loads(b)
			if j:				
				for i in j:
					name=i['name'].encode('utf8')
					epi=name.split('Tập ')[1]					
					v_href=href.replace(id2,'tap-%s-%s'%(epi,i['content_id'].encode('utf8')))
					items.append((v_href,epi))
				t+=1
			else:break			
						
	elif 'phimmoi' in url:	
		body=xread(url+'xem-phim.html')				
		for detail in re.findall('(<div class="server clearfix server-group".+?</ul>)',body,re.DOTALL):
			title=' '.join(s for s in xsearch('<h3 class="server-name">(.+?)</h3>',detail,1,re.DOTALL).split())
			if title and 'tập phim' not in title:
				serverid=xsearch('data-serverid="(.+?)"',detail)
				title='[COLOR yellow]%s[/COLOR]'%title
				items.append(('',title))				

			for title,href in re.findall('title="Tập (.+?)".+?href="(.+?)"',detail,re.DOTALL):
				items.append(('http://www.phimmoi.net/'+href,title))
				
	elif 'xuongphim' in url:
		id=xsearch('-(\d+)\.html',url)		
		#id = re.search('-(\d{1,6})\.html',url).group(1)
		while True:		
			b=xread('http://xuongphim.tv/?film=%s&episode=&page=%d&searchep='%(id,page))
						 			
			items+=[('http://xuongphim.tv'+j[0],j[1]) for j in re.findall('href="(.+?)">(.+?)</a>',b)]
			page+=1			
			
			pn=xsearch('<a class="active"[^<]+>\d+</a><[^<]+>(\d+)</a>',b)
			if not pn:break
			
	elif 'phimbathu.com' in url:
		url='http://phimbathu.com'+xsearch('"btn-see btn btn-info adspruce-streamlink" href="(.+?)"',xread(url))
	
		b=xread(url)
		s=xsearch('(<div class="list-episode".+?/div)',b,1,re.S)
		return re.findall('href="(.+?)">(.+?)<',s)
	
	elif 'vietsubhd.com' in url:		
		if 'xem-phim.html' not in url:url+='xem-phim.html'
		b=xread(url)
		filmID=xsearch('filmid="(.+?)"',b)

		s=xsearch('<div class="block servers">(.+?)<div class="block comment">',b,1,re.S)
		servers=re.findall('(<div class="name.+?/ul>)',s)
	
		for s in servers:	
			for href,episodeID,title in re.findall('<a href="(.+?)".+?id="(.+?)".+?>(.+?)</a>',s):
				href='vietsubhd.com/filmID=%s&EpisodeID=%s'%(filmID,episodeID)
				items.append((href,title))
					
	elif 'hdviet.com' in url:
		url = url.split('/')[1]		
		href='http://movies.hdviet.com/lay-danh-sach-tap-phim.html?id=%s'%url
		response=xfetch(href).json
		if not response:return
		for eps in range(1,int(response["Sequence"])+1):		
			title='%s/%s'%(format(eps,'0%dd'%len(response['Episode'])),str(response['Episode']))
			href='hdviet.com/%s_e%d'%(url,eps)
			items.append((href,title))
			
	elif 'hayhaytv.vn' in url:
		b=re.sub('>\s*<','><',xread(url))
		return re.findall('<a class="ep-link.+?href="(.+?)">(.+?)</a>',b)
				
	elif 'phimnhanh.com' in url :					
		body=xread(url);s=xsearch('(<p class="epi">.+?    </p>)',body,1,re.DOTALL)
		return re.findall(' href="(.+?)" title=".+?">(.+?)</a>',s)

	elif 'hdsieunhanh' in url :					
		content=xread(url)
		s=xsearch('(<ul class="list_episode".+?/ul>)',content,1,re.DOTALL)
		return re.findall('href="(.+?)">(.+?)</a>',s)	
	
	elif 'bilutv' in url:					
		if '/xem-phim/' not in url:
			body=xread(url)
			fanart=xsearch('<img alt=".*?" src="(.+?)"',body)
			url=xsearch('<a href="(.*?/xem-phim/.+?)">',body)
			if 'http://bilutv.com/' not in url:url='http://bilutv.com/'+url
		
		body = xread(url)
		server=xsearch('(<ul class="choose-server">.+?/ul>)',body,1,re.DOTALL)		
		
		if server and re.search('class="list-episode"',body):		
			for href,title in re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server):
				if re.search('Thuyet Minh',no_accent(title)):
					body = xread('http://bilutv.com/'+href)
					s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)					
					return re.findall('href="(.+?)">(.+?)</a>',s)
		elif server:		
			return re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server)			
		
		s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)
		items=re.findall('href="(.+?)">(.+?)</a>',s)
		
	return items
				


																	
class television:
	def detail(self,s):
		title=vnu(xsearch('title="([^"]+?)"',s))
		if not title:title=vnu(xsearch('alt="([^"]+?)"',s))
		label=' '.join(re.findall('<p[^<]*?>(.+?)</p>',s))+title
		dir=True if 'tập' in (title+label).lower() else False
		if xsearch('(\d+/\d+)',label):dir=True;title+=' [COLOR blue]%s[/COLOR]'%xsearch('(\d+/\d+)',label)
		if 'thuyếtminh' in (title+label).replace(' ','').lower():title='[COLOR blue]TM[/COLOR] '+title
		if 'phụđề' in (title+label).replace(' ','').lower():title='[COLOR green]PĐ[/COLOR] '+title
		href=xsearch('href="([^"]+?)"',s)
		if not href:href=xsearch('data-href="(.+?)"',s)
		if 'Đang diễn ra' in s:dir=None
		img=xsearch('src="([^"]+?\.jpg)',s)
		if not img:
			img=xsearch('data-original="([^"]+?\.jpg)',s)
			if not img:img=xsearch('data-original="([^"]+?\.png)',s)
		return title,href,img,dir

	def additems(self,url,page=0):
		items=[]
		content = xread(url)
		if 'htvonline.com.vn' in url:
			for s in [i for i in content.split('<div class="channels_htvc">') if 'view_title2' in i]:
				title=xsearch('<div class="view_title2"><div>(.+?)</div></div>',s).strip()
				title='[COLOR yellow]%s[/COLOR]'%vnu(title)
				items.append((title,'','',False))				
				for title,href,img in re.findall('href="(.+?)" data-original="(.+?)">.+?src="(.+?)"></a>',s):
					title=xsearch('/([\w|-]+)-\d',title).upper()
					items.append((title,href,img,False))
		elif 'fptplay.net/livetv' in url:
			for s in [i for i in content.split('<div id="box_') if ' class="livetv_header' in i]:
				title=xsearch('<span class="livetv_header Regular pull-left" style="margin-right: 7px;">(.+?)</span>',s)
				title='[COLOR yellow]%s[/COLOR]'%vnu(title)
				items.append((title,'','',False))
				for title,href,img,dir in [self.detail(i) for i in re.findall('(<a class="tv_channel.+?/a>)',s,re.S)]:
					items.append((title,href,img,False))		
		return items
		
class Football:			
	def additems(self,url,page=0):
		items=[]
		content = xread(url)
		if 'fullmatchreplay.com' in url:
			for s in [i for i in content.split('<div class="one_third columns item musical isotope-item" style="">') if 'ts-display-pf-img' in i]:
				href=xsearch('href="(.+?)">',s);href='http://fullmatchreplay.com/'+href
				title=xsearch('<span>(.+?)</span>',s).strip()
				view=xsearch('<div class="views">Views: (.+?)</div>',s)
				img=xsearch('src="(.+?)"',s)
				items.append((title,href,img,True))
		elif 'socceryou.com' in url:
			for s in [i for i in content.split('<div class="foto-video">') if 'class="video"' in i]:
				href=xsearch('href="(.+?)"></a>',s);href='http://socceryou.com/en/'+href				
				title=xsearch('title="(.+?)"',s)				
				img=xsearch('src="(.+?)"',s)
				items.append((title,href,img,True))
				 				
		return items
		
	def eps(self,url):
		items=[]	
		content = xfetch(url).body
		log(url)
		if 'fullmatchreplay.com' in url:		
			for href,title in re.findall('href=\'(.+?)\'>(.+?)</a>',content):		
				href='http://fullmatchreplay.com/'+href
				items.append((title,href))
		elif 'socceryou.com' in url:
			#b=xsearch('<div class=\'video_button\'>(.+?)</iframe>',content)
			for href,title in re.findall('href=\'(.+?)\'>(.+?)</a>',content):		
				href='http://socceryou.com/en/'+href
				items.append((title,href))
		
		return items
		
	def getLink(self,url):		
		content=xread(url)
		if 'fullmatchreplay.com' in url:
			id=xsearch('"https://www.youtube.com/embed/(.+?)"',content)
			if id:link='plugin://plugin.video.youtube/?action=play_video&videoid=%s'%id
			else:						
				id=xsearch('videos/v2/(\d+)/zeus',content)
				link='https://config.playwire.com/19004/videos/v2/%s/abr-non-hd.m3u8'%id
		elif 'socceryou.com' in url:
			id=xsearch('"https://www.youtube.com/embed/(.+?)"',content)
			if id:link='plugin://plugin.video.youtube/?action=play_video&videoid=%s'%id
			else:				
				src=xsearch('<iframe src="(.+?)"',content)
				if 'dailymotion.com' in src:				
					notify('Chưa xử lý server dailymotion.com!')
					return ''
				else:
					content=xread(src)				
					link=xsearch('file:	\'(.+?)\'',content)			
		return link

def youtubeDL(url):
	try:import YDStreamExtractor;vid=True
	except:vid=False;mess(u'Cài đặt module youtube.dl để get link phim này')
	if vid:
		vid=YDStreamExtractor.getVideoInfo(url)
		if vid:
			link=xget(vid.streamURL().split('|')[0])
			if link:
				link=link.geturl()
				mess('Xshare get link on Youtube.dl module','Notification')
		else:link=''
	return link		
		
class hdvietnam:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.hdvietnam.com/forums/'}
		self.urlhome='http://www.hdvietnam.com/'
								
	def threads(self,url):
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;|<','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		def srv(link):return [i for i in srvs if i in link]
		#srvs=['fshare.vn','4share.vn','tenlua.vn','subscene.com','phudeviet.org','youtube.com']
		srvs=['fshare.vn', 'docs.google.com']
		items=[]
		def getTitle(title,href,s):
			t=title
			if [i for i in srvs if i in title] or not title:
				title=xsearch('<b>Ðề: (.+?)</b>',s)
				if not title:
					title=' '.join(xsearch('<div style="text-align: center".+?>(\w[^<]+?)<',s).split())
			elif 'download' in title.strip().lower():
				title=xsearch('class="internalLink">([^<]+?)<',s[s.find(href)-500:])
				if not title:title=xsearch('<title>(.+?)</title>',content)
			if not title:title=t
			title=cleans(title)
			return title
		
		content=xread(url,self.hd)
		for s in re.findall('(<li id="post-.+?/li>)',content,re.S):
			img=xsearch('<img src="([^"]+?)" class="',s)
			if not img:img=xsearch('<img src="(.+?jpg)"',s)
			i=s
			while 'header-' in img and 'ogo' not in img:
				i=i[i.find(img)+10:]
				img=xsearch('<img src="(.+?jpg)"',i)
			
			i=re.findall('<a href="([^"]+?)" target="_blank"[^<]+?>(.+?)</a>',s)
			i= [(getTitle(title,href,s),href,img) for href,title in i if srv(href)]
			if i:items+=i
			else:items+=[('',i,img) for i in re.findall('(http[\w|:|/|\.|\?|=|&|-]+)',s.replace('amp;','')) if srv(i)]
			
		temp=[];list=[]
		for i in items:
			if i[1] not in temp:temp.append(i[1]);list.append(i)
		return list

################
	
def DownloadDB(query='phim-le',server='megabox',page=1,page_max=1,update_db=False):
	filename='2@%s_%s.xml'%(query,server)
	content_old=makerequest(joinpath(datapath,filename))
	#href_old=re.findall('"url":"(.+?)",',content_old)
	href_old=re.findall('titleEn="(.*?)" year="(.*?)"',content_old)

	items=[];list=[]
	while page <= page_max:				
		if page_max != page:notify(u'Đang tiến hành download trang %d'%(page),timeout=5000)
		if server=='megabox':			
			url = 'http://phim.megabox.vn/%s/trang-%d'%(query,page)
		elif server=='phimmoi':						
			url='http://www.phimmoi.net/%s/page-%d.html'%(query,page)			
		elif server=='phimnhanh':						
			url = 'http://phimnhanh.com/%s?page=%d'%(query,page)				
		elif server=='vaphim':
			v_query = 'series' if query=='phim-bo' else query		
			url='http://vaphim.com/category/phim-2/%s/page/%d/'%(v_query,page)			
				
		elif server=='fsharefilm':
			if page==1:url = 'http://fsharefilm.com/chuyen-muc/phim/'
			else:url = 'http://fsharefilm.com/chuyen-muc/phim/page/%d/'%page
				
		elif server=='hdonline':
			url = 'http://hdonline.vn/danh-sach/%s/trang-%d.html'%(query,page)				
		elif server=='hdviet':
			url = 'http://movies.hdviet.com/%s/trang-%d.html'%(query,page)							
		elif server=='fcine':						
			url='http://fcine.net/?page=%d&listResort=1'%(page)
		elif server=='phimbathu':						
			url='http://phimbathu.com/danh-sach/%s.html?page=%d'%(query,page)
		elif server=='bilutv':						
			url='http://bilutv.com/danh-sach/%s.html?page=%d'%(query,page)
		elif server=='vietsubhd':						
			url='http://www.vietsubhd.com/%s/trang-%d.html'%(query,page)
		elif server=='hdsieunhanh':						
			url='http://www.hdsieunhanh.com/%s.html&page=%d'%(query,page)

		elif server=='pubvn':					
			url='http://pubvn.net/phim/%s/32-1-2/trang%d.html'%(query,page)

		elif server=='xemphimbox':					
			url='http://xemphimbox.com/%s/trang-%d.html'%(query,page)
			
		items+=additems2(url,0,page)
			
		page+=1		
	####	
	if items:
		contents='<?xml version="1.0" encoding="utf-8">\n';check=0
		#for id,title,theloai,tag,titleEn,year,info in [s for s in items if json.dumps(s[4]).replace('/','\/').replace('"','') not in href_old]:
		for id,title,theloai,tag,titleEn,year,info in [s for s in items if (fixString(s[4]),s[5]) not in href_old]:
			titleVn=fixString(title);titleEn=fixString(titleEn);title=titleVn+'[]'+(titleEn if titleEn else titleVn)
			check+=1
			category='';parent=theloai
		
			content='<a id="%s" category="%s" parent="%s" tag="%s" titleEn="%s" year="%s" title="%s">%s</a>\n'			
			content=content%(id,category,parent,tag,titleEn if titleEn else titleVn,year,title,info);contents+=content
			
			if update_db:list.append((id,category,parent,tag,titleEn if titleEn else titleVn,year,title,info))
		
		v_query='Phim lẻ' if query=='phim-le' else 'Phim bộ'
		if check:			
			contents+=content_old.replace('<?xml version="1.0" encoding="utf-8">\n','')
			if makerequest(joinpath(datapath,filename),contents,'w'):
				notify(u'Đã cập nhật được %d phim'%check,u'%s - %s'%(v_query,eval("www['"+server+"']")))
			else: notify(u'Đã xảy ra lỗi cập nhật!',u'%s - %s'%(v_query,eval("www['"+server+"']")))
		else:notify(u'Không có phim mới...',u'%s - %s'%(v_query,eval("www['"+server+"']")))
		
	return list
		
def UpdateDB3(query,server,pages):		
	filename_new='2@%s_%s.xml'%(query,server)
	content_new=makerequest(joinpath(datapath,filename_new))		
	r='<a id="(.*?)" category="(.*?)" parent="(.+?)" tag="(.*?)" titleEn="(.*?)" year="(.*?)" title="(.+?)">(.+?)</a>'
	items=re.findall(r,content_new)
	
	contents=''
	page=1;no=1
	for id,category,parent,tag,titleEn,year,title,info in items:
		if no>pages:page+=1;no=1			
		
		j = json.loads(info)				
		for i in j["href"]:				
			href=u2s(i["url"])
		
		if True:
			id = u2s(j.get("id"));
			v_href=''
			for i in j["href"]:				
				if server=='phimmoi':id=xsearch('-(\d+?)\/',u2s(i["url"]))
				else:id=xsearch('-(\d+?)\.html',u2s(i["url"]))

				v_url='{"label":"","url":'+json.dumps(u2s(i["url"]))+',"subtitle":'+json.dumps(u2s(i["subtitle"]))+'}'
				if v_href:v_href+=','+v_url
				else:v_href=v_url
			
			rating = u2s(j.get("rating"));plot = u2s(j.get("plot"))
			episode = u2s(j.get("episode"));director = u2s(j.get("director"));writer = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
			duration = u2s(j.get("duration"));thumb = u2s(j.get("thumb"))
				
			info='{'
			info+='"id":"'+server+'-'+id+'"'
			info+=',"href":['+v_href+']'
			info+=',"titleVn":'+json.dumps(u2s(j.get("titleVn")))		
			info+=',"titleEn":'+json.dumps(u2s(j.get("titleEn")))
			info+=',"country":'+json.dumps(country)
			info+=',"genre":'+json.dumps(genre)
			info+=',"year":'+json.dumps(u2s(j.get("year")))
			info+=',"writer":'+json.dumps(writer)
			info+=',"director":'+json.dumps(director)
			info+=',"duration":'+json.dumps(duration)
			info+=',"thumb":'+json.dumps(thumb)
			info+=',"rating":'+json.dumps(rating)				
			info+=',"episode":'+json.dumps(episode)				
			info+=',"plot":'+json.dumps(plot)
			info+='}'
			info=info.replace('/','\/')				
		
		id='%03d'%page		
		content='<a id="%s" category="%s" parent="%s" tag="%s" titleEn="%s" year="%s" title="%s">%s</a>\n'			
		content=content%(id,category,parent,tag,titleEn,year,title,info);contents+=content
		no+=1
		
	contents='<?xml version="1.0" encoding="utf-8">\n'+contents			
	filename='2@%s_%s.xml'%(query,server)
	makerequest(joinpath(datapath,filename),contents,'w')				
						
def UpdateDB2(query,server,page=1,list=[],updown='up'):
	content_old=makerequest(joinpath(datapath,'2@%s_movie.xml'%query))		
	#href_old=re.findall('titleEn="(.*?)" year="(.*?)"',content_old)
	href_old=re.findall('year="(.*?)" title=".*\[\](.*?)"',content_old)#titleEn
	href_old2=re.findall('year="(.*?)" title="(.*?)\[\].*"',content_old)#titleVn	
			
	if not list:
		filename_new='2@%s_%s.xml'%(query,server)
		content_new=makerequest(joinpath(datapath,filename_new))	
		if page:r='<a id="(%03d)" category="(.*?)" parent="(.+?)" tag="(.*?)" titleEn="(.*?)" year="(.*?)" title="(.+?)">(.+?)</a>'%(page)
		else:r='<a id="(.*?)" category="(.*?)" parent="(.+?)" tag="(.*?)" titleEn="(.*?)" year="(.*?)" title="(.+?)">(.+?)</a>'
		items=re.findall(r,content_new)
	else:items=list
	
	contents=''
	if items:
		for id,category,parent,tag,titleEn,year,title,info in [s for s in items if (s[5],s[6].split('[]')[1]) not in href_old and (s[5],s[6].split('[]')[0]) not in href_old2]:
			j = json.loads(info)				
			for i in j["href"]:				
				href=u2s(i["url"])
			
			titleVn = u2s(j.get("titleVn"));titleEn = u2s(j.get("titleEn"));year = u2s(j.get("year"))

			if False:
				id = u2s(j.get("id"));
				v_href=''
				for i in j["href"]:				
					if server=='phimmoi':id=xsearch('-(\d+?)\/',u2s(i["url"]))
					else:id=xsearch('-(\d+?)\.html',u2s(i["url"]))

					v_url='{"label":"","url":'+json.dumps(u2s(i["url"]))+',"subtitle":'+json.dumps(u2s(i["subtitle"]))+'}'
					if v_href:v_href+=','+v_url
					else:v_href=v_url
				
				rating = u2s(j.get("rating"));plot = u2s(j.get("plot"))
				episode = u2s(j.get("episode"));director = u2s(j.get("director"));writer = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
				duration = u2s(j.get("duration"));thumb = u2s(j.get("thumb"))
					
				info='{'
				info+='"id":"'+server+'-'+id+'"'
				info+=',"href":['+v_href+']'
				info+=',"titleVn":'+json.dumps(titleVn)		
				info+=',"titleEn":'+json.dumps(titleEn)
				info+=',"country":'+json.dumps(country)
				info+=',"genre":'+json.dumps(genre)
				info+=',"year":'+json.dumps(year)
				info+=',"writer":'+json.dumps(writer)
				info+=',"director":'+json.dumps(director)
				info+=',"duration":'+json.dumps(duration)
				info+=',"thumb":'+json.dumps(thumb)
				info+=',"rating":'+json.dumps(rating)				
				info+=',"episode":'+json.dumps(episode)				
				info+=',"plot":'+json.dumps(plot)
				info+='}'
				info=info.replace('/','\/')		
				
				titleVn = fixString(titleVn);titleEn = fixString(titleEn)
				title = titleVn + '[]' + titleEn if titleEn else titleVn						
				continue
			
			id='%03d'%page		
			content='<a id="%s" category="%s" parent="%s" tag="%s" titleEn="%s" year="%s" title="%s">%s</a>\n'			
			content=content%(id,category,parent,tag,titleEn if titleEn else titleVn,year,title,info);contents+=content
							
	if contents:			
		content_old=content_old.replace('<?xml version="1.0" encoding="utf-8">\n','')
		if not page or updown=='up':#page=0 lay tat ca 
			contents+=content_old
		else:
			contents=content_old+contents

		contents='<?xml version="1.0" encoding="utf-8">\n'+contents			
		filename='2@%s_movie.xml'%query
		makerequest(joinpath(datapath,filename),contents,'w')				
		
	#content_new=content_new.replace('id="%03d"'%page,'id="ok"')
	#makerequest(joinpath(datapath,filename_new),content_new,'w')			
		

		
#['hdonline',21:397/152 ,'phimmoi',30:92/50 , ' phimnhanh:504 ] 'hdsieunhanh',30:203/70  	pubvn: 245	'xemphimbox',24:104/40
#phimbathu:125/81	bilutv:70/68	vietsubhd:275/54	, '#xuongphim:55/39'
#'vaphim',32:222/69, 'fsharefilm' 57, fcine:162 

#DownloadDB2('phim-le',page=1,page_max=1)
#exec(xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'%s.py'%base64.b64decode(x0x0x0x0)))
	
query='phim-bo'
#UpdateDB3(query,'phimmoi',30)

#DownloadDB(query,'hdonline',1,1)
#UpdateDB2('phim-le','hdonline',0,[],'down')		
if False:						
	page_max=2;updateDB=True
	while page_max > 0:
		list=[]
		for s in ['hdonline', 'pubvn', 'phimmoi', 'hdsieunhanh']:
		#['phimbathu', 'bilutv', 'vietsubhd', 'fcine']:
		#['hdonline', 'pubvn', 'phimmoi', 'hdsieunhanh']:
			notify(u'%s / %d '%(s,page_max))
			list+=DownloadDB(query,s,page_max,page_max,updateDB)			
			
		if updateDB:UpdateDB2(query,s,page_max, list, 'up')
		
		page_max-=1					

if False:	
	filename='2@%s_movie.xml'%query
	contents='<?xml version="1.0" encoding="utf-8">\n'
	#makerequest(joinpath(datapath,filename),contents,'w')					
	
	page=1;page_max=146
	while page <= page_max:
		for s in ['hdonline','phimmoi']:
		#for s in ['hdonline','hdsieunhanh','xemphimbox','pubvn']:			
			notify(u'Đang cập nhật dữ liệu...%s-%d'%(s,page),query,timeout=5000)
			UpdateDB2(query,s,page,[],'down')			
	
		page+=1

	
def getLink2(url):
	def string_encrypt(key, str):
		str = str.decode("base64");ll=0;x=out='';s=range(0,256)
		for kk in range(0,256):
			ll = (ll + s[kk] + ord(key[kk % len(key)])) % 256
			x = s[kk]
			s[kk] = s[ll]
			s[ll] = x
		kk=ll=0
		for y in range (0, len(str)):
			kk = (kk + 1) % 256
			ll = (ll + s[kk]) % 256
			x = s[kk]
			s[kk] = s[ll]
			s[ll] = x
			out += chr(ord(str[y])^s[(s[kk] + s[ll]) % 256])
		return out

	user = myaddon.getSetting('sctv_user')
	password = myaddon.getSetting('sctv_pass')
	channelid = re.search(re.compile(r"\/(\d+)\/"), url).group(1)
	response = urlfetch.get(url)
	if not response:
		notify('Kiểm tra nguồn phát tại [COLOR red]tv24h.vn[/COLOR] và báo cho người phát triển.')
		return
	cookie=response.cookiestring;
	matches = re.search(r'\"channel_token\" value=\"(.+?)\"', response.body)
	channeltoken = matches.group(1)
	signin_url = 'http://tv24.vn/client/login/process'
	headers = {'Host': 'tv24.vn', 'Accept-Encoding': 'gzip, deflate, compress, identity, *', 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0', 'Cookie': cookie, 'Referer': 'http://web.tv24.vn/dang-nhap'}
	data = {'mobile': user, 'password': password}
	urlfetch.post(signin_url, headers=headers, data=data)
	data = {'channel_id': channelid, 'channel_token': channeltoken}
	response = urlfetch.post('http://tv24.vn/client/channel/link', headers=headers, data=data)
	if 'null' in response.body:
		if len(user) == 0  or len(password) == 0:
			sleep(1)
			alert(u'Bạn hãy đăng ký tài khoản trên web [COLOR red]http://tv24.vn[/COLOR] và nhập trong Setting của Addon VMF'.encode("utf-8"))
	else:
		json_data = json.loads(response.body)
		video_url = json_data['data']['PLAY_URL']
		#notify("Đang getlink")
		video_url = string_encrypt(channeltoken, video_url)
		sleep(5)
		return video_url,''