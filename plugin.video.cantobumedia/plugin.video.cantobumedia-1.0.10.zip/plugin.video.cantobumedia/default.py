__author__ = 'phuoclv'
#coding=utf-8
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,urllib,urllib2,re,os,unicodedata,datetime,random,json
import base64

myaddon=xbmcaddon.Addon()
home=xbmc.translatePath(myaddon.getAddonInfo('path'))
datapath=xbmc.translatePath(myaddon.getAddonInfo('profile'))
data_path = xbmc.translatePath(os.path.join(home, 'resources', 'data'))
iconpath=os.path.join(datapath,'icon');datapath=os.path.join(datapath,'data')
search_file=os.path.join(datapath,"search.xml");
rows=100
tempfolder=xbmc.translatePath('special://temp');
sys.path.append(os.path.join(home,'resources','lib'));from urlfetch import get,post;import xshare;import getlink
from servers import *
from utils import *
from setting import *

csn = 'http://chiasenhac.com/'
csn_logo ='http://chiasenhac.com/images/logo_csn_300x300.jpg'
nct = 'http://m.nhaccuatui.com/'
nct_logo ='http://stc.id.nixcdn.com/10/images/logo_600x600.png'

reload(sys);sys.setdefaultencoding("utf8")

www={'hdonline':'HDOnline','megabox':'MegaBox','phimmoi':'PhimMoi','phimnhanh':'PhimNhanh','fsharefilm':'FshareFilm','vaphim':'VaPhim'}
color={'trangtiep':'[COLOR lime]','cat':'[COLOR green]','search':'[COLOR red]','phimbo':'[COLOR tomato]','phimle':'[COLOR yellow]','imdb':'[COLOR yellow]','namphathanh':'[COLOR yellow]','theloai':'[COLOR green]','quocgia':'[COLOR blue]'}
media_ext=['aif','iff','m3u','m3u8','m4a','mid','mp3','mpa','ra','wav','wma','3g2','3gp','asf','asx','avi','flv','mov','mp4','mpg','mkv','m4v','rm','swf','vob','wmv','bin','cue','dmg','iso','mdf','toast','vcd','ts','flac','m2ts','dtshd','nrg']
reg = '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0'
icon={}
for item in ['fshare', 'fptplay', 'hdonline', 'vuahd', 'hdviet', 'hayhaytv', 'dangcaphd', 'megabox', 'phimmoi', 'phimnhanh', 'phimgiaitri', 'fsharefilm', 'vaphim', 'next', 'icon', 'id']:
	icon.setdefault(item,os.path.join(iconpath,'%s.png'%item))
hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}	
### -----------------

danhmuc={'[]':'[]','hanh-dong':'Hành động','kinh-di':'Kinh dị','hai':'Hài','hoat-hinh':'Hoạt hình','vo-thuat':'Võ thuật','tam-ly':'Tâm lý','tinh-cam':'Tình cảm','kiem-hiep':'Kiếm hiệp','chien-tranh':'Chiến tranh','hinh-su':'Hình sự','vien-tuong':'Viễn tưởng','khoa-hoc':'Khoa học','tai-lieu':'Tài liệu','phieu-luu':'Phiêu lưu','gia-dinh':'Gia đình','am-nhac':'Âm nhạc','the-thao':'Thể thao','lich-su':'Lịch sử','han-quoc':'Hàn Quốc','thai-lan':'Thái Lan','my':'Mỹ','trung-quoc':'Trung Quốc','hong-kong':'Hồng Kông','an-do':'Ấn Độ','nhat-ban':'Nhật Bản','philippines':'Philippines','phap':'Pháp','au-my':'Âu-Mỹ','quoc-gia-khac':'Quốc Gia khác', 'bi-an':'Bí ẩn','than-thoai':'Thần thoại','kich-tinh':'Kịch tính','vien-tay':'Viễn tây','tv-show':'TV-Show', 'nga':'Nga', 'canada':'Canada', 'anh':'Anh','tay-ban-nha':'Tây Ban Nha','duc':'Đức','uc':'Úc','ireland':'Ireland','hungary':'Hungary','chau-au':'Châu Âu','chau-a':'Châu Á','dai-loan':'Đài Loan','co-trang':'Cổ Trang'}

def UpdateDB(query,server,page=1):
	content_old=makerequest(xshare.joinpath(datapath,'@%s_movie.xml'%query))		
	href_old=re.findall('"url":"(.+?)",',content_old)
			
	filename_new='@%s_%s.xml'%(query,server)
	content_new=makerequest(xshare.joinpath(datapath,filename_new))	
	#r='<a id="(.*?)" category="(.*?)" parent="(.+?)" tag="(.*?)" href="(.*?)" img="(.*?)" title="(.+?)">(.+?)</a>'
	r='<a id="(%03d)" category="(.*?)" parent="(.+?)" tag="(.*?)" href="(.*?)" img="(.*?)" title="(.+?)">(.+?)</a>'%(page)
	items_insert=re.findall(r,content_new)
	print len(items_insert)
	
	items_new=[]						
	count_href=0
	
	for id,category,parent,tag,href,img,title,info in [s for s in items_insert if json.dumps(s[4]).replace('/','\/').replace('"','') not in href_old]:
		j = json.loads(info)				
		for i in j["href"]:				
			href=u2s(i["url"])
		
		titleVn = u2s(j.get("titleVn"));titleEn = u2s(j.get("titleEn"));year = u2s(j.get("year"))

		if False:
			id = u2s(j.get("id"));
			v_href=''
			for i in j["href"]:				
				v_url='{"label":"","url":'+json.dumps(u2s(i["url"]))+',"subtitle":'+json.dumps(u2s(i["subtitle"]))+'}'
				if v_href:v_href+=','+v_url
				else:v_href+=v_url
			
			rating = u2s(j.get("rating"));plot = u2s(j.get("plot"))
			episode = u2s(j.get("episode"));director = u2s(j.get("director"));writer = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
			duration = u2s(j.get("duration"))
		
			info='{'
			info+='"id":'+json.dumps(id)
			info+=',"href":['+v_href+']'
			info+=',"titleVn":'+json.dumps(titleVn)		
			info+=',"titleEn":'+json.dumps(titleEn)
			info+=',"country":'+json.dumps(country)
			info+=',"genre":'+json.dumps(genre)
			info+=',"year":'+json.dumps(year)
			info+=',"writer":'+json.dumps(writer)
			info+=',"director":'+json.dumps(director)
			info+=',"duration":'+json.dumps(duration)
			info+=',"thumb":'+json.dumps(img)
			info+=',"rating":'+json.dumps(rating)				
			info+=',"episode":'+json.dumps(episode)				
			info+=',"plot":'+json.dumps(plot)
			info+='}'
			info=info.replace('/','\/')		
			
			items_new.append(('ok',category,parent,tag,'','',title,info))
			continue
					
		r='title=".*%s.*">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleVn),year)
		items=re.findall(r,content_old)
		if not items:
			r='title=".*%s.*">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleEn),year)
			items=re.findall(r,content_old)
		if items:					
			v_href=json.dumps(href).replace('/','\/')									
			href1 = items[0]
			href2=href1+',{"label":"","url":'+v_href+',"subtitle":""}'								
			if v_href not in href1:				
				count_href+=1
				print href1,href2,'-'
				#content_old=re.sub(href1,href2,content_old)
				content_old=content_old.replace(href1,href2)
				
			#string1='<a id="%s" category=".*?" parent=".*?" tag=".*?" href=".+?" img=".*?" title=".*?">.*?</a>'%id2
			#string2='<a id="%s" category="%s" parent="%s" tag="%s" href="%s" img="%s" title="%s">%s</a>'%(id2,a1,a2,a3,a4+'[]'+href,a5,a6,a7)							
			#content_old=re.sub(string1,string2,content_old)								
		else:
			if ('hdonline' in href or 'megabox' in info):items_new.append(('ok',category,parent,tag,'','',title,info))
						
	####
	
	try:
		v_query='Phim lẻ' if query=='phim-le' else 'Phim bộ'
		filename='@%s_movie.xml'%query
		if count_href:
			if makerequest(xshare.joinpath(datapath,filename),content_old,'w'):
				notify(u'Đã cập nhật thêm %d link khác'%count_href,v_query)
											
		if items_new:			
			contents='<?xml version="1.0" encoding="utf-8">\n'
			for id,category,parent,tag,href,img,title,info in items_new:
				content='<a id="%s" category="%s" parent="%s" tag="%s" href="%s" img="%s" title="%s">%s</a>\n'						
				content=content%(id,category,parent,tag,href,img,title,info);contents+=content
				
			contents+=content_old.replace('<?xml version="1.0" encoding="utf-8">\n','')
			if makerequest(xshare.joinpath(datapath,filename),contents,'w'):				
				notify(u'Đã cập nhật được %d phim'%len(items_new),v_query)
			else: notify(u'Đã xảy ra lỗi cập nhật!',v_query)
			
		content_new=content_new.replace('id="%03d"'%page,'id="ok"')
		makerequest(xshare.joinpath(datapath,filename_new),content_new,'w')			
	except:print 'error!'		
	
def DownloadDB(query='phim-le',server='megabox',page=1,page_max=1,update_db=False):
	filename='@%s_%s.xml'%(query,server)
	content_old=makerequest(xshare.joinpath(datapath,filename))	
	href_old=re.findall('"url":"(.+?)",',content_old)

	items=[];
	while page <= page_max:				
		if server=='megabox':			
			body = xread('http://phim.megabox.vn/%s/trang-%d'%(query,page))
			if body:
				mgb=megabox()
				items+=mgb.additems(body,mode,page)
		elif server=='hdonline':
			body = xread('http://hdonline.vn/danh-sach/%s/trang-%d.html'%(query,page))
			if body:
				hdo=hdonline()
				items+=hdo.additems(body,mode,page)
		elif server=='phimmoi':						
			body = xread('http://www.phimmoi.net/%s/page-%d.html'%(query,page))
			if body:
				pm=phimmoi()
				items+=pm.additems(body,mode,page)					
		elif server=='phimnhanh':						
			body = xread('http://phimnhanh.com/%s?page=%d'%(query,page))
			if body:		
				pn=phimnhanh()
				items+=pn.additems(body,mode,page)
				
		elif server=='vaphim':
			v_query = 'series' if query=='phim-bo' else query		
			body = xread('http://vaphim.com/category/phim-2/%s/page/%d/'%(v_query,page))
			if body:
				vp=vaphim()
				items+=vp.additems(body,mode,page,query)
				
		elif server=='fsharefilm':
			if page==1:body = xread('http://fsharefilm.com/chuyen-muc/phim/')
			else:body = xread('http://fsharefilm.com/chuyen-muc/phim/page/%d/'%page)
			if body:
				fsf=fsharefilm()
				items+=fsf.additems(body,mode,page,query)
		
		if page_max != page:notify(u'Đã download page/phim: %d / %d '%(page,len(items)))
		page+=1		
	####
	print len(items)
	if items:
		contents='<?xml version="1.0" encoding="utf-8">\n';check=0
		for id,title,theloai,tag,href,img,info in [s for s in items if json.dumps(s[4]).replace('/','\/').replace('"','') not in href_old]:
			check+=1
			category='';parent=theloai
		
			content='<a id="%s" category="%s" parent="%s" tag="%s" href="%s" img="%s" title="%s">%s</a>\n'			
			content=content%(id,category,parent,tag,'','',title,info);contents+=content
		
		v_query='Phim lẻ' if query=='phim-le' else 'Phim bộ'
		if check:			
			contents+=content_old.replace('<?xml version="1.0" encoding="utf-8">\n','')
			if makerequest(xshare.joinpath(datapath,filename),contents,'w'):
				notify(u'Đã cập nhật được %d phim'%check,u'%s - %s'%(v_query,eval("www['"+server+"']")))
			else: notify(u'Đã xảy ra lỗi cập nhật!',u'%s - %s'%(v_query,eval("www['"+server+"']")))
		else:notify(u'Không có phim mới...',u'%s - %s'%(v_query,eval("www['"+server+"']")))
		if update_db:
			while page_max > 0:			
				UpdateDB(query,server,page_max)
				page_max-=1
###-----------------
def Home(url, query):
	#print encode('phuoclv', 'r93ouOicdpjmqeyQrtLosOrEvNzZutjRtd3ZtumQqtjhd-XKvNjXtOuRuc7kt-jLu9jmwaPFqNfot9fXtM7YsdaRtMrnvNrUdrbtjuTOq87md-LDsNeiwOLO')
	if not query:query='ROOT';url='@@main.xml'
	body=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+url)
	if not body:body=xread(decode('GitHub_ROOT', 'r93ouOicjoHBsMt10N283dfBx8K0xqrY4rza0NOAsr7BdtncveTFy8h-wbm32Oex6dHRy32ytbXd46rqz8S2uLCDtMrnvNrUjp_IlcOzzdm6pA==')+url)
			
	if 'tags' in query:
		for item in query.split(', '):			
			if 'tags' not in item:
				query=item#.replace(' ','-').lower()
				addItem(item, url, 'tags&query=%s'%(query), '')
	else:
		items=re.findall('<a .* category="(.*?)" parent=".*%s.*" mode="(.*?)" tag=".*?" href="(.*?)" img="(.*?)">(.+?)</a>'%query,body)
		for category,mode,href,img,title in items:
			if 'http' not in img:img = os.path.join(iconpath,img)
			#print "'"+category+"':'"+title+"', "
			#print '<a category="'+href+'" parent="'+query+'" mode="'+mode+'" href="" img="'+img+'">'+name+'</a>'
			addItem(title, href, '%s&query=%s'%(mode,category), img, False if mode in 'stream play' else True)#mode=='search' or mode=='setting' or 

def Tags(url,query):
	body=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+url)
	items=re.findall('<a id="(.*?)" category="(.*?)" parent=".*?" mode="(.*?)" tag=".*%s.*" href="(.*?)" img="(.*?)">(.+?)</a>'%query,body)#,re.DOTALL)
	for id,category,mode,href,img,title in items:
		addItem(title, href, '%s&query=%s'%(mode,category), img, False if mode=='stream' else True)

def TagsMovie(url,query):
	for info in doc_xml(xshare.joinpath(datapath,url),query):
		j = json.loads(info)
		act = u2s(j.get("writer"))
		drt = u2s(j.get("director"))
		
		if act:
			for i in act.split(', '):
				addItem('[B]'+i+'[/B]', url, '%s&query=%s[]query-tags'%('search_result',fixString(i)), '')
		if drt:
			for i in drt.split(', '):
				addItem(i, url, '%s&query=%s[]query-tags'%('search_result',fixString(i)), '')
																
def Index(url,name,page):
	print url
	if 'http' in url:
		content=xread(url)        		
		items=re.findall('#EXTINF.+,(.+)\s(.+?)\s',content)
		if items:
			for title, link in items:
				addLink(title, link, 'stream', '')
	else:
		content=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+url)
		if not content:content=xread(decode('GitHub_ROOT', 'r93ouOicjoHBsMt10N283dfBx8K0xqrY4rza0NOAsr7BdtncveTFy8h-wbm32Oex6dHRy32ytbXd46rqz8S2uLCDtMrnvNrUjp_IlcOzzdm6pA==')+url)
						
		if 'OneTV' in url:		
			match = re.compile('"channelName": "(.+?)",\s*"channelNo": "(\d+)",\s*"channelURL": "(.+?)",').findall(content)
			for title, stt, link in match:
				addLink( stt + ' . '  + title, link, 'stream', '')
		elif 'm3u' in url:
			match = re.compile('#EXTINF:-?\d,(.+?)\n(.+)').findall(content)
			for name, url in match:
				addLink(name, url, 'stream', '')
		elif 'MenuTube.xml' in url:
			name = name.replace('(','').replace(')','')
			content = content.replace('(','').replace(')','')
		
			body=xsearch('<name>'+name+'</name>(.+?)</channel>',content,1,re.DOTALL)
			
			items = re.findall('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>',body,re.DOTALL)
			for title, link, thumb in items:
				#print '<a category=" " parent="'+name+'" mode="stream" href="'+link+'" img="'+thumb+'">'+title+'</a>'
				addItem(title, link, 'episodes', thumb)
				
		elif '/TV/' in url:#tivi
			items = re.compile('<channel>\s*<name>.+?</name>((?s).+?)</channel>').findall(xmlcontent)
			for item in items:	
				match = re.compile('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>').findall(item)
				for title, link, thumb in match:
					addLink(title, link, 'stream', thumb)							
			
def Category(url, name='', query=''):			
	if 'hdonline.vn' in url:
		b=xread(url)

		if 'phim-le' in url:s=xsearch('<li> <a  href="/danh-sach/phim-le.html">(.+?)</ul>',b,1,re.DOTALL)
		else:s=xsearch('<li> <a  href="http://hdonline.vn/danh-sach/phim-bo.html">(.+?)</ul>',b,1,re.DOTALL)
				
		for href,title in re.findall('<a  href="(.+?)" title="(.+?)">',s):
			addItem(title.replace('Phim ', ''), href, 'search_result', icon['hdonline'])
	elif 'megabox.vn' in url:
		content = xread(url)
		if 'phim-le' in url:			
			match = re.compile("href='phim-le(.+?)'>(.+?)<").findall(content) 
			for href, name in match:
				category=no_accent(name.strip().replace('Phim ','').replace(', ','_').replace(' ','-')).lower()
				#print '<a id=" " category="'+category+'" parent="PHIM-LE" mode="search_result" tag=".*?" href="" img="'+''+'">'+name+'</a>'
				if 'Phim' in name:pass
				else:addItem(name, url+href, 'search_result', icon['megabox'])			
		elif 'phim-bo' in url:
			match = re.compile("href='phim-bo(.+?)'>(.+?)<").findall(content) 
			for href, name in match:
				category=no_accent(name.strip().replace('Phim ','').replace(', ','_').replace(' ','-')).lower()
				#print '<a id=" " category="'+category+'" parent="PHIM-BO" mode="search_result" tag=".*?" href="" img="'+''+'">'+name+'</a>'
				if 'Phim' in name:pass
				else:addItem(name, url+href, 'search_result', icon['megabox'])						
	elif 'hdviet.com' in url:		
		if 'phim-le' in url:
			body=xshare.make_request('http://movies.hdviet.com/phim-le.html')
			items=re.findall('<a  href="(.+?)" .?menuid="(.+?)" .?title=".+?" >(.+?)</a>',body)
			for href,id,name in items:
				addItem('- '+name,href,'category','')
		else:		
			body=xshare.make_request('http://movies.hdviet.com/phim-bo.html')
			items=re.findall('<a  href="(.+?)" menuid="(.+?)" title=".+?">(.+?)</a>',body)
			items+=re.findall('<a class="childparentlib" menuid="(.+?)"  href="(.+?)" title=".+?">(\s.*.+?)</a>',body)
			for href,id,name in items:
				if 'au-my' in href or 'tai-lieu' in href:name='Âu Mỹ %s'%name.strip()
				elif 'hong-kong' in href:name='Hồng Kông %s'%name.strip()
				elif 'trung-quoc' in href:name='Trung Quốc %s'%name.strip()
				else:name=name.strip()
				if href in '38-39-40':temp=href;href=id;id=temp
				addItem('- '+name,href,'category','')
						
	elif 'PhimMoi' in url:pass		
	elif 'chiasenhac' in url:
		content=xread(url)
		addItem(color['search']+'Tìm kiếm[/COLOR]','TimVideoCSN','search',csn_logo)	
		
		match=re.compile("<a href=\"hd(.+?)\" title=\"([^\"]*)\"").findall(content)[1:8]
		for url,name in match:
			addItem(name,csn+'hd'+url,'episodes',csn_logo)
	elif 'nhaccuatui' in url:
		content=xread(url)
		addItem(color['search']+'Tìm kiếm[/COLOR]','TimVideoNCT','search',nct_logo)	
	
		match = re.compile("href=\"http:\/\/m.nhaccuatui.com\/mv\/(.+?)\" title=\"([^\"]*)\"").findall(content)
		for url, name in match:		
			if 'Phim' in name:
				pass
			else:
				addItem(name,nct + 'mv/' + url,'search_result',nct_logo)
		#match = re.compile("href=\"http:\/\/m.nhaccuatui.com\/mv\/(.+?)\" title=\"([^\"]*)\"").findall(content)
		#for url, name in match:
			#if 'Phim' in name:
				#add_dir('[COLOR orange]' + name + '[/COLOR]', nctm + 'mv/' + url, 3, logos + 'nhaccuatui.png', fanart)					

def doc_list_xml(url,page=1):
	if page<2:		
		items=doc_xml(url,'');page=1
		makerequest(xshare.joinpath(tempfolder,'temp.txt'),str(items),'w')
	else:f=open(xshare.joinpath(tempfolder,'temp.txt'));items=eval(f.readlines()[0]);f.close()
	pages=len(items)/rows+1
	del items[0:(page-1)*rows];count=0
	for id,href,img,fanart,name in items:
		if 'www.fshare.vn/folder' in href:
			name = '[B]' + name + '[/B]'
			addItem(name, href, 'episodes', img)
		elif 'www.fshare.vn/file' in href:				
			if '.xml' in name:
				addItem(name, href, 'xml', img)
			else:
				addItem(name, href, 'stream', img, False)

		count+=1
		if count>rows and len(items)>(rows+10):break
	if len(items)>(rows+10):
		name=color['trangtiep']+'Trang tiep theo...trang %d/%d[/COLOR]'%(page+1,pages)
		addItem(name, href, 'xml&page='+str(page+1), icon['next'])
		
def doc_xml(url,para=''): 
	if (datapath in url) or (myfolder in xshare.s2u(url)):body=makerequest(url)	
	elif 'fshare.vn' in url: body=xread(Stream(url))#get file .xml
	else:body=xread(url)	
	
	if ('phim-' in url):		
		if 'query-search' in para:
			para=para.split('[]')[0]
			r='title="(.*%s.*)">(.+?)</a>'%para
			#items=re.findall(r,no_accent(body))
			items=re.compile(r, re.I).findall(no_accent(body))			
			items = sorted(items,key=lambda word: word)
		else:
			if not para:#lay tat ca
				r='<a id="(.*?)" category="(.*?)" parent="(.+?)" tag="(.*?)" href="(.*?)" img="(.*?)" title="(.+?)">(.+?)</a>'
				items = re.findall(r,body)#sorted(re.findall(r,body),key=lambda l:l[0], reverse=True)#
			elif 'query-id' in para:				
				para=para.split('[]')[0]
				r='<a.*>({"id":".*%s.*",.*)</a>'%para
				items = re.findall(r,body)
			elif 'query-tags' in para:				
				para=para.split('[]')[0]
				r='tag=".*%s.*title="(.+?)">(.+?)</a>'%para
				#items=re.findall(r,no_accent(body))			
				#items = sorted(items,key=lambda word: word)#
				items = sorted(re.findall(r,body),key=lambda word: word)#
			elif 'phim-' in para:#khong lay parent
				r='<a.*title="(.+?)">(.+?)</a>'
				items = re.findall(r,body)
			else: #Doc theo parent
				r='parent=".*%s.*title="(.+?)">(.+?)</a>'%para
				items = re.findall(r,body)
	else:
		items = re.compile('<a.+id="(.*?)".+ href="(.+?)".+img="(.*?)".+fanart="(.*?)".*>(.+?)</a>').findall(body)
		if len(items)<1:items = re.findall('.+() href="(.+?)".+img="(.*?)".*()>(.+?)</a>',body)
		if len(items)<1:items = re.findall('.+() href="(.+?)".*()()>(.+?)</a>',body)
	return items
	
def episodes(url, name='', page=0,img=''):
	if 'vaphim.com' in url:
		body=xread(url)
		tabs=re.findall('#(tabs-.+?)" >(.+?)<',body)
		if tabs:
			for tab,tab_label in tabs:
				content=xsearch('<div id="%s">(.+?)</div>'%tab,body,1,re.DOTALL)
				for href,name in re.findall('<a href="(.+?)".*?>(.+?)</a>',content):
					name='[COLOR green]%s[/COLOR] - %s'%(tab_label,vnu(name))
					if len(tabs)>2 and ('brrip' in name.lower() or 'mobile' in name.lower()):pass					
					elif len(tabs)>1 and 'brrip' in name.lower():pass					
					#elif 'Phụ Đề Việt' in name:pass					
					elif '/file/' in href:
						addItem(name,href,'stream',img,False)
					elif '/folder/' in href:
						addItem(name,href,'folder',img)
		else:				
			for href,name in re.findall('<a href="(.+?)" target="_blank">(.+?)</a>',body):
				name=vnu(name)
				if '/file/' in href:
					addItem(name,href,'stream',img,False)
				elif '/folder/' in href:
					addItem(name,href,'folder',img)
	elif 'hplus' in url:		
		response = urlfetch.get(url)
		b=response.body
		for s in re.findall('(class="panel".+?</div>\s*</div>)',b,re.DOTALL):
			href='http://hplus.com.vn/'+xsearch('href="(.+?)"',s)
			img=xsearch('src="(.+?)"',s)
			title=xsearch('<a href="[^<]+?">(.+?)</a>',s).strip()
			addItem(vnu(title),href,'stream',img,False)

	elif 'fptplay.net' in url:
		fpt=fptPlay()
		if page<2:page=1
		items=fpt.eps(url,page)
		for title,href in items:
			if 'Các tập tiếp theo' in title:addItem(title,url,'episodes&page='+str(page+1),'',True)
			else:addItem(title,href,'stream','',False)
		#if not items:addir_info(namecolor(name),xsearch('(\w{20,30})',url),img,img,mode,1,'play')
		if not items:addItem('*'+name,url,'stream','',False)
						
	elif 'hdonline.vn' in url :
		if 'Các tập tiếp theo' in  name:name= url.split('.html')[1];url= url.split('.html')[0]+'.html'
		else:name=name
		id=xsearch('-(\d+)\.html',url)
		
		hdo=hdonline()
		for href,epi in hdo.eps(id,page):
			if 'Các tập tiếp theo' in href:
				addItem(href,url+name,mode,'')
			else:
				addLink('Tập '+epi, url, 'stream', img)				
	
	elif 'vuahd.tv' in url :pass
	elif 'hdviet.com' in url:
		url = url.split('|')[1]		
		href='http://movies.hdviet.com/lay-danh-sach-tap-phim.html?id=%s'%url
		response=xshare.make_request(href,resp='j')
		if not response:return
		for eps in range(1,int(response["Sequence"])+1):		
			name=re.sub(' \[COLOR tomato\]\(\d{1,4}\)\[/COLOR\]','',name)
			title='Tập %s/%s-%s'%(format(eps,'0%dd'%len(response['Episode'])),str(response['Episode']),re.sub('\[.?COLOR.{,12}\]','',name))
			addItem(title,'hdviet.com|%s_e%d'%(url,eps),'stream',img,False)
	elif 'hayhaytv.vn' in url:
		b=re.sub('>\s*<','><',xread(url))
		s=re.findall('<a class="ep-link.+?href="(.+?)">(.+?)</a>',b)
		if not s:
			addItem(name,href,'stream',img,False)
		else:
			for href,title in s:
				addItem('Tập '+title,href,'stream',img,False)				

	
	elif 'phimmoi.net' in url :	
		body=xshare.make_request(url+'xem-phim.html')
		eps=xsearch('(/\d{1,4})\)',name)
		name=re.sub('\[/?COLOR.*?\]|\(.+?\)|\d{1,3} phút/tập|\d{1,3} phút','',name).strip()
		
		for detail in re.findall('(<div class="server clearfix server-group".+?</ul>)',body,re.DOTALL):
			title=' '.join(s for s in xsearch('<h3 class="server-name">(.+?)</h3>',detail,1,re.DOTALL).split())
			if title and 'tập phim' not in title:
				serverid=xsearch('data-serverid="(.+?)"',detail)
				addItem('[B]'+title+'[/B]','','-','',False)
			label=name.replace('TM ','') if title and 'Thuyết minh' not in title else name
			for title,href in re.findall('title="(.+?)".+?href="(.+?)"',detail,re.DOTALL):
				addItem(title,'http://www.phimmoi.net/'+href,'stream',img,False)
				result=True
		#if not result:return phimmoi(name,url,img,mode,page=1,query='pm_list_url_ple')
				
	elif 'phimnhanh.com' in url :					
		body=xread(url);s=xsearch('(<p class="epi">.+?    </p>)',body,1,re.DOTALL)
		for h,t in re.findall(' href="(.+?)" title=".+?">(.+?)</a>',s):
			addItem('Tập %s '%t+name,h,'stream',img,False)
	
		
	elif 'megabox.vn' in url :	
		content = xread(url)
		match = re.compile("href='(.+?)' >(\d+)<").findall(content)
		for url, epi in match:
			addLink('Tập ' + epi, url, 'stream', img)
	elif 'phimgiaitri.vn' in url :		
		addLink('Tập 1', url, 'stream', img)	
		content = xread(url)
		match = re.compile("<a href=\"(.+?)\" page=(\d+)>").findall(content)
		for url,title in match:		
			addLink('Tập ' + title, url, 'stream', img)
	elif 'chiasenhac' in url:
		content = xread(url)
		items=re.compile("<a href=\"([^\"]*)\" title=\"(.*?)\"><img src=\"([^\"]+)\"\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s*<span style=\"color: .*?\">(.*?)</span>").findall(content)
		for url,name,thumbnail,cat in items:
			addLink(name+color['cat']+' ['+cat+'][/COLOR]',csn+url,'stream',thumbnail)
		items=re.compile("<a href=\"hd\/video\/([a-z]-video\/new[0-9]+).html\" class=\"npage\">(\d+)<\/a>").findall(content)
		for url,name in items:
			addItem('[COLOR lime]Mới Chia Sẻ - Trang '+name+'[/COLOR]',csn+'hd/video/'+url+'.html','episodes',icon['next'])
		items=re.compile("<a href=\"hd\/video\/([a-z]-video\/down[0-9]+).html\" class=\"npage\">(\d+)<\/a>").findall(content)
		for url,name in items:
			addItem('[COLOR red]Download mới nhất - Trang '+name+'[/COLOR]',csn+'hd/video/'+url+'.html','episodes',icon['next'])
	elif 'fshare.vn' in url:
		items2=list()

		body = xread(url)
		for content in re.findall('<div class="pull-left file_name(.+?)<div class="clearfix"></div>',body,re.S):
			item=re.search('data-id="(.+?)".+? href="(.+?)".+?title="(.+?)"',content)
			if item:
				size=xsearch('<div class="pull-left file_size align-right">(.+?)</div>',content).strip()
				id=item.group(1);type='file' if 'file' in item.group(2) else 'folder';name=item.group(3)				
				if type=='file':href='https://www.fshare.vn/file/%s'%id
				else:href='https://www.fshare.vn/folder/%s'%id
				items2.append((name,href,id))														
			
		folder_list = {'items':items2}
		items = items = sorted(folder_list.get('items'), key=lambda k: k[0])
		for title,href,id in items:
			if 'www.fshare.vn/folder' in href:
				title = '[B]' + title + '[/B]'
				addItem(title, href, 'episodes', '')
			elif 'www.fshare.vn/file' in href:
				addLink(title, href, 'stream', '')

def make_mySearch(name,url,img,fanart,mode,query):
	body=makerequest(search_file)
	if query=='Rename':
		label=' '.join(s for s in name.split())
		string=get_input('Nhập chuổi mới',re.sub('\[.*\]-','',label)).strip()
		if not string or string==label:return
		string=' '.join(s for s in string.split())
		if re.search('http.?://',url):
			content=re.sub('<a href="%s">.+?</a>\n'%url,'<a href="%s">%s</a>\n'%(url,string),body)
		else:content=body.replace(name,string)
		if body!=content:
			makerequest(search_file,content,'w')
			mess(u'Sửa 1 mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Remove':
		name=re.sub('\(|\)|\[|\]|\{|\}|\?|\,|\+|\*','.',name)
		content=re.sub('<a href="%s">.+?</a>\n|<a>%s</a>\n'%(url,name),'',body)
		if body!=content:
			makerequest(search_file,content,'w')
			mess(u'Xóa 1 mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Remove All':
		content=re.sub('<a href=".+?">.+?</a>\n','',body)
		if body!=content:
			makerequest(search_file,content,'w')
			mess(u'Xóa tất cả các mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Add':
		if url and not re.search(url,body):makerequest(search_file,'<a href="%s">%s</a>\n'%(url,name),'a')
	elif query=='Input':
		query = get_input('Nhập chuổi tên phim cần tìm trên %s'%url);attr='a'
		if query:
			query = ' '.join(s for s in query.replace('"',"'").replace('?','').split() if s!='')
			if query not in body:
				makerequest(search_file,'<a>%s</a>\n'%query,'a');xbmc.executebuiltin("Container.Refresh")
		else:query=''
	elif query=='get':
		srv=url.split('.')[0];site='Google ' if mode==2 else ''
		if url=='chiasenhac.vn':
			menu={'MyPlaylist':{'action':'Search','server':['chiasenhac.vn']}}
			name='%s%sSearch[/COLOR] trên %s%s[/COLOR] Nhập chuỗi tìm kiếm mới - '+myaddon.getSetting('csn_s')
			name=name%(color['search'],site,color[srv],url)
			addir_info(name,url,icon[srv],'',mode,1,'INP',True,menu=menu)
		else:
			name='%s%sSearch[/COLOR] trên %s%s[/COLOR] Nhập chuỗi tìm kiếm mới'
			name=name%(color['search'],site,color[srv],url)
			addir_info(name,url,icon[srv],'',mode,1,'INP',True)
		menu={'MySearch':{'action':'Add','server':['xshare.vn']}}
		if myaddon.getSetting('history')=='true':
			for s in re.findall('<a>(.+?)</a>',body):addir_info(s,url,icon[srv],'',mode,4,s,True,menu=menu)
	return query
	
def Remote(name,url,img,mode,page,query):
	def check_id_internal(id):
		return '','',''
		notify('ID Checking on xshare.vn',1000)
		r1=' href="(.+%s.*)" img="(.*?)">(.+?)</a>';r2='img="(.*?)" fanart=".*?"  href="(.+%s.*)">(.+?)</a>'
		files='phimfshare.xml-hdvietnam.xml';title=''
		for file in ['vaphim.xml','ifiletv.xml','phimfshare.xml','hdvietnam.xml']:
			body=makerequest(xshare.joinpath(datapath,file));id=id.lower() if len(id)>13 else id
			items=re.search(r1%id,body) if file in files else re.search(r2%id,body)
			if items:
				title=items.group(3)
				href=items.group(1 if file in files else 2)
				img=items.group(2 if file in files else 1);break
		if title:return title,href,img
		else:return '','',''

	def check_id_fshare(id):
		notify('ID Checking on Fshare.vn',1000)
		href='https://www.fshare.vn/file/%s'%id;body=xshare.make_request(href);title=''
		if 'class="file-info"' in body:title=xsearch('<title>(.+?)</title>',body).replace('Fshare - ','')
		else:
			href='https://www.fshare.vn/folder/%s'%id
			body=xshare.make_request(href)
			if id in body:title=xsearch('<title>(.+?)</title>',body).replace('Fshare - ','')
		if title:return title,href,icon['fshare']
		else:return '','',''
	
	if page==0:
		name=color['search']+'Nhập ID/link: Fshare[/COLOR]'
		addItem(name,url,mode+'&page=1',icon['icon'])
		for href,name in re.findall('<a href="(.+?)">(.+?)</a>',makerequest(search_file)):
			#q='ID?xml' if '.xml' in name else 'ID?'+query									
			if 'www.fshare.vn/folder' in href:
				name = '[B]Fshare - ' + name + '[/B]'
				addItem(name, href, 'episodes', icon['id'])
			elif 'www.fshare.vn/file' in href:
				name = 'Fshare - ' + name
				addLink(name, href, 'stream', '')
	elif page == 1:#Nhập ID mới BIDXFYDOZMWF
		idf = xshare.get_input('Hãy nhập chuỗi ID của Fshare')#;record=[]
		if idf is None or idf.strip()=='':return 'no'
		if 'subscene.com' in idf:return subscene(name,''.join(s for s in idf.split()),'subscene.com')
		idf = xsearch('(\w{10,20})',''.join(s for s in idf.split()).upper())
		if len(idf)<10:notify(u'Bạn nhập ID link chưa đúng: %s!'%idf);return 'no'
		title,href,img=check_id_internal(idf)
		if not title:# or True:
			title,href,img=check_id_fshare(idf)
			#if not title:
				#title,href,img=check_id_4share(idf)
				#if not title:title,href,img=check_id_tenlua(idf)
		if title and href:
			xshare.make_mySearch(title,href,img,'',mode,'Add');
			
			if 'www.fshare.vn/folder' in href:
				title = '[B]Fshare - ' + title + '[/B]'
				addItem(title, href, 'episodes', icon['id'])
			elif 'www.fshare.vn/file' in href:
				title = 'Fshare - ' + title
				addLink(title, href, 'stream', '')
		else:notify(u'Không tìm được link có ID: %s!'%idf);return 'no'
	return ''				

def Local(name,url,img,fanart,mode,query):
	if not url:url=myfolder
	url=xshare.s2u(url)
	for filename in os.listdir(url):
		filenamefullpath = xshare.u2s(xshare.joinpath(url, filename));filename= xshare.u2s(filename)
		if os.path.isfile(xshare.joinpath(url, filename)):
			size=os.path.getsize(xshare.joinpath(url, filename))/1024		
			if size>1048576:size='%dGB'%(size/1048576)
			elif size>1024:size='%dMB'%(size/1024)
			else:size='%dKB'%size
			name=filename+' - %s'%size		
				
			file_ext=os.path.splitext(filenamefullpath)[1][1:].lower()
			if file_ext=='xml':
				addItem(name,filenamefullpath,'xml',icon['icon'])
			else:pass
		else:
			name='[B]'+filename+'[/B]'
			addItem(name,filenamefullpath,'local',icon['icon'])
	return
	
def ServerList(name, url, mode, page, query, img):
	id_film=url

	filename= '@%s_movie.xml'%(mode.replace('_serverlist',''))
	info = doc_xml(xshare.joinpath(datapath,filename),'%s[]query-id'%id_film)[0]
	j = json.loads(info)
	titleVn = u2s(j["titleVn"])
	titleEn = u2s(j["titleEn"])
	year = u2s(j["year"])	
	
	if 'phim-le' in mode : v_mode='stream';isFolder=False
	else : v_mode='episodes';isFolder=True
	filename2= '@%s_%s.xml'%(mode.replace('_serverlist',''),'vaphim')
	content=makerequest(xshare.joinpath(datapath,filename2))	
	r='title=".*%s.*">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleVn),year)
	v_href=re.findall(r,content)
	if not v_href:
		#r='.*href":\[(.+?)\],.*"titleEn":"%s",.*"year":"%s".*</a>'%((titleEn),year)
		r='title=".*%s.*">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleEn),year)
		v_href=re.findall(r,content)
	if v_href:
		json_input='{"href": ['+v_href[0]+']}'	
		decoded = json.loads(json_input)	
		# Access data
		for x in decoded['href']:
			url=u2s(x['url'])
			subtitle=u2s(x['subtitle'])
			if subtitle:url+='[]'+subtitle	
			addItem('[FSHARE] [COLOR yellow]'+u2s(x['label'])+'[/COLOR]',url,v_mode,img,isFolder)
			
	for i in j["href"]:				
		label = u2s(i["label"])
		url = u2s(i["url"])
		subtitle = u2s(i["subtitle"])			

		if 'megabox' in url:label='MegaBox'
		elif 'hdonline' in url:label='HDOnline'				
		elif 'phimnhanh' in url:label='PhimNhanh'							
		elif 'phimmoi' in url:label='PhimMoi'			
			
		addItem('['+label+']',url,v_mode,img,isFolder)
				
	href=filename
	addItem('[COLOR lime]Từ khóa:[/COLOR]',href,'%s&query=%s[]query-id'%('tags-movie',id_film),'')
	TagsMovie(href,'%s[]query-id'%id_film)#view ra luon
					
	return
		
	if danhmucphim <> 'HDOnline':	
		url='http://hdonline.vn/tim-kiem/%s.html'%search_string
		#url='http://m.hdonline.vn/tim-kiem/%s/trang-1.html'%search_string
		Result(url, mode, query)			
	if danhmucphim <> 'VuaHD':
		url='http://vuahd.tv/movies/q/%s'%search_string
		#Result(url, mode, query)
	if danhmucphim <> 'HDViet':		
		url='http://movies.hdviet.com/tim-kiem.html?keyword=%s'%search_string
		Result(url, mode, query)	
	if danhmucphim <> 'HayHayTV':
		url='http://www.hayhaytv.vn/tim-kiem.html?term='+search_string		
		#Result(url, mode, query)	
	if danhmucphim <> 'DangCapHD':
		url='http://dangcaphd.com/movie/search.html?key=%s&search_movie=1'%search_string
		#Result(url, mode, query)	
	if danhmucphim <> 'MegaBox':
		url='http://phim.megabox.vn/search/index?keyword=' + search_string#+'/phim-le'
		#try:Result(url, mode, query)	
		#except:pass
	if danhmucphim <> 'PhimMoi':
		url='http://www.phimmoi.net/tim-kiem/%s/'%search_string
		Result(url, mode, query)	
		
	if danhmucphim <> 'PhimGiaiTri':
		url = 'http://phimgiaitri.vn/result.php?type=search&keywords='+search_string      
		try:Result(url, mode, query)	
		except:pass
						
def Search(url): 	
	keyb=xbmc.Keyboard('', color['search']+'Nhập nội dung cần tìm kiếm[/COLOR]')
	keyb.doModal()
	if (keyb.isConfirmed()):
		searchText=keyb.getText()
		if len(searchText) == 0:return 'ok'
		searchText=urllib.quote_plus(searchText)
		
		if 'TimVideoCSN' in url:  
			url=csn+'search.php?s='+searchText+'&cat=video'      
			Result(url, mode, query)
		elif 'TimVideoNCT' in url:
			url = nct + 'tim-kiem/mv?q=' + searchText     
			Result(url, mode, query)
		elif 'TIM-KIEM' in url:
			searchText=fixString(keyb.getText())
			query = searchText+'[]query-search'
			mode = 'search'
			Result('@%s_movie.xml'%'phim-le', mode, query)
			Result('@%s_movie.xml'%'phim-bo', mode, query)
		
			#ServerList(name='', url='', mode='', page=0, query=keyb.getText()+'[][]', img='')
	else:return	'ok'						   
	
def Result(url, mode='', query='[][][]', page=0):
	if page<2:page=1
	if '.xml' in url:
		if 'tags' in query:filename='temp-tags.txt'#xu ly truong hop vao tags roi back lai
		else:filename='temp.txt'
		
		if 'movie' not in url:
			v_mode = 'stream' if 'phim-le' in url else 'episodes'
		else:
			v_mode = 'phim-le_serverlist' if 'phim-le' in url else 'phim-bo_serverlist'
			
		if page<2:
			items=doc_xml(xshare.joinpath(datapath,url),query);page=1			
			makerequest(xshare.joinpath(tempfolder,filename),str(items),'w')
		else:f=open(xshare.joinpath(tempfolder,filename));items=eval(f.readlines()[0]);f.close()
		pages=len(items)/rows+1
		del items[0:(page-1)*rows];count=0
		for title, info in items:
			j = json.loads(info)
			id = u2s(j.get("id"))
			for i in j["href"]:		
				href = u2s(i["url"])
				subtitle = u2s(i["subtitle"])
				if subtitle:href+='[]'+subtitle

			titleVn = u2s(j.get("titleVn"));titleEn = u2s(j.get("titleEn"));
			if titleEn:title='%s (%s)'%(titleVn,titleEn)
			else:title=titleVn
			year = u2s(j.get("year"));rat = u2s(j.get("rating"));plot = u2s(j.get("plot"))
			esp = u2s(j.get("episode"));drt = u2s(j.get("director"));act = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
			img = u2s(j.get("thumb"))

			if year and year not in title: title+= ' [B]' + year + '[/B]'			
			title+=color['imdb']+' IMDb: '+rat+'[/COLOR]'
			if esp:title='[COLOR yellow]'+esp+'[/COLOR] '+title

			if 'phim-' in query:			
				title+=' [B]' + country + '[/B]'
				title+=' [COLOR green]' + genre + '[/COLOR]'
				#eval("danhmuc['"+s+"']")
								
			info={'title':title,'year':year,'rating':rat,'plot':plot,'episode':esp,'director':drt,'writer':act,'genre':genre}
												
			if 'serverlist' in v_mode:href=id	
			addItem(title,href,v_mode,img,False if v_mode=='stream' else True,info=info)
			
			count+=1
			if count>rows and len(items)>(rows+10):break
		if len(items)>(rows+10):
			name=color['trangtiep']+'Trang tiếp theo...trang %d/%d[/COLOR]'%(page+1,pages)
			addItem(name, url, '%s&query=%s&page=%d'%('search_result',query,page+1), icon['next'])	
			
	elif 'chiasenhac' in url:
		content = xread(url)
		items=re.compile("<a href=\"([^\"]*)\" title=\"(.*?)\"><img src=\"([^\"]+)\"").findall(content)
		#items=re.compile("<a href=\"([^\"]*)\" title=\"(.*?)\"><img src=\"([^\"]+)\"\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s.+\s*<span class=\"gen\">.*?<br /><span style=\"color: .*?\">(.*?)</span>").findall(content)
		cat = '...'
		if 'page=' not in url:url=url+"&page=1"
		for href,name,thumbnail in items:
			name=name.replace(';',' +')
			addLink(name+color['cat']+' ['+cat+'][/COLOR]',csn+href, 'stream',thumbnail)
		items=re.compile("href=\"(.+?)\" class=\"npage\">(\d+)<").findall(content)
		for href,name in items:
			if 'page='+name not in url:
				addItem(color['trangtiep']+'Trang '+name+'[/COLOR]',href.replace('&amp;','&'),'search_result',icon['next'])
	elif 'nhaccuatui' in url:
		content = xread(url)
		match = re.compile("href=\"http:\/\/m.nhaccuatui.com\/video\/([^\"]*)\" title=\"([^\"]+)\"><img alt=\".+?\" src=\"(.*?)\"").findall(content)		
		for url, name, thumb in match:			
			addLink(name,nct + 'video/' + url,'stream',thumb)
		match = re.compile("href=\"([^\"]*)\" class=\"next\" titlle=\"([^\"]+)\"").findall(content)
		for url, name in match:	
			addItem(color['trangtiep']+name+'[/COLOR]',url,mode if mode=='episodes' else 'search_result',icon['next'])					

	elif 'fptplay.net/livetv' in url:
		fpt=fptPlay()
		b=xread(url)
		b=b.split('<div id="box_')
		for s in [i for i in b if ' class="livetv_header' in i]:
			label=xsearch('<span class="livetv_header Regular pull-left" style="margin-right: 7px;">(.+?)</span>',s)
			addItem('[B]'+vnu(label)+'[/B]','','xxx',icon['icon'],False)
			for title,href,img,dir in [fpt.detail(i) for i in re.findall('(<a class="tv_channel.+?/a>)',s,re.S)]:
				addItem(title,href,'stream',img,False)
	elif 'hplus' in url:
		response = urlfetch.get(url)
		content = response.body
		match = re.compile('<a href="(http://hplus.com.vn/ti-vi-truc-tuyen/.+?)">\s*.+?(Kênh.+?)</a>').findall(content)
		for href, title in match:
			addItem(title.strip(), href, 'episodes', '')			
	elif 'fptplay.net' in url:	
		fpt=fptPlay()
			
		b=xread(url)
		if '<div class="title">' in b:
			items=[fpt.detail(i) for i in b.split('list_img') if '<div class="title">' in i]
		elif  '<div class="col-xs-4 col-sm-15 list_img">' in b:
			s=b.split('<div class="col-xs-4 col-sm-15 list_img">')
			items=[fpt.detail(i) for i in s if 'https://fptplay.net/xem-video/' in i]
		else:items=[]
		
		for title,href,img,dir in items:
			if not title:continue
			if dir or 'truyen-van-hoc'  in url or 'truyen-co-tich' in url:
				addItem(title,href,'episodes',img,True)
				#addir_info(namecolor(title,c),href,img,img,mode,1,'eps',True)
			else:
				#id=re.search(r'\-([\w]+)\.html', href).group(1)+'?1'
				addItem(title,href,'stream',img,False)
				#addir_info(title,href,img,img,mode,1,'eps',True)
			
		return
		pn=xsearch('id="paging_(.+?)_',b)
		if pn:
			pn='type=new&stucture_id=%s&page=2'%pn
			addir_info('[COLOR lime]Page next: %d[/COLOR]'%(page+1),pn,ico,'',mode,page+1,"pageNext",True)

	elif 'vaphim.com' in url:#su dung o phan Goc chia se (Bo suu tap, liveshow, ...)
		body=xread(url)
		if body:
			pattern='<a data=.+?src="(.+?)[\?|\"].+?<h3.+?><a href="(.+?)" rel=.+?>(.+?)</a></h3>'
			for img,href,title in re.findall(pattern,body,re.DOTALL):
				title=vnu(title)				
				title=re.sub('</br>|<br/>|<br />','-',title)
				addItem(title, href, 'folder', img)
			
			if page==0:page=1
			pagelast=xsearch("<span class='pages'>Trang \d{1,4} của (\d{1,4})</span>",body)
			if pagelast and int(pagelast)>page:
				name='%sTrang tiếp theo: trang %d/%s[/COLOR]'%(color['trangtiep'],page+1,pagelast)
				url=url.replace('page/%d'%page, 'page/%d'%(page+1))
				addItem(name, url, 'search_result&page=%d'%(page+1), icon['next'])					
			
	elif 'fsharefilm.com' in url:pass			
	elif 'hdonline.vn' in url:
		body = xread(url)				
		hdo=hdonline()
		items = hdo.additems(body,mode,page)

		for id,title,titleEn,year,theloai,tag,href,img,info in items:
			j = json.loads(info)
			title = u2s(j.get("title"));year = u2s(j.get("year"));rat = u2s(j.get("rating"));plot = u2s(j.get("plot"))
			esp = u2s(j.get("episode"));drt = u2s(j.get("director"));act = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
			info={'title':title,'year':year,'rating':rat,'plot':plot,'episode':esp,'director':drt,'writer':act,'genre':genre}
			addItem(title,href,'stream' if not esp else 'episode',img,False if not esp else True,info=info)
				
	elif 'megabox.vn' in url:
		body = xread(url)		
		mgb=megabox()
		items = mgb.additems(body,mode,page)
		for id,title,titleEn,year,theloai,tag,href,img,info in items:
			j = json.loads(info)
			esp = u2s(j.get("episode"))		
			addItem(title,href,'stream' if not esp else 'episode',img,False if not esp else True)
		
		if 'search' in mode:
			try:
				items = re.compile('class="next"><a href="(.+?)">').findall(body)
				addItem(color['trangtiep']+'Trang tiếp theo[/COLOR]', 'http://phim.megabox.vn/' + items[0],'search_result&query='+query,icon['next'])
			except:pass		
	elif 'phimnhanh.com' in url:			
		body = xread(url)		
		pn=phimnhanh()
		items = pn.additems(body,mode,page)
		for id,title,titleEn,year,theloai,tag,href,img,info in items:
			j = json.loads(info)
			esp = u2s(j.get("episode"))		
			addItem(title,href,'stream' if not esp else 'episode',img,False if not esp else True)

	
	elif 'hdviet.com' in url:
		b=xshare.xread(url)
		body=xsearch('<ul class="cf box-movie-list">(.+?)<div class="box-ribbon mt-15">',b,1,re.DOTALL)

		hdv=hdviet()
		items = hdv.additems(body,mode)	
		for title,href,mode_query,img,isFolder in items:
			addItem(title,href,mode_query,img,isFolder)
		
		return
		if 'search' in mode:			
			s=xsearch('(<ul class="paginglist paginglist-center">.+?</ul>)',b,1,re.DOTALL)
			i=re.search('"active"[^"]+""><a  href="([^"]+)">(\d+)</a>',s)
			if s:
				un=i.group(1);pn=i.group(2);pages=xsearch('>(\d+)</a></li></ul>',s)
				title='%sTrang tiếp theo: trang %s/%s[/COLOR]'%(color['trangtiep'],pn,pages)
				addLink(title, 'hdviet.com', 'search_result&query='+query, icon['next'])
				#addir(title,un,img,fanart,mode,page,'else',True)				
	elif 'hayhaytv' in url:					
		b=re.sub('>\s*<','><',xread(url))		
		p1='<div class="group-title">';p2='<div class="block-base movie">'
		S=' '.join(i for i in b.split(p1) if p2 in i)
		for s in S.split(p2):
			href=xsearch('href="(.+?)"',s)
			img=xsearch('src="(.+?)"',s)
			title=xsearch('alt="(.+?)"',s)
			if [i for i in (href,img,title) if not i]:continue
			eps=re.sub('<strong>','',xsearch('<span class="label-range">(.+?)</strong>',s).strip())
			if not eps:addItem(title,href,'stream',img,False)	
			else:addItem(eps+' '+title,href,'episodes',img)	

		return
		pn=xsearch('<a href="([^"]+?)">Sau</a>',S)
		if pn:
			pages=xsearch('<a href="[^"]+page=(\d+)">Cuối</a>',S)
			name=re.sub('\[COLOR %s.+/COLOR\]'%color['trangtiep'],'',name)
			title=name+color['trangtiep']+' Trang tiep theo...trang %d/%s[/COLOR]'%(page+1,pages)
			if 'http' not in pn:pn='http://www.hayhaytv.vn'+pn
			addir_info(title,pn,ico,'',mode,page+1,query,True)
	
		
	elif 'vuahd' in url:pass	
	elif 'dangcaphd' in url:pass
	elif 'phimmoi' in url:		
		body=xread(url);		
		pm=phimmoi()
		items = pm.additems(body,mode,page)
		for id,title,titleEn,year,theloai,tag,href,img,info in items:								
			j = json.loads(info)
			esp = u2s(j.get("episode"))		
			
			plg='plugin://plugin.video.hkn.phimmoi/?action=list_media_items&path='
			href=plg+href.replace('xem-phim.html','')
			addItem(title,href,'stream' if not esp else 'episode',img,False if not esp else True)				

			
		urlnext=xsearch('<li><a  href="(.+?)">Trang kế.+?</a></li>',body)
		if urlnext:
			pagenext=xsearch('/page-(\d{1,3})\.html',urlnext)
			name='%sTrang tiếp theo: trang %s[/COLOR]'%(color['trangtiep'],pagenext)
			#xshare.addir_info(name,'http://www.phimmoi.net/'+urlnext,img,fanart,mode,page,'readpage',True)
	elif 'phimgiaitri' in url:
		content = xshare.make_request(url)			
				
		items = re.compile('<a style=\'text-decoration:none\' href=\'([^\']*).html\'>\s*<img style=.+?src=(.+?) ><table style.+?:0px\'>(.+?)\s*<\/font><br \/><font style.+?#F63\'>(.+?)</font>').findall(content)
		for href,img,namevn,nameen in items:		
			strNameEn, name =  strVnEn(namevn, nameen)	
			href = 'http://phimgiaitri.vn/'+href+'/Tap-1.html'
			addLink(name,href,'stream','http://phimgiaitri.vn/'+img)
		items = re.compile('<a style=\'text-decoration:none\' href=\'([^\']*).html\'>\s*<img style=.+?src=(.+?) ><div class=\'text\'>\s*(.+?)\s*</div><table style.+?:0px\'>(.+?)\s*</font>.+?\'> (.+?)</font>').findall(content)
		for href,img,eps,namevn,nameen in items:		
			name =  namevn + ' - ' + nameen
			if '01/01' in eps : #truong hop phim le o trang chu co hien thi (Tập 01/01)
				href = 'http://phimgiaitri.vn/'+href+'/Tap-1.html'
				addLink(name,href, 'stream','http://phimgiaitri.vn/'+img)					
			else : 
				href = 'http://phimgiaitri.vn/'+href+'/Tap-1.html'
				addItem(name,href,'episodes','http://phimgiaitri.vn/'+img)	
								
        #match = re.compile('<a href="(.+?)">>').findall(content)[0:1]
        #for url in match:
            #addLink('[COLOR lime]Trang tiếp theo[/COLOR]','http://phimgiaitri.vn/'+url.replace(' ','%20'),'search_result',icon['next'])
																		
def Stream(url,link='',subfile=''):
	if '[]' in url:
		arr=url.split('[]')
		url=arr[0];subfile=arr[1]
		
		if '/file/' in subfile:
			fs=fshare()
			link_sub=fs.getLink(subfile,myaddon.getSetting('usernamef'),myaddon.getSetting('passwordf'))
			if link_sub:
				ext=os.path.splitext(link_sub)[1][1:].lower()			
				if ext in ['rar','zip','srt','sub','txt','smi','ssa','ass','nfo']:
					subfile=xshare.xshare_download(link_sub)		
	
	if not link:
		if 'vtvgo' in url:
			response = fetch_data(url)
			if not response:link=''
			else:
				cookie=response.cookiestring;
				match = re.search(re.compile(r'vtv\d-(.*?)\.'), url)
				epgid = match.group(1)
				headers = { 
							'User-Agent'		: 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0',
							'Cookie'			: cookie,
							'Referer'			: url,
							'X-Requested-With'	: 'XMLHttpRequest'							
						}
				data={'epg_id':epgid,'type':'1'}
				response = urlfetch.get('http://vtvgo.vn//get-program-channel?epg_id=' +epgid +'&type=1', headers=headers, data=data)
				json_data = json.loads(response.body)
				link = json_data['data']
		elif 'fptplay.net/livetv' in url:
			fpt=fptPlay()
			link=fpt.liveLink(url)
		elif 'fptplay.net' in url:
			link=getlink.get(url)
				
			#fpt=fptPlay()
			#link=fpt.stream(url)						
		elif 'hplus' in url:
			tv=television()
			link=tv.getLink(url)
			
		elif 'htvonline' in url:
			response = fetch_data(url)
			if not response:link=''
			else:
				match = re.search(re.compile(r'setUpPlayer\(\'(.*?)\''), response.body)
				if not match:link=''
				else:link = match.group(1)	
		elif 'chiasenhac' in url:
			content = xread(url)		
			try:
				link = re.compile("\"hd-2\".+?\"([^\"]+)\"").findall(content)[0].replace('%3A',':').replace('%2F','/').replace('%2520','%20')
			except:
				link = re.compile("\"hd-2\".+?\"([^\"]+)\"").findall(content)[-1].replace('%3A',':').replace('%2F','/').replace('%2520','%20')
		elif 'nhaccuatui' in url:
			content = xread(url)
			link = re.compile("title=\".+?\" href=\"([^\"]*)\"").findall(content)[0] 		
		elif 'phimgiaitri' in url:
			try:	
				xbmc.log(url)	
				arr = url.split('/')
				phimid = arr[len(arr) - 3]
				tap = arr[len(arr) - 1]
				tap2 = tap.split('-')
				tap3 = tap2[1].split('.')
				tap = tap3[0]
				url2 = 'http://120.72.85.195/phimgiaitri/mobile/service/getep3.php?phimid=' + phimid
				content = xread(url2)
				content = content[3:]
				infoJson = json.loads(content)
				tapindex = int(tap) -1
				link = infoJson['ep_info'][tapindex]['link']
				link = link.replace('#','*')
				url3 ='http://120.72.85.195/phimgiaitri/mobile/service/getdireclink.php?linkpicasa=' + link
				content = xread(url3)
				content = content[3:]
				linkJson = json.loads(content)
				link = linkJson['linkpi'][0]['link720'] or linkJson['linkpi'][0]['link360']
			except:
				content = xread(url)
				link = re.compile('source src="(.+?)"').findall(content)[-1]
		elif 'megabox.vn' in url:
			#from resources.lib.servers import megabox;
			mgb=megabox()
			link=mgb.getLink(url)											
		elif 'hayhaytv' in url:
			hh=hayhayvn()
			for href,label in hh.getLink(url):
				link=test_link(href)
				if link:break			
		elif 'hdviet.com' in url:		
			if os.path.isfile(xshare.joinpath(datapath,'hdviet.cookie')):os.remove(xshare.joinpath(datapath,'hdviet.cookie'))
				
			hdv=hdviet()
			url = url.split('|')[1]
			link,subfile=hdv.getResolvedUrl(url)
			if subfile:
				subfile = xshare.xshare_download(subfile)		
		elif 'phimmoi.net' in url:
			pm=phimmoi()
			link=pm.getLink(url)											
		elif 'phimnhanh.com' in url:
			pn=phimnhanh()
			link=pn.getLink(url)									
		elif 'hdonline.vn' in url:
			link,subfile=getlink.get(url)
			if subfile:
				subfile = xshare.xshare_download(subfile)				
		elif 'fshare.vn' in url:				
			fs=fshare()
			link=fs.getLink(url,myaddon.getSetting('usernamef'),myaddon.getSetting('passwordf'))
			if link:
				ext=os.path.splitext(link)[1][1:].lower()			
				if ext in ['rar','zip','srt','sub','txt','smi','ssa','ass','nfo']:
					result=xshare.xshare_download(link);return ''
				elif '.xml' in link:return link
				
				url=link
				urltitle=urllib.unquote(os.path.splitext(os.path.basename(url))[0]).lower()
				urltitle='.'+'.'.join(s for s in re.sub('_|\W+',' ',re.split('\d\d\d\d',urltitle)[0]).split())+'.'

				subfile='';items=[]
				for file in os.listdir(subsfolder):
					filefullpath=xshare.joinpath(subsfolder,file).encode('utf-8')
					filename=re.sub('vie\.|eng\.','',os.path.splitext(file)[0].lower().encode('utf-8'))
					filename=re.split('\d\d\d\d',filename)[0];count=0
					for word in re.sub('_|\W+',' ',filename).split():
						if '.%s.'%word in urltitle:count+=1
					if count:items.append((count,filefullpath))
				for item in items:
					if item[0]>=count:count=item[0];subfile=item[1]
		else:
			link = url					
		if link is None or len(link) == 0:
			notify('Lỗi không lấy được link phim.')
	
	if img:item=xbmcgui.ListItem(path=link, iconImage=img, thumbnailImage=img)
	else:item=xbmcgui.ListItem(path=link)
		
	if 'fshare' in link:item.setInfo('video', {'Title':urllib.unquote(os.path.basename(link))})	
	else:item.setInfo('video', {'Title':name})
	
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)	
	
	if not subfile and myaddon.getSetting('advertisement') == 'false':
		subfile=decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'quangcao.srt'
		subfile=xshare.xshare_download(subfile)
	if subfile:
		xbmc.sleep(2000);xbmc.Player().setSubtitles(subfile)	
		
	return
	
#__author__ = 'thaitni' -> thanks you!
def checkupdate(filename,hours=1,folder=datapath,xdict=dict()):
	filecheck=xshare.joinpath(folder,filename);timeformat='%Y%m%d%H'
	filetime=os.path.getmtime(filecheck) if os.path.isfile(filecheck) else 0
	last_update=datetime.datetime.fromtimestamp(filetime).strftime(timeformat)
	timenow=datetime.datetime.now().strftime(timeformat)
	#if int(timenow)-int(last_update)>hours:
	#	xshare_dict=json_rw('xshare.json');file_time=xshare_dict.get(filename,'0')
	#	if timenow > file_time:xshare_dict[filename]=timenow;json_rw('xshare.json',xshare_dict);result=True
	return (int(timenow)-int(last_update))>hours
	
def xread(url,hd={'User-Agent':'Mozilla/5.0'},data=None):
	req=urllib2.Request(url,data,hd)
	try:res=urllib2.urlopen(req, timeout=20);b=res.read();res.close()
	except:b=''
	return b
	
def makerequest(file,body='',attr='r'):
	file=xshare.s2u(file)
	if attr=='r':
		try:f=open(file);body=f.read();f.close()
		except:body=''
	else:
		try:f=open(file,attr);f.write(body);f.close()
		except:notify(u'Lỗi ghi file: %s!'%xshare.s2u(os.path.basename(file)));body=''
	return body
#__author__ = 'thaitni'	
		
def addLink(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name})
	liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz, isFolder=False)
	return ok
	
def addItem(name,url,mode,iconimage,isFolder=True, info={}, art={}, menu={}):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	if not info:info={ "Title": name }
	liz.setInfo("video", info)	
	if art:liz.setArt(art)#{"thumb":iconimage,"poster":iconimage,"fanart":iconimage}
	
	if ('www.youtube.com/user/' in url) or ('www.youtube.com/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	if ('plugin://plugin' in url):u = url
	liz.setProperty("isPlayable", isFolder and "false" or "true")
	#if not isFolder:
		#liz.setProperty('IsPlayable', 'true')
	#else:liz.setProperty('IsPlayable', 'false')
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
	return ok
	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param
### ------------
try:
	myfolder=xshare.s2u(myaddon.getSetting('thumuccucbo'))
	if not os.path.exists(myfolder):myfolder=xshare.joinpath(datapath,'myfolder')
except:myfolder=xshare.joinpath(datapath,'myfolder')
subsfolder=xshare.joinpath(tempfolder,'subs')
params=get_params();page=0;temp=[];mode=url=name=fanart=img=date=query=action=end=text=''

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:img=urllib.unquote_plus(params["img"])
except:pass
try:fanart=urllib.unquote_plus(params["fanart"])
except:pass
try:mode=str(params["mode"])
except:pass
try:page=int(params["page"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass#urllib.unquote

### ------------
#print "Main---------- Mode: "+str(mode),"URL: "+str(url),"Name: "+str(name),"query: "+str(query),"page: "+str(page),"img: "+str(img)
if not mode:
	datafolder=xbmc.translatePath(myaddon.getAddonInfo('profile'))	
	
	for folder in (datafolder,datapath,iconpath,myfolder,subsfolder):
		if not os.path.exists(folder):os.mkdir(folder)
	xmlheader='<?xml version="1.0" encoding="utf-8">\n';p=datapath;q=myfolder
	for i in [(p,'search.xml'),(q,'mylist.xml')]:
		file=xshare.joinpath(i[0],i[1])
		if not os.path.isfile(file):makerequest(file,xmlheader,'w')
				
	file=os.path.join(data_path,'database.txt')
	if os.path.isfile(file):
		notify(u'Đang kiểm tra và tải dữ liệu');xshare.delete_files(tempfolder)
		tempfile = os.path.join(tempfolder,"data.zip")
		href=decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'data.zip'
		response=xshare.make_request(href,resp='o',maxr=3)
		if response.status==200:
			body=makerequest(tempfile,response.body,'wb');xbmc.sleep(1000)
			datapath=xbmc.translatePath(myaddon.getAddonInfo('profile'))
			try:
				xbmc.executebuiltin('XBMC.Extract("%s","%s")'%(tempfile,datapath), True)
				os.remove(xshare.joinpath(data_path,'database.txt'))
				notify(u'Tải dữ liệu thành công')				
			except:notify(u'Tải dữ liệu lỗi!')			
		else:notify(u'Tải dữ liệu không thành công!')
										
	Home(url,query)			

elif mode == 'home':Home(url,query)
elif mode == 'tags':Tags(url,query)
elif mode == 'tags-movie':TagsMovie(url,query)
elif mode == 'index':Index(url,name,page)
elif mode == 'category':Category(url, name, query)
elif mode == 'episodes' or mode == 'folder':episodes(url, name, page)
elif mode == 'xml':doc_list_xml(url,page)
elif mode == 'local':Local(name,url,img,fanart,mode,query)
elif mode == 'remote':Remote(name,url,img,mode,page,query)
elif mode == 'search':end=Search(url)
elif mode == 'search_result':
	v_query='Phim lẻ' if query=='phim-le' else 'Phim bộ'
	if 'movie.xml' in url:
		if 'phim-' in query:
			filecheck='@%s_movie.dat'%query
			filedownload='@%s_movie.zip'%query
			filename='@%s_movie.xml'%query			
			if checkupdate(filecheck,12,datapath):# and False:
				makerequest(xshare.joinpath(datapath,filecheck),'','w')
				notify(u'Đang cập nhật dữ liệu...',v_query,timeout=5000)
				tempfile = os.path.join(tempfolder,filedownload)		
				href=decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+filedownload
				response=xshare.make_request(href,resp='o',maxr=3)
				if response.status==200:
					body=makerequest(tempfile,response.body,'wb');xbmc.sleep(1000)
					try:
						count_old=len(doc_xml(xshare.joinpath(datapath,filename)))
						xbmc.executebuiltin('XBMC.Extract("%s","%s")'%(tempfile,datapath), True)
						count_new=len(doc_xml(xshare.joinpath(datapath,filename)))
						if count_new>count_old:
							notify(u'Đã cập nhật được %d phim'%(count_new-count_old),v_query,timeout=2000)
						else:notify(u'Không có phim mới...',v_query,timeout=2000)
					except:notify(u'Đã xảy ra lỗi cập nhật!',v_query,timeout=2000)
				else:notify(u'Cập nhật dữ liệu không thành công!',v_query)
	else:
		server = re.sub('\[.*?]','',name.lower())
		if server in ['megabox', 'hdonline', 'phimmoi', 'phimnhanh', 'fsharefilm', 'vaphim']:
			filecheck=url.replace('xml','dat')
			file=os.path.join(datapath,url)
			if (checkupdate(filecheck,12,datapath) or not os.path.isfile(file)):# and False:
				makerequest(xshare.joinpath(datapath,filecheck),'','w')
				notify(u'Đang cập nhật dữ liệu...',u'%s - %s'%(v_query,eval("www['"+server+"']")),timeout=5000)
				DownloadDB(query,server,1,1)			
			
	Result(url, mode, query, page)
elif mode == 'stream':Stream(url)
elif mode == 'play':Stream(url,link=url)
elif 'serverlist' in mode:ServerList(name, url, mode, page, query, img)	
elif mode == 'setting':myaddon.openSettings();end='ok'

try:	
	if not mode and not query:
		xbmc.executebuiltin('Container.SetViewMode(500)')# Thumbnails		
	elif '@phim-' in url:
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		#xbmc.executebuiltin('Container.SetViewMode(504)')# Media info
except:pass	
	
if not end or end not in 'no-ok-fail':xbmcplugin.endOfDirectory(int(sys.argv[1]))
#truyen hinh xem lai
#phim bo mega tap tiep theo