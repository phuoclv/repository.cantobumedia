# -*- coding: utf-8 -*-
import urllib,urllib2,urlfetch, re, os, json, requests
from time import sleep
from utils import *
from urlfetch import get,post

import random
import xbmc, xbmcaddon
	
def gibberishAES(string, key=''):
	import ctypes
	def aa(l,s=4):
		a=[]
		for i in range(0,len(l),s):a.append((l[i:i+s]))
		return a

	def j2p(v):return ctypes.c_int(v).value
	def rshift(val, n): return (val % 0x100000000) >> n

	e = 14
	r = 8
	n = False
		
	def f(e):
		#try:result=urllib.quote(e)
		#except:result=str(e)
		return str(e)
		
	def c(e):
		#try:result=urllib.quote(e, safe='~()*!.\'')
		#except:result=str(e)
		return str(e)

	def t(e):
		f = [0]*len(e)
		if 16 >len(e):
			r = 16 - len(e)
			f = [r, r, r, r, r, r, r, r, r, r, r, r, r, r, r, r]
		for n in range(len(e)):f[n] = e[n]
		return f

	def o(e):
		n = ""
		for r in len(e):n += ("0" if 16 > e[r] else "") + format(e[r], 'x')
		return n

	def u(e, r):
		c = []
		if not r:e=f(e)
		for n in range(len(e)):c.append(ord(e[n]))
		return c

	def i(n):
		if n==128:e = 10; r = 4
		elif n==192:e = 12;r = 6
		elif n==256:e = 14;r = 8

	def b(e):
		n = []
		for r in range(e):n.append(256)
		return n

	def h(n, f):
		d=[];t= 3 if e >= 12 else 2; i = n + f; d.append(L(i));u=[c for c in d[0]]
		for c in range(1,t):d.append(L(d[c - 1] + i));u+=d[c]
		return {'key': u[0 : 4 * r],'iv': u[4 * r : 4 * r + 16]}

	def a1(e, r=False):
		c = ""
		if (r):
			n = e[15]
			#if n > 16:print "Decryption error: Maybe bad key"
			if 16 != n:
				for f in range(16 - n):c += chr(e[f])
		else:
			for f in range(16):c += chr(e[f])
		return c

	def a(e, r=False):
		if not r:c=''.join(chr(e[f])for f in range(16))
		elif 16!=e[15]:c=''.join(chr(e[f]) for f in range(16-e[15]))
		else:c=''
		return c

	def v(e, r, n, f=''):
		r = S(r); o = len(e) / 16; u = [0]*o
		d=[e[16 * t: 16 * (t + 1)] for t in range(o)]
		for t in range(len(d) - 1,-1,-1):
			u[t] = p(d[t], r)
			u[t] = x(u[t], n) if 0 == t else x(u[t], d[t - 1])
		
		i=''.join(a(u[t]) for t in range(o-1))
		i += a(u[o-1], True)
		return i if f else c(i)

	def s(r, f):
		n = False
		t = M(r, f, 0)
		for c in (1, e + 1 ,1):
			t = g(t)
			t = y(t)
			if e > c:t = k(t)
			t = M(t, f, c)
		return t

	def p(r, f):
		n = True
		t = M(r, f, e)
		for c in range(e - 1,-1,-1):
			t = y(t,n)
			t = g(t,n)
			t = M(t, f, c)
			if c > 0 : t = k(t,n)
		return t

	def g(e,n=True):#OK
		f = D if n else B; c = [0]*16
		for r in range(16):c[r] = f[e[r]]
		return c

	def y(e,n=True):
		f = []
		if n: c = [0, 13, 10, 7, 4, 1, 14, 11, 8, 5, 2, 15, 12, 9, 6, 3] 
		else:c =[0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
		for r in range(16):f.append(e[c[r]])
		return f

	def k(e,n=True):
		f = [0]*16
		if (n):
			for r in range(4):
				f[4 * r] = F[e[4 * r]] ^ R[e[1 + 4 * r]] ^ j[e[2 + 4 * r]] ^ z[e[3 + 4 * r]]
				f[1 + 4 * r] = z[e[4 * r]] ^ F[e[1 + 4 * r]] ^ R[e[2 + 4 * r]] ^ j[e[3 + 4 * r]]
				f[2 + 4 * r] = j[e[4 * r]] ^ z[e[1 + 4 * r]] ^ F[e[2 + 4 * r]] ^ R[e[3 + 4 * r]]
				f[3 + 4 * r] = R[e[4 * r]] ^ j[e[1 + 4 * r]] ^ z[e[2 + 4 * r]] ^ F[e[3 + 4 * r]]
		else:
			for r in range(4):
				f[4 * r] = E[e[4 * r]] ^ U[e[1 + 4 * r]] ^ e[2 + 4 * r] ^ e[3 + 4 * r]
				f[1 + 4 * r] = e[4 * r] ^ E[e[1 + 4 * r]] ^ U[e[2 + 4 * r]] ^ e[3 + 4 * r]
				f[2 + 4 * r] = e[4 * r] ^ e[1 + 4 * r] ^ E[e[2 + 4 * r]] ^ U[e[3 + 4 * r]]
				f[3 + 4 * r] = U[e[4 * r]] ^ e[1 + 4 * r] ^ e[2 + 4 * r] ^ E[e[3 + 4 * r]]
		return f	

	def M(e, r, n):#OK
		c = [0]*16
		for f in range(16):c[f] = e[f] ^ r[n][f]
		return c

	def x(e, r):
		f = [0]*16
		for n in  range(16):f[n] = e[n] ^ r[n]
		return f

	def S(n):#r=8;e=14
		o=[[n[4 * f + i] for i in range(4)] for f in range(r)]
		
		for f in range(r,4 * (e + 1)):
			d=[t for t in o[f-1]]
			if 0 == f % r:d = m(w(d)); d[0] ^= K[f / r - 1]
			elif r > 6 and 4 == f % r : d = m(d)
			o.append([o[f - r][t] ^ d[t] for t in range(4)])
		
		u = []
		for f in range(e + 1):
			u.append([])
			for a in range(4):u[f]+=o[4 * f + a]
		return u

	def m(e):
		return [B[e[r]] for r in range(4)]

	def w(e):
		e.insert(4,e[0])
		e.remove(e[4])
		return e

	def A(e, r):return [int(e[n:n+r], 16) for n in range(0,len(e),r)]

	def C(e):
		n=[0]*len(e)
		for r in range(len(e)):n[e[r]] = r
		return n

	def I(e, r):
		f=0
		for n in range(8):
			f = f ^ e if 1 == (1 & r) else f
			e = j2p(283 ^ e << 1) if e > 127 else j2p(e << 1)
			r >>= 1
		return f

	def O(e):
		n = [0]*256
		for r in range(256):n[r] = I(e, r)
		return n

	B = A("637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16", 2)
	D = C(B)
	K = A("01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591", 2)
	E = O(2)
	U = O(3)
	z = O(9)
	R = O(11)
	j = O(13)
	F = O(14)

	def G(e, r, n):
		c = b(8); t = h(u(r, n), c); a = t.key; o = t.iv; d = [83, 97, 108, 116, 101, 100, 95, 95]+c
		e = u(e, n)
		f = l(e, a, o)
		f = d+f
		return T.encode(f)

	def H(e, r, n=''):
		f = decode(e)
		c = f[8 : 16]
		t = h(u(r, n), c)
		a = t['key']
		o = t['iv']
		f = f[16 : len(f)]
		return v(f, a, o, n)

	def decode(r):#OK
		def indexOfchar(n):
			try:a=e.index(r[n])
			except:a=-1
			return a
		
		e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
		r=r.replace('\n','');f=[];c=[0]*4
		for n in range(0,len(r),4):
			for i in range(len(c)):c[i]=indexOfchar(n+i)
			f.append(j2p(c[0]<<2|c[1]>>4))
			f.append(j2p((15&c[1])<<4|c[2]>>2))
			f.append(j2p((3&c[2])<<6|c[3]))
		return f[0:len(f)-len(f)%16]

	def L(e):
		def r(e, r):return j2p(e << r) | j2p(rshift(e, 32-r))

		def n(e, r):
			c = 2147483648 & e
			t = 2147483648 & r
			n = 1073741824 & e
			f = 1073741824 & r
			a = (1073741823 & e) + (1073741823 & r)
			i = 2147483648^a^c^t
			j = 3221225472^a^c^t
			k = 1073741824^a^c^t
			return j2p(i if n & f else ((j if 1073741824 & a else k) if n | f else a^c^t))		

		def f(e, r, n):return j2p(e & r) | j2p(~e & n)

		def c(e, r, n):return j2p(e & n) | j2p(r & ~n)

		def t(e, r, n):return e ^ r ^ n

		def a(e, r, n):return r ^ (e | ~n)

		def o(e, c, t, a, o, d, u):
			e = n(e, n(n(f(c, t, a), o), u))
			return n(r(e, d), c)

		def d(e, f, t, a, o, d, u):
			e = n(e, n(n(c(f, t, a), o), u))
			return n(r(e, d), f)

		def u(e, f, c, a, o, d, u):
				e = n(e, n(n(t(f, c, a), o), u))
				return n(r(e, d), f)

		def i(e, f, c, t, o, d, u):
			e = n(e, n(n(a(f, c, t), o), u))
			return n(r(e, d), f)

		def b(e):
			n=len(e); f = n + 8; c = (f - f % 64) / 64; t = 16 * (c + 1); a = [0]*t; o = 0
			for d in range(n):r = (d - d % 4) / 4; o = 8 * (d % 4);	a[r] = a[r] | j2p(e[d] << o)
			d+=1
			r = (d - d % 4) / 4
			o = 8 * (d % 4)
			a[r] = a[r] | j2p(128 << o)
			a[t - 2] = j2p(n << 3)
			a[t - 1] = j2p(rshift(n,29))
			return a

		def h(e):
			f = []
			for n in range(4):
				r = j2p(255 & rshift(e, 8 * n))
				f.append(r)
			return f

		m = A("67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391", 8)
		S = [];  S = b(e); y = m[0]; k = m[1]; M = m[2]; x = m[3]; l = 0
		for l in range(0,len(S),16):
			v = y
			s = k
			p = M
			g = x
			y = o(y, k, M, x, S[l + 0], 7, m[4])
			x = o(x, y, k, M, S[l + 1], 12, m[5])
			M = o(M, x, y, k, S[l + 2], 17, m[6])
			k = o(k, M, x, y, S[l + 3], 22, m[7])
			y = o(y, k, M, x, S[l + 4], 7, m[8])
			x = o(x, y, k, M, S[l + 5], 12, m[9])
			M = o(M, x, y, k, S[l + 6], 17, m[10])
			k = o(k, M, x, y, S[l + 7], 22, m[11])
			y = o(y, k, M, x, S[l + 8], 7, m[12])
			x = o(x, y, k, M, S[l + 9], 12, m[13])
			M = o(M, x, y, k, S[l + 10], 17, m[14])
			k = o(k, M, x, y, S[l + 11], 22, m[15])
			y = o(y, k, M, x, S[l + 12], 7, m[16])
			x = o(x, y, k, M, S[l + 13], 12, m[17])
			M = o(M, x, y, k, S[l + 14], 17, m[18])
			k = o(k, M, x, y, S[l + 15], 22, m[19])
			y = d(y, k, M, x, S[l + 1], 5, m[20])
			x = d(x, y, k, M, S[l + 6], 9, m[21])
			M = d(M, x, y, k, S[l + 11], 14, m[22])
			k = d(k, M, x, y, S[l + 0], 20, m[23])
			y = d(y, k, M, x, S[l + 5], 5, m[24])
			x = d(x, y, k, M, S[l + 10], 9, m[25])
			M = d(M, x, y, k, S[l + 15], 14, m[26])
			k = d(k, M, x, y, S[l + 4], 20, m[27])
			y = d(y, k, M, x, S[l + 9], 5, m[28])
			x = d(x, y, k, M, S[l + 14], 9, m[29])
			M = d(M, x, y, k, S[l + 3], 14, m[30])
			k = d(k, M, x, y, S[l + 8], 20, m[31])
			y = d(y, k, M, x, S[l + 13], 5, m[32])
			x = d(x, y, k, M, S[l + 2], 9, m[33])
			M = d(M, x, y, k, S[l + 7], 14, m[34])
			k = d(k, M, x, y, S[l + 12], 20, m[35])
			y = u(y, k, M, x, S[l + 5], 4, m[36])
			x = u(x, y, k, M, S[l + 8], 11, m[37])
			M = u(M, x, y, k, S[l + 11], 16, m[38])
			k = u(k, M, x, y, S[l + 14], 23, m[39])
			y = u(y, k, M, x, S[l + 1], 4, m[40])
			x = u(x, y, k, M, S[l + 4], 11, m[41])
			M = u(M, x, y, k, S[l + 7], 16, m[42])
			k = u(k, M, x, y, S[l + 10], 23, m[43])
			y = u(y, k, M, x, S[l + 13], 4, m[44])
			x = u(x, y, k, M, S[l + 0], 11, m[45])
			M = u(M, x, y, k, S[l + 3], 16, m[46])
			k = u(k, M, x, y, S[l + 6], 23, m[47])
			y = u(y, k, M, x, S[l + 9], 4, m[48])
			x = u(x, y, k, M, S[l + 12], 11, m[49])
			M = u(M, x, y, k, S[l + 15], 16, m[50])
			k = u(k, M, x, y, S[l + 2], 23, m[51])
			y = i(y, k, M, x, S[l + 0], 6, m[52])
			x = i(x, y, k, M, S[l + 7], 10, m[53])
			M = i(M, x, y, k, S[l + 14], 15, m[54])
			k = i(k, M, x, y, S[l + 5], 21, m[55])
			y = i(y, k, M, x, S[l + 12], 6, m[56])
			x = i(x, y, k, M, S[l + 3], 10, m[57])
			M = i(M, x, y, k, S[l + 10], 15, m[58])
			k = i(k, M, x, y, S[l + 1], 21, m[59])
			y = i(y, k, M, x, S[l + 8], 6, m[60])
			x = i(x, y, k, M, S[l + 15], 10, m[61])
			M = i(M, x, y, k, S[l + 6], 15, m[62])
			k = i(k, M, x, y, S[l + 13], 21, m[63])
			y = i(y, k, M, x, S[l + 4], 6, m[64])
			x = i(x, y, k, M, S[l + 11], 10, m[65])
			M = i(M, x, y, k, S[l + 2], 15, m[66])
			k = i(k, M, x, y, S[l + 9], 21, m[67])
			y = n(y, v)
			k = n(k, s)
			M = n(M, p)
			x = n(x, g)
		return h(y)+h(k)+h(M)+h(x)

		
	def recode(b):
		def getcode(s):
			w, i, s, e=s.split(',')
			a=b=c=0;d=[];f=[]
			while True:
				if a < 5:f.append(w[a])
				elif a < len(w):d.append(w[a])
				a+=1
				
				if  b < 5 :f.append(i[b])
				elif  b < len(i):d.append(i[b])
				b+=1
				
				if  c < 5:f.append(s[c])
				elif  c < len(s):d.append(s[c])
				c+=1
				
				if len(w) + len(i) + len(s) + len(e) == len(d) + len(f) + len(e):break

			k=''.join(s for s in d);m=''.join(s for s in f);b=0;o=[]
			for a in range(0,len(d),2):
				n = -1
				if ord(m[b]) % 2:n = 1
				o.append(chr(int(k[a:a+2], 36) - n))
				b+=1
				if b >= len(f):b = 0
			return ''.join(s for s in o)
		l=0
		while l<5 or 'decodeLink' not in b:
			try:b=getcode(xsearch("(\w{100,},\w+,\w+,\w+)",b.replace("'",'')));l+=1
			except:break
		return b
	
	return H(string, key) if key else recode(string)
					
class fshare:    
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 Gecko/20100101 Firefox/44.0','x-requested-with':'XMLHttpRequest'}

	def xfetch2(self,url,headers='',data=None):
		try:response=urlfetch(url,headers=self.hd,data=data)
		except:response= None
		return response

	def xfetch(self,url, headers=None, data=None):
		if headers is None:
			headers = self.hd
		try:
			if data:
				response = urlfetch.post(url, headers=headers, data=data)
			else:
				response = urlfetch.get(url, headers=headers)
			return response
		except:return None					

	exec(xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'code/getLink.py'))

	
class fptPlay:#from resources.lib.servers import fptPlay;fpt=fptPlay(c)
	def __init__(self):
		self.hd={'User_Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest','X-KEY':'123456'}
		self.hd['referer']='https://fptplay.net/'
		
	def detail(self,s):
		title=vnu(xsearch('title="([^"]+?)"',s))
		if not title:title=vnu(xsearch('alt="([^"]+?)"',s))
		label=' '.join(re.findall('<p[^<]*?>(.+?)</p>',s))+title
		dir=True if 'tập' in (title+label).lower() else False
		if xsearch('(\d+/\d+)',label):dir=True;title+=' [COLOR blue]%s[/COLOR]'%xsearch('(\d+/\d+)',label)
		if 'thuyếtminh' in (title+label).replace(' ','').lower():title='[COLOR blue]TM[/COLOR] '+title
		if 'phụđề' in (title+label).replace(' ','').lower():title='[COLOR green]PĐ[/COLOR] '+title
		href=xsearch('href="([^"]+?)"',s)
		if not href:href=xsearch('data-href="(.+?)"',s)
		if 'Đang diễn ra' in s:dir=None
		img=xsearch('src="([^"]+?\.jpg)',s)
		if not img:
			img=xsearch('data-original="([^"]+?\.jpg)',s)
			if not img:img=xsearch('data-original="([^"]+?\.png)',s)
		return title,href,img,dir
			
	def eps(self,url):
		page=1
		while True:
			data='film_id=%s&page=%d'%(xsearch('(\w{20,30})',url),page);items=[]
			b=xread('https://fptplay.net/show/episode',self.hd,data)
			for s in [i for i in re.findall('(<li.+?/li>)',b,re.S) if '"title_items"' in i]:
				title=xsearch('title="(.+?)"',s)
				epi=xsearch('<p class="title_items">.+? (\d+)',s)
				if epi:title=epi+'-'+title
				if 'phụđề' in title.replace(' ','').lower():title='[COLOR green]PĐ[/COLOR] '+title
				elif 'thuyếtminh' in title.replace(' ','').lower():title='[COLOR blue]TM[/COLOR] '+title
				#href=xsearch('(\w{20,30})',xsearch('href="(.+?)"',s))+'?'+xsearch('id="episode_(\d{1,4})"',s)
				href=xsearch('href="(.+?)"',s)
				items.append((vnu(title),href))
			page+=1
			if '&rsaquo;&rsaquo;' not in b:break
		return items	
	
	def getLink(self,url,epi='1'):	
		phone_fptplay=get_setting('phone_fptplay');password=get_setting('pass_fptplay')
		conutry=re.sub('\(.+?\)','',get_setting('country_fptplay')).strip()		
	
		url_login = 'https://fptplay.net/user/login'

		#r = urlfetch.get('https://fptplay.net')
		#cookie = r.cookiestring;
		params = {'country_code': conutry, 'phone': phone_fptplay, 'password': password, 'submit': ''}
		headers = {'User_Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0','Referer':'https://fptplay.net/'}
		
		if len(phone_fptplay) == 0  or len(password) == 0:
			sleep(2)
			notify(u'Bạn nên nhập user và pasword của FPTplay.net.'.encode("utf-8"))
		
		
		s = requests.Session()

		r = s.get('https://fptplay.net')

		r = s.post(url_login, headers=headers, data=params)
			
		headers = { 
					'Referer'			: url,
					'X-KEY'				: '123456',
					'X-Requested-With'	: 'XMLHttpRequest'
				}
	
		#Kiểm tra live tivi 
		match = re.search(r'\/livetv\/(.*)$', url)
		if match:
			id = match.group(1)
			data={'id':id,'type':'newchannel','quality':'3','episode':epi,'mobile':'web'}
			r = s.post('https://fptplay.net/show/getlinklivetv',headers=headers, data=data)
			json_data = json.loads(r.content)
			return json_data['stream']+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0&Referer=https://fptplay.net/livetv/'
									
		match = re.search(r'\-([\w]+)\.html', url)
		if not match:return ''
		id = match.group(1)
		
		match = re.search(r'#tap-([\d]+)$', url)		
		if match:epi = match.group(1)
		else:epi = 1	
		
		data={'id':id,'type':'newchannel','quality':'3','episode':epi,'mobile':'web'}
		r = s.post('https://fptplay.net/show/getlink',headers=headers, data=data)
		json_data = json.loads(r.content)
		return json_data['stream']+'|User-Agent=Mozilla/5.0'
	

def	getInfo(id,href,titleVn,titleEn,img,year,eps='',quocgia='',theloai='',daodien='',dienvien='',thoiluong='',IMDb='',desc=''):
	info='{'
	info+='"id":"%s"'%id
	info+=',"href":[%s]'%href
	info+=',"titleVn":'+json.dumps(titleVn)		
	info+=',"titleEn":'+json.dumps(titleEn)
	info+=',"thumb":'+json.dumps(img)	
	info+=',"year":'+json.dumps(year)	
	info+=',"episode":'+json.dumps(eps)	
	
	info+=',"country":'+json.dumps(quocgia)
	info+=',"genre":'+json.dumps(theloai)
	info+=',"writer":'+json.dumps(daodien)
	info+=',"director":'+json.dumps(dienvien)
	info+=',"duration":'+json.dumps(thoiluong)
	info+=',"rating":'+json.dumps(IMDb)				
	info+=',"plot":'+json.dumps(desc)
	info+='}'
	info=info.replace('/','\/')	
	
	return info
			
class XuongPhim:
	def __init__(self):
		self.home='http://xuongphim.tv'

	def additems(self,url,page=0):
		body = xread(url);items=[]
		for content in re.findall('<li>\s*<div class="tn-bxitem">(.+?)</ul>',body,re.S):
			titleVn=xsearch('<p class="name-vi">(.+?)</p>',content).strip()
			titleEn=xsearch('<p class="name-en">(.+?)</p>',content).strip()
						
			year=xsearch('( \(\d{4}\))',titleEn)							
			if not year:year=xsearch('( \d{4})',titleEn)
			titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			
			href=self.home+xsearch('<a href="(.+?)"',content).strip()														
			img=xsearch('<img src="(.+?)"',content).strip()
			
			#lay desc truc tiep thau </li> = <div class="clearfix"> o content
			#desc=xsearch('<div class="tn-contentdecs mb10">(.+?)</div>',content,1,re.DOTALL)											
			
			label=xsearch('<span title="Chất lượng HD (.+?)"',content)			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
						
			#<span class="tn-pcolor1">Phim phim lẻ</span>
			eps = xsearch('S&#7889; T&#7853;p: (.+?)</p>',content)				
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
			
			if page:pass
			else:items.append((title,href,img,isFolder))		

		if not page:
			for href, pagenext in re.findall('<a rel=".+?" href="(.+?)">(.+?)</a>',body):
				if pagenext == 'Next':
					href=self.home+href
					title='[COLOR lime]Trang tiếp theo: ...[/COLOR]'
					items.append((title,href,'image',True))															
			
		return items
		
	def eps(self,url):
		id=xsearch('-(\d+)\.html',url)		
		#id = re.search('-(\d{1,6})\.html',url).group(1)
		page=1;items=[]
		while True:		
			b=xread('http://xuongphim.tv/?film=%s&episode=&page=%d&searchep='%(id,page))
						 			
			items+=[('http://xuongphim.tv'+j[0],j[1]) for j in re.findall('href="(.+?)">(.+?)</a>',b)]
			page+=1			
			
			pn=xsearch('<a class="active"[^<]+>\d+</a><[^<]+>(\d+)</a>',b)
			if not pn:break
			
		return items				
		
class hdonline:
	def __init__(self):
		self.home='http://hdonline.vn'

	def additems(self,url,page=0):
		body = xread(url);items=[]
		for content in re.findall('<li>\s*<div class="tn-bxitem">(.+?)</ul>',body,re.S):
			titleVn=xsearch('<p class="name-en">(.+?)</p>',content).strip()
			titleEn=xsearch('<p class="name-vi">(.+?)</p>',content).strip()
			
			href='http://hdonline.vn'+xsearch('<a href="(.+?)"',content).strip()
			year=xsearch('<p>Năm sản xuất:(.+?) </p>',content).strip()
			if year in titleVn:titleVn=titleVn.replace(year,'').strip()			
			if year in titleEn:titleEn=titleEn.replace(year,'').strip()			
												
			img=xsearch('<img src="(.+?)"',content).strip()
			
			#lay desc truc tiep thau </li> = <div class="clearfix"> o content
			#desc=xsearch('<div class="tn-contentdecs mb10">(.+?)</div>',content,1,re.DOTALL)											
			

			if 'Cinderella Girls 2nd Season' in titleVn:titleVn='The iDOLM@STER Cinderella Girls 2nd Season'
			if 'Cinderella Girls 2nd Season' in titleEn:titleEn='The iDOLM@STER Cinderella Girls 2nd Season'
			
			log(re.search('.hụ .ề .iệt',content))
			if re.search('.huyết .inh',content):
				label='Thuyết minh'
			elif re.search('.hụ .ề .iệt',content):
				label='Phụ đề Việt'
			else:label=''
			#label=xsearch('<span title="Chất lượng HD (.+?)"',content)
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			
			IMDb = xsearch('Đánh giá: (.+?) </p>',content)				
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
			
			eps = xsearch('Số Tập: (.+?) </p>',content)				
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
						
			if page:				
				b = xread(href)
				desc=xsearch('itemprop="description">(.+?)</div>',b,1,re.DOTALL)
				desc=re.sub('<(.+?)>','',desc).replace('\n','')

				v_theloai=xsearch('<li>Thể loại:(.+?)</li>',b)
				theloai=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_theloai))
				
				v_quocgia=xsearch('<li>Quốc gia:(.+?)</li>',b)
				quocgia=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_quocgia))
				
				thoiluong=xsearch('<li>Thời lượng: (.+?)</li>',b).strip()
				
				v_daodien=xsearch('Đạo diễn: .*?">(.+?)</li>',b).strip()				
				daodien=', '.join(i.strip() for i in re.findall('<a href=".+?">(.+?)</a>',v_daodien))			
				dienvien=', '.join(i.strip() for i in re.findall('<a href=".+?" class="tn-pcolor1">(.+?)</a>',b))
										
				id= 'hdonline-'+xsearch('-(\d+?)\.html',href)
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)													
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))				
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))			
			
		if not page:
			href=xsearch('<a rel="nofollow" href="(.+?)">',body,1,re.DOTALL)
			if href:
				pages=''
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%(pages)
				items.append((title,href,'image',True))											
		return items
		
	def eps(self,url):
		id=xsearch('-(\d+)\.html',url)		
		page=1;items=[]
		while True:		
			b=xread('http://hdonline.vn/episode/ajax?film=%s&episode=&page=%d&search='%(id,page))
			items+=[('http://hdonline.vn'+j[0],j[1]) for j in re.findall('href="(.+?)".*data-order="(.+?)"',b)]
			page+=1			
			
			pn=xsearch('<a class="active"[^<]+>\d+</a><[^<]+>(\d+)</a>',b)
			if not pn:break
			
		return items
		
	def getLink(self,url):
		return get_hdonline(url)

class TVHay:				
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://tvhay.org/'}
	

	def additems(self,url):				
		b=xread(url);items=[]
		for s in re.findall('(<div class="inner">.+?</li>)',b,re.DOTALL):
			title=xsearch('title="(.+?)"><span',s)
			titleVn=xsearch('Xem phim </span>(.+?)</a>',s)
			titleEn=xsearch('<div class="name2">\s*(.+?)</div>',s).strip()			
			year=xsearch('<div class="year">\s*(.+?)</div>',s).strip()
			label=xsearch('<div class="status">\s*(.+?)</div>',s).strip()
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			href=xsearch('href="(.+?)"',s);img=xsearch('src=".+?url=(.+?)"',s)
			
			if not img:
				s=[i[1] for i in items if i[0]==href]
				if s:img=s[0]
			
			if href:items.append((title,href,img,False))
			
		last=xsearch('<a class="last" href="(.+?)">',b)		
		if last:
			pages=xsearch('/(\d+)/',last)

			href=xsearch('rel="next" href="(.+?)">',b)			
			page=xsearch('/(\d+)/',href)
			title='[COLOR lime]Trang tiếp theo: %s/%s[/COLOR]'%(page,pages)
			items.append((title,href,'image',True))

		return items
						
class BiluTV:		
	def __init__(self):
		self.home='http://bilutv.com/'
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36'}
		
	def additems(self,url,page=0):		
		body=xread(url);items=[]
		
		cl='film-item '
		for s in re.findall('(<li class="%s.+?</li>)'%cl,body,re.DOTALL):
			href=self.home+xsearch('href="/(.+?)"',s)
			img=xsearch('original="(.+?)"',s)
			titleVn=xsearch('<p class="name">(.+?)</p>',s)
			titleEn=xsearch('<p class="real-name">(.+?)</p>',s)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			#quality=xsearch('<span class="label-quality">(.+?)</span>',s)
			label=xsearch('<label class="current-status">(.+?)</label>',s)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
												
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False

			#if 'Thuyết Minh' in label:title='[COLOR blue]TM[/COLOR] '+title
		
			if page:
				id= 'bilutv-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:							
			pn=re.search('<a href="/[^<]+?" >(\d+)</a></li><li><a href="/([^<]+?)" class="navigation next" rel="next">',body)
			if pn:
				href=self.home+pn.group(2);pages=pn.group(1)
				title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%pages
				items.append((title,href,'image',True))
			else:
				pn=re.search('<a href="[^<]+?" >(\d+)</a></li><li><a href="([^<]+?)" class="navigation next" rel="next">',body)
				if pn:
					href=url.split('?')[0]+pn.group(2);pages=pn.group(1)
					title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%pages
					items.append((title,href,'image',True))
											
		return items

	def eps(self,url):	
		if '/xem-phim/' not in url:
			body=xread(url)
			fanart=xsearch('<img alt=".*?" src="(.+?)"',body)
			url=xsearch('<a href="(.*?/xem-phim/.+?)">',body)
			if self.home not in url:url=self.home+url
		
		body = xread(url)
		server=xsearch('(<ul class="choose-server">.+?/ul>)',body,1,re.DOTALL)		
		
		if server and re.search('class="list-episode"',body):		
			for href,title in re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server):
				if re.search('Thuyet Minh',no_accent(title)):
					body = xread(self.home+href)
					s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)					
					return re.findall('href="(.+?)">(.+?)</a>',s)
		elif server:		
			return re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server)			
		
		s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)
		items=re.findall('href="(.+?)">(.+?)</a>',s)
		return items		
		

		
class PhimBatHu:
	def __init__(self):
		self.home='http://phimbathu.com'
		
	def additems(self,url,page=0):
		b=xread(url);items=[]

		s=xsearch('(id="content".+?class="right-content")',b,1,re.DOTALL)
		for i in re.findall('(<li class="item.+?/li>)',s,re.DOTALL):
			titleVn=xsearch('title="(.+?)"',i)
			titleEn=xsearch('class="name-real">\s*<span>(.+?)</span>',i)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			label=xsearch('"label">(.+?)<',i)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			#if re.search('.huyết .inh',i):title='[COLOR blue]TM[/COLOR] '+title
			href=xsearch('href="(.+?)"',i)
			if '//' not in href:href='http://phimbathu.com'+href
			img=xsearch('src="(.+?)"',i,result=xsearch('data-original="(.+?)"',i))
							
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False

			
			if page:
				id= 'phimbathu-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:
			pn=xsearch('<a href="([^<]+?)" class="navigation next"',s)
			if pn:
				pages=xsearch('>(\d+?)</a></li><li><a href="[^<]+?" class="navigation next"',s)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,'http://phimbathu.com'+pn,'image',True))
			
		return items
			

class XemPhimBox:

	def additems(self,url,page=0):
		items=[]
		content = xread(url)

		for s in [i for i in content.split('<div class="item col-lg-3 col-md-3 col-sm-6 col-xs-6">') if '<div class="inner">' in i]:
			href=xsearch('href="(.+?)"',s)
			title=xsearch('title="(.+?)">',s).strip()
			img=xsearch('src="(.+?)"',s)
								
			titleEn=xsearch('</a> <dfn>(.+?)</dfn>',s)
			titleVn=title.replace(' - '+titleEn,'')
			year=xsearch('</dfn> <dfn>(.+?)</dfn>',s)			
			label=xsearch('<span class="status">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			

			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False
		
			if page:
				id= 'xemphimso-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
				
		return items	


			
class VietSubHD:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}

	def additems(self,url,page=0):
		b=xread(url);items=[]
		if '/videos' in url:p='(<span class="video.+?/a>)'
		else:p='(<a class="poster".+?/div>)'

		for s in re.findall(p,b,re.S):
			title=xsearch('title="(.+?)"',s)
			titleEn=xsearch('</a> <dfn>(.+?)</dfn>',s)
			titleVn=title.replace(' - '+titleEn,'')
			year=xsearch('</dfn> <dfn>(.+?)</dfn>',s)			
			label=xsearch('<span class="status">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			

			href=xsearch('href="(.+?)"',s)
			img=xsearch('url=([^<]+jpg)',s)
			img=img.replace('w35-h35','w180-h240').replace('Poster.','')
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False
		
			if page:
				id= 'vietsubhd-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:			
			pn=xsearch('class="current".+?<a href="([^"]+?)"[^<]*?>\d+<',b)
			if pn:
				pages=xsearch('-(\d+)\.html" title="Trang cuối">',b)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,pn,'image',True))
			
		return items	
		

class HDSieuNhanh:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		self.urlhome='http://hdsieunhanh.com/'		

	def eps(self,url):
		content=xread(url)
		s=xsearch('(<ul class="list_episode".+?/ul>)',content,1,re.DOTALL)
		return re.findall('href="(.+?)">(.+?)</a>',s)
		
	def additems(self,url,page=0):
		content=xread(url);items=[]		
		for s in [i for i in content.split('<div class="block-base movie">') if 'data-id' in i]:
			title=xsearch('alt="(.+?)"',s)
			titleEn=xsearch('class="film-name"><h2>(.+?)</h2>',s)
			titleVn=xsearch('</h2>(.+?)</a>',s).strip()
			href=xsearch('href="(.+?)"',s)
			#if 'html' not in href:href=self.urlhome+href
			img=xsearch('src="(.+?)"',s).replace('amp;','')
			rate=xsearch('"rate">([^<]+?)</span>',s)
			if rate:title='%s [COLOR green]%s[/COLOR]'%(title,rate)
			eps=' '.join(re.sub('<[^<]+?>','',xsearch('(<span class="label-range">.+?<strong>\d+?</strong>)',s)).split())
			if '"tag bitrate1 "' in s:title='%s [COLOR lime]CAM[/COLOR]'%title
			elif '"tag bitrate0 "' in s:title='%s [COLOR lime]HD[/COLOR]'%title
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
		
		
			if page:
				id= 'hdsieunhanh-'+xsearch('-(\d+?)\.html',href);year=''
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:				
			pn=xsearch('<a href="([^"]+?)">Sau</a>',content)
			if pn:
				pn=self.urlhome+pn.replace('amp;','')
				pages=xsearch('=(\d+)">Cuối</a></li></ul>',content)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,pn,'image',True))
		
		return items
		
	
		
class hdviet:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,url,page=0):
		items=[]
	
		b=xread(url)
		body=xsearch('<ul class="cf box-movie-list">(.+?)<div class="box-ribbon mt-15">',b,1,re.DOTALL)

		pattern='<li class="mov-item".+?href="(.+?)".+?src="(.+?)".+?title="Phim (.+?)".+?<span(.+?) data-id="(.+?)">'	
		data=re.findall(pattern,body,re.DOTALL);listitems=list()
		for href,img,title,detail,id_film in data:
			epi=xsearch('"labelchap2">(\d{1,3})</span>',detail);title=vnu(title)
			res=xsearch('id="fillprofile" class="icon-(.+?)11">',detail)
			res='[COLOR gold]SD[/COLOR]' if 'SD' in res else '[COLOR gold]HD[/COLOR]%s'%res
			phim18=xsearch('class="children11".+?>(.+?)</label></span>',detail)
			TM=xsearch('id="fillaudio" class="icon-(.+?)">',detail)
			TM='%s[COLOR green]%s[/COLOR][COLOR red]%s[/COLOR]'%(res,TM,phim18)
			plot=xsearch('<span class="cot1">(.+?)</span>',detail)
			year=xsearch('<span class="chil-date".+?>(.*?)</label></span>',detail)
			act=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dien-vien/.+?">(.+?)</a>',detail))
			drt=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dao-dien/.+?">(.+?)</a>',detail))
			IMDb=xsearch('<span class="fl-left">.+?<span>(.+?)</span>',detail)
			upl=xsearch('<span class="fl-right">.+?<span>(.+?)</span>',detail)

			if '(' in title and ')' in title:title=title.replace('(','[B]').replace(')','[/B]')
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'			
			
			href='hdviet.com|'+str(id_film)			
			
			isFolder=True
			if epi:
				title = '(' + epi + ') ' + title
				v_mode='episodes';
			else:v_mode='stream';isFolder=False
					
			if page:pass
			else:items.append((title,href,img,isFolder))
						
		if not page:
			s=xsearch('(<ul class="paginglist.+?/ul>)',b,1,re.S)
			href=xsearch('(class="active".+?/ul>)',s,1,re.S)
			href=xsearch('href="(.+?)"',href)
			if href:
				pages=xsearch('>(\d+)<.+?/ul>',s)
				title='[COLOR lime]Trang tiếp theo: %s/%s[/COLOR]'%('...',pages)
				items.append((title,href,'image',True))										
				
		return items
		
	def getResolvedUrl(self,id_film,loop=0):#Phim le/phim chieu/ke doi dau thien ac		
		data=json_rw('hdviet.cookie')
		token = data.get('access_token')
		#token = '22bb07a59d184383a3c0cd5e3db671fc'
		#id_film=id_film.replace('_e','&ep=')
		direct_link='https://api-v2.hdviet.com/movie/play?accesstokenkey=%s&movieid=%s'%(token,id_film)		
				
		result=xread(direct_link)
		try:links=json.loads(result)["r"]
		except:links=dict()
		
		#try:print json.dumps(links,indent=2,ensure_ascii=True)
		#except:pass			
		
		link=links.get('LinkPlay')
		#if not link:return '',''
		#elif '0000000000000000000000' in link:
			#data=login_hdviet();links=getlinkhdviet(data.get('access_token'),id_film);link=links.get('LinkPlay')	
		
		if link:
			#max_resolution='_1920_' if myaddon.getSetting('hdvietresolution')=='1080' else '_1280_'
			max_resolution='_1920_'
			resolutions=['_1920_','_1885_','_1876_','_1866_','_1792_','_1280_','_1024_','_800_','_640_','_480_']
			if '_e' in id_film:link=re.sub('%s_e\d{1,3}_'%id_film.split('_')[0],'%s_'%id_film,link)
			
			r=''.join([s for s in resolutions if s in link]);response=''
			if r:
				href=link[:link.rfind(r)]+link[link.rfind(r):].replace(r,'%s')
				for i in resolutions:
					if i>max_resolution:continue
					response=xread(href%i)
					if len(response)>0:link=href%i;break
			else:
				href=link.replace('playlist.m3u8','playlist_h.m3u8')
				response=xread(href)
				if not response or '#EXT' not in response:
					for s in range(1,6):
						#print re.sub('http://n0\d.vn-hd.com','http://n0%d.vn-hd.com'%s,href)
						if 'http://n0%d'%s in href:continue
						elif re.search('http://n0\d.vn-hd.com',href):
							response=xread(re.sub('http://n0\d.vn-hd.com','http://n0%d.vn-hd.com'%s,href))
						if response and  '#EXT' in response:break
				if not response:response=xread(link)
			
			if response and '#EXT' in response:
				items=re.findall('RESOLUTION=(\d+?)x.*\s(.+m3u8)',response)
				if items:
					res=0;hr=''
					for r,h in items:
						#print r,h
						if int(r)>res:res=int(r);hr=h
					if hr and 'http://' in hr:link=hr
					else:link=os.path.dirname(link)+'/'+hr
				else:
					items=re.findall('(.+m3u8)',response)
					if items and 'http://' in items[0]:link=items[len(items)-1]#;print items[0]
					elif items:link=os.path.dirname(link)+'/'+items[0]
				
			else:link=''
		if not link:return '',''
		audio=links.get('AudioExt',list());audioindex=-1;linksub=''
		if not audio:pass
		elif len(audio)>1:
			#audio_choice=myaddon.getSetting('hdvietaudio')
			audio_choice='Hỏi khi xem-'
			if audio_choice=='Hỏi khi xem':
				title=u'[COLOR green]Chọn Audio[/COLOR]';line1= u'[COLOR yellow]Vui lòng chọn Audio[/COLOR]'
				audioindex=notify_yesno(title,line1,'',audio[0].get("Label",'0'),audio[1].get("Label",'1'))
			else:audioindex=0 if u2s(audio[0].get("Label")) in audio_choice else 1
			if 'Thuyết' not in u2s(audio[audioindex].get("Label")):linksub='yes'#bật cờ download sub
			try:link=link+'?audioindex=%d'%(int(audio[audioindex].get("Index",'0'))-1)
			except:pass
		elif u2s(audio[0].get("Label"))=='Thuyết Minh':audioindex=0
		if audioindex<0 or linksub:
			for source in ['Subtitle','SubtitleExt','SubtitleExtSe']:
				try:linksub=links[source]['VIE']['Source']
				except:linksub=''
				if linksub:break
		#print 'getResolvedUrl: %s - %s'%(link,linksub)
		return link,linksub					

class megabox:		
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,body,mode,page):
		items=[]
		
		for content in re.findall('<div class="item">(.+?)</div><!--',body,re.S):
			item=re.search('src="(.+?)">\s*.*<span class="features">\s*</span>\s*</a>\s*<div class="meta">\s*<h3 class="H3title">\s*<a href="(.+?)">(.+?)</a>',content)
			if item:
				#title=item.group(3)
				href=item.group(2)
				img=item.group(1)							
				
				thoiluong = xsearch('Thời lượng:</strong>(.+?)</li>',content).strip()
				IMDb = xsearch('<span class=\'rate\'>(.+?)</span>',content).strip()
				title=xsearch('<h3 class=\'H3title\'>(.+?)</h3>',content).strip()
				title=vnu(title)				
				id=xsearch('-(\d+?)\.html',href)
				if id == '15740':year='1978'
				else:year = xsearch('Năm phát hành:.*(\d{4})</li>',content).strip()
				if year in title:title=title.replace(year,'').strip()
				quocgia=xsearch('Quốc gia:</strong> (.+?)</li>',content).strip()
				daodien=xsearch('Đạo diễn:</strong> (.+?)</li>',content).strip()
				dienvien=xsearch('Diễn viên:</strong> (.+?)</li>',content).strip()					
			
				theloai=xsearch('Thể loại:</strong> (.+?)</li>',content).strip()
				theloai=theloai.replace('Ma k','K').replace('Khoa học v','V').replace('Sử thi','Lịch sử')
				
				desc=xsearch('<div class=\'des\'>(.+?)</div>',content)
				
				try:					
					titleVn = title.split(" (")[0]
					titleEn = title.split(" (")[1].replace(')','')
					#title = titleVn + ' - ' + titleEn												
				except:titleVn=title;titleEn=''

				eps = xsearch('class=.esp.><i>(.+?)</span>',content).replace('</i>','')					

				id= 'megabox-'+id
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)						
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))											
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))											
		return items		
					
class phimnhanh:				
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,url,page=0):
		body=xread(url);items=[]

		for  s in re.findall('(<li  class="serial">.+?</li>)',body,re.DOTALL):
			href=xsearch('href="(.+?)"',s)
			#title=xsearch('title="(.+?)"',s)
			titleVn=xsearch('<span class="title display">(.+?)</span>',s)
			titleEn=xsearch('<span class="title real">(.+?) \(',s)
			year=xsearch('<span class="title real">.+? \((.+?)\)</span>',s)
			img=xsearch('data-original="(.+?)"',s)
			label=xsearch('<span class="m-label q">(.+?)</span>',s)
			lang=xsearch('<span class="m-label lang">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)											
			
			IMDb=xsearch('<span class="m-label imdb"><span class="rate">(.+?)</span>',s)
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
			
			ep=xsearch('<span class="m-label ep">(.+?)</span>',s)
			if 'tập' in ep:eps=ep;thoiluong='';isFolder=True
			else:thoiluong=ep;eps='';isFolder=False
						
			if page:
				b=xread(href)		

				v_theloai=xsearch('<p>Thể loại:(.+?)</p>',b)
				theloai=', '.join(i.replace('Kinh Dị - Ma','Kinh Dị').replace('Tâm Lý - Tình Cảm','Tâm Lý, Tình Cảm') for i in re.findall('<a href=".+?" title="(.+?)">',v_theloai))						
				
				v_quocgia=xsearch('<p>Quốc gia:(.+?)</p>',b)
				quocgia=', '.join(i.replace('Mỹ - Châu Âu','Âu-Mỹ') for i in re.findall('<a href=".+?" title="(.+?)">',v_quocgia))
				
				v_daodien=xsearch('<p>Đạo diễn:(.+?)</p>',b)
				daodien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_daodien))
				v_dienvien=xsearch('<p>Diễn viên:(.+?)</p>',b)
				dienvien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_dienvien))		
													
				desc=''#xsearch('<p>(.+?)<br></p>',b,1,re.DOTALL)						
			
				id= 'phimnhanh-'+xsearch("javascript:download\('(.+?)'",b)
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
													
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,isFolder))
						
		if not page:
			href=xsearch('<a href="([^>]+?)" rel="next">',body)
			if href:
				href=href.replace('amp;','');pn=xsearch('page=(\d+?)\Z',href)
				ps=xsearch('<a href="[^>]+?">(\d+?)</a></li> <li><a href="[^>]+?" rel="next">',body)
				title='[COLOR lime]Trang tiếp theo: %s/%s[/COLOR]'%(pn,ps)
				items.append((title,href,'image',True))			
										
		return items	
								
class phimmoi:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.phimmoi.net'}

	def additems(self,url,page=0):
		body=xread(url);items=[]
		
		for s in re.findall('(<li class="movie-item">.+?</li>)',body,re.DOTALL):
			#title=xsearch('title="(.+?)"',s)
			titleVn=xsearch('<span class="movie-title-1">(.+?)</span>',s)
			titleEn=xsearch('<span class="movie-title-2">(.+?)</span>',s)
			if '(' in titleVn and ')' in titleVn:titleVn=titleVn.replace(' (', ' - ').replace(')', '')			
			if '(' in titleEn and ')' in titleEn:titleEn=titleEn.replace(' (', ' - ').replace(')', '')
			#duration=xsearch('>(\d{1,3}.?phút)',s)
			label=xsearch('"ribbon">(.+?)</span>',s)
			href=xsearch('href="(.+?)"',s)
			if 'phimmoi.net' not in href:href='http://www.phimmoi.net/'+href
			img=xsearch('url=(.+?)%',s)
			
			b=xread(href)
			thoiluong = xsearch('Thời lượng:</dt><dd class="movie-dd">(.+?)</dd>',b)
			IMDb = xsearch('<dd class="movie-dd imdb">(.+?)</dd>',b)			
			quocgia=', '.join(i for i in re.findall('<a class="country" href=".+?" title=".+?">(.+?)</a>',b))
														
			theloai = ', '.join(i for i in re.findall('<a class="category" href=".+?" title="(.+?)">',b,re.S) if 'lẻ' not in i and 'bộ' not in i)#Phim bộ Hàn 
			theloai=theloai.replace('Phim Bí ẩn-Siêu nhiên','Phim Bí ẩn').replace('Phim hồi hộp-Gây cấn','Phim hồi hộp')
			theloai=theloai.replace('Phim tình cảm-Lãng mạn','Phim tình cảm').replace('Phim ','')
						
			desc=xsearch('id="film-content"><p>(.+?)\s*</p>',b,1,re.DOTALL)#<br><br>
			desc=re.sub('<(.+?)>','',desc)

			if 'Năm:</dt><dd class="movie-dd">' in b:
				year = xsearch('Năm:</dt><dd class="movie-dd">.+?(\d{1,4})</a>',b,1,re.DOTALL)
			elif 'Ngày phát hành:</dt><dd class="movie-dd">' in b:
				year = xsearch('Ngày phát hành:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)
			else:
				year = xsearch('Ngày ra rạp:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)			
			
			if '(' in titleVn: titleVn=titleVn.replace('(','- ').replace(')','')
			if '(' in titleEn: titleEn=titleEn.replace('(','- ').replace(')','')
			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)														
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'
							
			eps=xsearch('Tập ?(\d{,4}/\d{,4}|\?/\d{,4}|\d{,4})',s)
			if not eps:
				epi=xsearch('class="eps">Trọn bộ ?(\d{1,4}) ?tập</div>',s)
				if epi:eps='%s/%s'%(epi,epi)
			else:epi=eps.split('/')[0]
			try:epi=int(epi)
			except:epi=0
			
			if eps:isFolder=True
			else:isFolder=False
						
			daodien=', '.join(i for i in re.findall('<a class="director" href=".+?" title="(.+?)">',b))
			dienvien=', '.join(i for i in re.findall('<span class="actor-name-a">(.+?)</span>',b))
			
			if xsearch('<dd class="movie-dd status">Trailer',b,0):continue						
			
			if page:
				id= 'phimmoi-'+xsearch('-(\d+?)\/',href)
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)
							
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))						
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))																
			else:items.append((title,href,img,isFolder))
			
		if not page:
			href=xsearch('<li><a href="(.+?)">Trang kế.+?</a></li>',body)
			if href:
				if not href.startswith('http'):href='http://www.phimmoi.net/'+href			
				title='[COLOR lime]Trang tiếp theo: ...[/COLOR]'
				if href:items.append((title,href,'image',True))			
			
		return items
						
class Fcine:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest'}
		self.cookie=''

	def additems(self,url,page=0):
		b=xread(url,self.hd).replace('\\n','').replace('\\t','').replace('\\r','');items=[]
		try:j=json.loads(b)
		except:j={}
		s = j.get('rows','').encode('utf-8')
		
		S=re.findall('(<div class="esnList_item".+?/ul>)',s,re.S)
		if not S:S=re.findall('(<li.+?/li>)',s,re.S)
		for s in S:
			title=xsearch("title='(.+?)'",s,result=xsearch('title="(.+?)"',s)).replace('&#039;',"'")
			titleVn=xsearch('<div class="ipsTruncate ipsTruncate_line ipsType_blendLinks ipsType_light".+?>\s*(.+?)</div>',s)			
			titleEn=xsearch('<div class="ipsTruncate ipsTruncate_line" data-ipsTruncate.+?>\s*(.+?)</div>',s).replace('&#039;',"'")
			year=xsearch('( \(\d{4}\))',titleEn)							
			if not year:year=xsearch('( \d{4})',titleEn)
			titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			if 'HDRip.png' in s:label='HDRip'
			elif 'Bluray.png' in s:label='Bluray'
			elif 'WEBrip.png' in s:label='WEBrip'
			elif 'WEB-DL.png' in s:label='WEB-DL'
			elif 'DVDrip.png' in s:label='DVDrip'
			else:label=''						
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			href=xsearch('href="(.+?)"',s)						
			img=xsearch('src="(.+?)"',s);eps=''
					
			if page:									
				id= 'fcine-'+xsearch('view/(\d+?)-',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
				
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,False))
		
		if not page:		
			pagination=j.get('pagination','').replace('&amp;','&').encode('utf-8')
			p=xsearch("data-page='(\d+)' data-ipsTooltip title='Next page'",pagination)
			if p:
				href=xsearch("href='([^']+?)' data-page='%s'"%p,pagination)
				title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%p
				if href:items.append((title,href+'&listResort=1','image',True))
			
		return items
		
class vaphim:		
	def additems(self,url,page=0,query='phim-le'):
		body=xread(url);items=[]
		pattern='<a data=.+?src="(.+?)[\?|\"].+?<h3.+?><a href="(.+?)" rel=.+?>(.+?)</a></h3>'
		for img,href,title in re.findall(pattern,body,re.DOTALL):
			title=re.sub('</br>|<br/>','<br />',title)
		
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')						
			try:
				titleVn=title.split(' <br /> ')[0].strip()
				titleEn=title.split(' <br /> ')[1].strip()										
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)					
			
			label=''						
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			
			
			if page:
				b = xread(href);v_b=re.sub('<(.+?)>','',b.replace('<br />','[]'))					
				
				if not year:
					year = xsearch('Năm sản xuất:(.+?)\[\]',v_b).strip()	
				
				thoiluong = xsearch('Thời lượng:(.+?)\[\]',v_b).strip()
				IMDb = xsearch('Đánh giá:(.+?)/10.*',v_b).strip()
				
				quocgia=xsearch('Quốc gia:(.+?)\[\]',v_b).strip()			
				daodien=xsearch('Đạo diễn:(.+?)\[\]',v_b).strip()
				dienvien=xsearch('Diễn viên:(.+?)\[\]',v_b).strip()				
				dienvien = dienvien.replace('-trong-vai:-','')
				
				theloai=xsearch('Thể loại:(.+?)\[\]',v_b).strip()
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				
				desc=vnu(xsearch('Nội dung:</span></strong></h2>\s*<p>(.+?)</p>',b))
						
				eps = ""
																														
				tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
				if tabs:								
					for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
						content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
						label=subtitle=url=''
						for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
							if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
							elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
								subtitle=href
							elif '/file/' in href:url=href;label=tab_label											
							elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
						
						if url:
							v_url='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'
							if v_href:v_href+=','+v_url
							else:v_href=v_url
						
						#break #chi lay tab dau tien
				else:
					pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
					label=subtitle=url=''
					for href, fn in re.findall(pattern,b):
						if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
						elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
							subtitle=href
						elif '/file/' in href:url=href;label=''											
						elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
						
					if url:v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'


				id= 'vaphim-'+xsearch('#tabs-(.+?)-',b)
				info=getInfo(id,v_href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)				
								
				if v_href:items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,True))

		if not page and False:
			pagelast=xsearch("<span class='pages'>Trang \d{1,4} của (\d{1,4})</span>",body)
			if pagelast and int(pagelast)>page:
				title='[COLOR lime]Trang tiếp theo: ...[/COLOR]'%(page+1,pagelast)
				href=href.replace('page/%d'%page, 'page/%d'%(page+1))
				if href:items.append((title,href,'image',True))							
			
		return items
	
class fsharefilm:		
	def additems(self,body,mode,page,query):
		items=[]
		for href in re.findall('<div class="movie col-xs-6 col-sm-4 col-md-3 col-lg-3">\s*<a class="wrap-movie-img" href="(.+?)">',body,re.S):						
			b = xread(href)
			if 'Phim Bộ' in xsearch('<ol class="breadcrumb">(.+?)</ol>',b,1,re.DOTALL):#query=='phim-le' and 
				continue
			
			title=xsearch('"name": "(.+?)",',b)
			title=title.replace(' &#8211; ','<br />')
			
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')
			else:year = xsearch('<b>Năm Phát Hành:</b></p>\s*<p class="info">(.+?)</p>',b).strip()			
			
			try:
				titleVn=title.split('<br />')[0]
				titleEn=title.split('<br />')[1]
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)
			
			img=xsearch('"url":"(.+?.jpg)"',b)
	
			thoiluong = ''#xsearch('Thời lượng:</strong> (.+?)</li>',b).strip()
			IMDb = xsearch('<b>IMDB:</b></p>\s*<p class="info">(.+?)/10</p>',b).strip()			
			quocgia=xsearch('<b>Quốc Gia:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			daodien=xsearch('<b>Đạo Diễn:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			dienvien=xsearch('<b>Diễn Viên:</b></p>\s*<p class="info">(.+?), </p>',b).strip()
			dienvien=dienvien.replace('-trong-vai:-','')
									
			v_theloai=xsearch('<b>Thể Loại:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			theloai=', '.join(i.replace('Phim','') for i in re.findall('<a href=".+?" rel="category tag">(.+?)</a>',v_theloai))
			
			desc=xsearch('<h2>\s*<p>Cốt Truyện</h2>(.+?)</p>',b)			
			
			eps = ""
			
			tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
			if tabs:								
				for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
					content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
					label=subtitle=url=''
					for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
						if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
						elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
							subtitle=href
						elif '/file/' in href:url=href;label=tab_label											
						elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
					if url:
						v_url='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'
						if v_href:v_href+=','+v_url
						else:v_href=v_url
					
					#break #chi lay tab dau tien
			else:
				pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
				label=subtitle=url=''
				for href, fn in re.findall(pattern,b):
					if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
					elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
						subtitle=href
					elif '/file/' in href:url=href;label=''											
					elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
				if url:v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'					

			id= 'fsharefilm-'+xsearch('#tabs-(.+?)-',b)
			info=getInfo(id,v_href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)				
													
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
			if v_href:items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
		return items

class television:
	def additems(self,url,page=0):
		items=[]
		content = xread(url)
		if 'htvonline.com.vn' in url:
			for s in [i for i in content.split('<div class="channels_htvc">') if 'view_title2' in i]:
				title=xsearch('<div class="view_title2"><div>(.+?)</div></div>',s).strip()
				title='[COLOR yellow]%s[/COLOR]'%vnu(title)
				items.append((title,'','',False))				
				for title,href,img in re.findall('href="(.+?)" data-original="(.+?)">.+?src="(.+?)"></a>',s):
					title=xsearch('/([\w|-]+)-\d',title).upper()
					items.append((title,href,img,False))
		elif 'fptplay.net/livetv' in url:
			fpt=fptPlay()
			for s in [i for i in content.split('<div id="box_') if ' class="livetv_header' in i]:
				title=xsearch('<span class="livetv_header Regular pull-left" style="margin-right: 7px;">(.+?)</span>',s)
				title='[COLOR yellow]%s[/COLOR]'%vnu(title)
				items.append((title,'','',False))
				for title,href,img,dir in [fpt.detail(i) for i in re.findall('(<a class="tv_channel.+?/a>)',s,re.S)]:
					items.append((title,href,img,False))		
		return items
		
class Football:			
	def additems(self,url,page=0):
		items=[]
		content = xread(url)
		if 'fullmatchreplay.com' in url:
			for s in [i for i in content.split('<div class="one_third columns item musical isotope-item" style="">') if 'ts-display-pf-img' in i]:
				href=xsearch('href="(.+?)">',s);href='http://fullmatchreplay.com/'+href
				title=xsearch('<span>(.+?)</span>',s).strip()
				view=xsearch('<div class="views">Views: (.+?)</div>',s)
				img=xsearch('src="(.+?)"',s)
				items.append((title,href,img,True))
		elif 'socceryou.com' in url:
			for s in [i for i in content.split('<div class="foto-video">') if 'class="video"' in i]:
				href=xsearch('href="(.+?)"></a>',s);href='http://socceryou.com/en/'+href				
				title=xsearch('title="(.+?)"',s)				
				img=xsearch('src="(.+?)"',s)
				items.append((title,href,img,True))
				 				
		return items
		
	def eps(self,url):
		items=[]	
		content = xread(url)	
		if 'fullmatchreplay.com' in url:		
			for href,title in re.findall('href=\'(.+?)\'>(.+?)</a>',content):		
				href='http://fullmatchreplay.com/'+href
				items.append((title,href))
		elif 'socceryou.com' in url:
			#b=xsearch('<div class=\'video_button\'>(.+?)</iframe>',content)
			for href,title in re.findall('href=\'(.+?)\'>(.+?)</a>',content):		
				href='http://socceryou.com/en/'+href
				items.append((title,href))
		
		return items
		
	def getLink(self,url):		
		content=xread(url)
		if 'fullmatchreplay.com' in url:
			id=xsearch('"https://www.youtube.com/embed/(.+?)"',content)
			if id:link='plugin://plugin.video.youtube/?action=play_video&videoid=%s'%id
			else:						
				id=xsearch('videos/v2/(\d+)/zeus',content)
				link='https://config.playwire.com/19004/videos/v2/%s/abr-non-hd.m3u8'%id
		elif 'socceryou.com' in url:
			id=xsearch('"https://www.youtube.com/embed/(.+?)"',content)
			if id:link='plugin://plugin.video.youtube/?action=play_video&videoid=%s'%id
			else:				
				src=xsearch('<iframe src="(.+?)"',content)
				if 'dailymotion.com' in src:				
					notify('Chưa xử lý server dailymotion.com!')
					return ''
				else:
					content=xread(src)				
					link=xsearch('file:	\'(.+?)\'',content)			
		return link

def youtubeDL(url):
	try:import YDStreamExtractor;vid=True
	except:vid=False;mess(u'Cài đặt module youtube.dl để get link phim này')
	if vid:
		vid=YDStreamExtractor.getVideoInfo(url)
		if vid:
			link=xget(vid.streamURL().split('|')[0])
			if link:
				link=link.geturl()
				mess('Xshare get link on Youtube.dl module','Notification')
		else:link=''
	return link		
		
class hdvietnam:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.hdvietnam.com/forums/'}
		self.urlhome='http://www.hdvietnam.com/'
						
	def forums(self,url):
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		
		content=xread(url,self.hd).split('<div class="titleBar">')[-1]
		items=[]
		for s in [i for i in re.findall('(<li id="thread.+?/li>)',content,re.S) if 'class="sticky"' not in i]:
			id=xsearch('id="thread-(.+?)"',s)
			
			b=xsearch('<h3 class="title">(.+?)</h3>',s,1,re.DOTALL)
			
			href=self.urlhome+xsearch('<a href="(.+?)"',b)				
			title=xsearch('data-previewUrl=".*">(.+?)</a>',b)
			#img=xsearch('<img src="(.+?)"',content)
			items.append((id,cleans(title),href))
			
		pn=xsearch('<a href="(.+?)" class="text">Ti.+ &gt;</a>',content)
		if pn:
			pn=self.urlhome+pn
			items.append(('pageNext','[COLOR lime]Trang tiếp theo: %s[/COLOR]'%xsearch('/page-(\d+)',pn),pn))
		return items
		
	def threads(self,url):
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;|<','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		def srv(link):return [i for i in srvs if i in link]
		#srvs=['fshare.vn','4share.vn','tenlua.vn','subscene.com','phudeviet.org','youtube.com']
		srvs=['fshare.vn', 'docs.google.com']
		items=[]
		def getTitle(title,href,s):
			t=title
			if [i for i in srvs if i in title] or not title:
				title=xsearch('<b>Ðề: (.+?)</b>',s)
				if not title:
					title=' '.join(xsearch('<div style="text-align: center".+?>(\w[^<]+?)<',s).split())
			elif 'download' in title.strip().lower():
				title=xsearch('class="internalLink">([^<]+?)<',s[s.find(href)-500:])
				if not title:title=xsearch('<title>(.+?)</title>',content)
			if not title:title=t
			title=cleans(title)
			return title
		
		content=xread(url,self.hd)
		for s in re.findall('(<li id="post-.+?/li>)',content,re.S):
			img=xsearch('<img src="([^"]+?)" class="',s)
			if not img:img=xsearch('<img src="(.+?jpg)"',s)
			i=s
			while 'header-' in img and 'ogo' not in img:
				i=i[i.find(img)+10:]
				img=xsearch('<img src="(.+?jpg)"',i)
			
			i=re.findall('<a href="([^"]+?)" target="_blank"[^<]+?>(.+?)</a>',s)
			i= [(getTitle(title,href,s),href,img) for href,title in i if srv(href)]
			if i:items+=i
			else:items+=[('',i,img) for i in re.findall('(http[\w|:|/|\.|\?|=|&|-]+)',s.replace('amp;','')) if srv(i)]
			
		temp=[];list=[]
		for i in items:
			if i[1] not in temp:temp.append(i[1]);list.append(i)
		return list

################