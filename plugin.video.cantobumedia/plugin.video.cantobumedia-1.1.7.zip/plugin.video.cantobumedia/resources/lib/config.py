import xbmc, xbmcaddon, os

hayhaytv_vn = 'http://www.hayhaytv.vn/'
hdviet_com = 'http://movies.hdviet.com/'
dangcaphd_com = 'http://dangcaphd.com/'
megabox_vn = 'http://phim.megabox.vn/'
phimgiaitri_vn = 'http://phimgiaitri.vn/'
phimmoi_net = 'http://www.phimmoi.net/'

#url = 'http://api.vietmedia.kodi.vn/play/v1/tivi/play/2'	#vietmedia play
#url = 'http://api.vietmedia.kodi.vn/xmio/v1/play/2'		#vietmedia movie
hdonlinevn = 'http://api.vietmedia.kodi.vn/hho/v1/play/'
megaboxvn = 'http://api.vietmedia.kodi.vn/mb/v1/play/'
vuahdtv = 'http://api.vietmedia.kodi.vn/play/v1/vuahd/play/'
#phimgiaitrivn = 'http://api.vietmedia.kodi.vn/pgt/v1/play/'
phimmoinet = 'http://api.vietmedia.kodi.vn/pm/v1/play/'

csn = 'http://chiasenhac.com/'
csn_logo ='http://chiasenhac.com/images/logo_csn_300x300.jpg'
nct = 'http://m.nhaccuatui.com/'
nct_logo ='http://stc.id.nixcdn.com/10/images/logo_600x600.png'