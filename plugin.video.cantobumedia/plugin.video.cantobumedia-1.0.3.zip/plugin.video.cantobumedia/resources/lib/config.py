hayhaytv_vn = 'http://www.hayhaytv.vn/'
hdviet_com = 'http://movies.hdviet.com/'
dangcaphd_com = 'http://dangcaphd.com/'

#url = 'http://api.vietmedia.kodi.vn/play/v1/tivi/play/2'	#vietmedia play
#url = 'http://api.vietmedia.kodi.vn/xmio/v1/play/2'		#vietmedia movie
hdonline_vn = 'http://api.vietmedia.kodi.vn/hho/v1/play/'
megabox_vn = 'http://api.vietmedia.kodi.vn/mb/v1/play/'
vuahd_tv = 'http://api.vietmedia.kodi.vn/play/v1/vuahd/play/'
#phimgiaitri_vn = 'http://api.vietmedia.kodi.vn/pgt/v1/play/'
phimmoi_net = 'http://api.vietmedia.kodi.vn/pm/v1/play/'