# -*- coding: utf-8 -*-
__author__ = 'phuoclv'
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,urllib,urllib2,re,os,unicodedata,datetime,time,random,json,requests
import base64
import httplib2

from xbmcswift2 import Plugin#, xbmc, xbmcaddon, xbmcgui, actions

myaddon=xbmcaddon.Addon()
home=xbmc.translatePath(myaddon.getAddonInfo('path'))
data_path = xbmc.translatePath(os.path.join(home, 'resources', 'data'))
sys.path.append(os.path.join(home,'resources','lib'))
from urlfetch import get,post
from BeautifulSoup import BeautifulSoup
from servers import *
from utils import *

plugin         = Plugin()
pluginrootpath = "plugin://plugin.video.cantobumedia"
cache=xbmc.translatePath(os.path.join(home,".cache"))
http=httplib2.Http(cache, disable_ssl_certificate_validation=True)
query_url      = "https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1&tq={tq}"
sheet_headers  = {
	"User-Agent"      : "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.3; WOW64; Trident/7.0)",
	"Accept-Encoding" : "gzip, deflate, sdch, br"
}

reload(sys);sys.setdefaultencoding("utf8")
###-----------------	
def getValue(colid):
	'''
	Hàm lấy giá trị theo cột của của mỗi dòng sheet
	Parameters
	----------
	colid : string
		Số thự tự của cột
	'''
	if colid is not None: return colid["v"]
	else: return ""
def getItems(url):
	#https://docs.google.com/spreadsheets/d/1XGjnEvBH1lqu5jo9ipdC2w1UcPlRPJGJQtK5R_G1x6A/edit#gid=1062297405

	sheet_id = re.compile("/d/(.+?)/").findall(url)[0]
	try:
		gid = re.compile("gid=(\d+)").findall(url)[0]
	except:
		gid = "0"
	'''
	resp, content = http.request(plugin.get_setting("GSheetURL"),"HEAD")
	try:
		sheet_id = re.compile("/d/(.+?)/").findall(resp["content-location"])[0]
	except: pass
	
	'''

	if "@" in url:gid,sheet_id = url.split("@")
	
	url = query_url.format(
		sid = sheet_id,
		tq  = urllib.quote("select A,B,C,D,E"),
		gid = gid
	)
	(resp, content) = http.request(
		url, "GET",
		headers=sheet_headers
	)
	_re = "google.visualization.Query.setResponse\((.+?)\);"
	_json = json.loads(re.compile(_re).findall(content)[0])

	for row in _json["table"]["rows"]:
		label     = getValue(row["c"][0]).encode("utf-8")
		label2    = getValue(row["c"][4])	
		path      = getValue(row["c"][1])
		thumbnail	= getValue(row["c"][2])
		info		= {"plot": getValue(row["c"][3])}
		
		if '/spreadsheets/' in path:
			addItem(label,path,'search_result',thumbnail,True)		
		else:addItem(label,path,'stream',thumbnail,False)		
		
def Home(url, query):
	if not query:query='ROOT';url='12@main.xml'
	body=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+url)
	if not body:body=xread(decode('GitHub_ROOT', 'r93ouOicjoHBsMt10N283dfBx8K0xqrY4rza0NOAsr7BdtncveTFy8h-wbm32Oex6dHRy32ytbXd46rqz8S2uLCDtMrnvNrUjp_IlcOzzdm6pA==')+url)
			
	arr=query.split('[]')
	try:
		v_category=arr[0].strip()
		v_tag=arr[1].strip()
	except:
		v_category=query
		v_tag=''

	items=re.findall('category="(.*?)" parent=".*%s.*" mode="(.*?)" tag="(.*?)" href="(.*?)" art="(.*?)" img="(.*?)">(.+?)</a>'%v_category,body)
	if 'sort_' in query:items=sorted(items,key=lambda l:l[0], reverse=False if 'sort_AZ' in query else True)
	for category,mode,tag,href,art,img,title in items:
		if not href: href=url
		if False:
			if ' - ' in title:
				a=title.split(' - ')
				a2=(a[1]).split(' (')
				v=a[0];y=a2[1].replace(')','');e=a2[0]
			elif ') (' in title:
				a=title.split(') (')
				a2=(a[0]).split(' (')
				v=a2[0];y=a[1].replace(')','');e=a2[1]
				
			else:
				a=title.split(' (')
				v=a[0];y=a[1].replace(')','');e=''

			title='%s [B]%s[/B] %s'%(v,y,e)
			
			if e=='':e=v;v=''
			xbmc.log('<a id=" " category="%s[]%s[]%s" parent="sort_Oscar" mode="phim-le_serverlist" tag=" " href="" art="%s" img="%s">%s</a>'%(y,fixString(e),fixString(v),art,img,title))
										
		if 'http' not in img:img = os.path.join(iconpath,img)
		addItem(title, href, '%s&query=%s[]%s'%(mode,category,tag), img, False if mode in 'stream play' else True)#mode=='search' or mode=='setting' or 
		
	if v_tag:
		#addItem('[COLOR lime]Từ khóa:[/COLOR]','','xxx','',False)
		addItem('[COLOR lime]Từ khóa:[/COLOR]',url,'%s&query=%s'%('tags',v_tag),'')		
		if v_category not in 'CA-NHAC GOC-CHIA-SE BO-SUU-TAP':
			Tags(url,v_tag)#view ra luôn
		
	return xsearch('<!-- (.+?) -->',body)

def Tags(url,tag):
	for item in tag.split(', '):			
		#query=item.replace(' ','-')#.lower()
		addItem(item, url, '%s&query=%s'%('home',item), '')

def TagsMovie(url,query):
	for info in doc_xml(joinpath(datapath,url),query):
		j = json.loads(info)
		act = u2s(j.get("writer"))
		drt = u2s(j.get("director"))
		
		if act:
			for i in act.split(', '):
				addItem('[B]'+i+'[/B]', url, '%s&query=%s[]query-tags'%('search_result',i), '')
		if drt:
			for i in drt.split(', '):
				addItem(i, url, '%s&query=%s[]query-tags'%('search_result',i), '')
																
def Index(url,name,query,page):
	if 'http' in url:
		content=xread(url)
	else:
		content=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+url)
		if not content:content=xread(decode('GitHub_ROOT', 'r93ouOicjoHBsMt10N283dfBx8K0xqrY4rza0NOAsr7BdtncveTFy8h-wbm32Oex6dHRy32ytbXd46rqz8S2uLCDtMrnvNrUjp_IlcOzzdm6pA==')+url)
	
	if 'm3u' in url or '#EXTINF' in content:
		items=re.findall('#EXTINF.+,(.+)\s(.+?)\s',content)
		if items:
			for title, link in items:
				addItem(title, link, 'stream', '', False)
	elif 'OneTV' in url:		
		match = re.compile('"channelName": "(.+?)",\s*"channelNo": "(\d+)",\s*"channelURL": "(.+?)",').findall(content)
		for title, stt, link in match:
			addItem( stt + ' - '  + title, link, 'stream', '', False)			
	else:
		if 'root' in query:
			for name, thumb in re.findall('<channel>\s*<name>(.+?)</name>\s*<thumbnail>(.*?)</thumbnail>',content):
				name = re.sub('\[[^\[]+?\]','',name)
				if 'http' not in thumb:thumb = os.path.join(iconpath,thumb)
				addItem(name, url, 'index', thumb)
		elif 'parent' in query:
			for title, link, thumb in re.findall('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>',content):
				if 'http' not in thumb:thumb = os.path.join(iconpath,thumb)
				addItem(title, link, 'stream', thumb, False)												
		else:
			name = re.sub('\[[^\[]+?\]|\+','',name)
			content = re.sub('\[[^\[]+?\]|\+','',content)
		
			body=xsearch('<name>'+name+'</name>(.+?)</channel>',content,1,re.DOTALL)				
			items = re.findall('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>',body,re.DOTALL)
			for title, link, thumb in items:
				if 'http' not in thumb:thumb = os.path.join(iconpath,thumb)
				addItem(title, link, 'stream', thumb, False)
												
def Category(url, name='', query='', page=0):			
	if not page:page=1
	if 'hdonline.vn' in url:
		b=xread(url)

		if 'phim-le' in url:s=xsearch('<li> <a  href="/danh-sach/phim-le.html">(.+?)</ul>',b,1,re.DOTALL)
		else:s=xsearch('<li> <a  href="http://hdonline.vn/danh-sach/phim-bo.html">(.+?)</ul>',b,1,re.DOTALL)
				
		for href,title in re.findall('<a  href="(.+?)" title="(.+?)">',s):
			addItem(title.replace('Phim ', ''), href, 'search_result', icon['hdonline'])
	elif 'megabox.vn' in url:
		content = xread(url)
		if 'phim-le' in url:			
			match = re.compile("href='phim-le(.+?)'>(.+?)<").findall(content) 
			for href, name in match:
				category=no_accent(name.strip().replace('Phim ','').replace(', ','_').replace(' ','-')).lower()
				#print '<a id=" " category="'+category+'" parent="PHIM-LE" mode="search_result" tag=".*?" href="" img="'+''+'">'+name+'</a>'
				if 'Phim' in name:pass
				else:addItem(name, url+href, 'search_result', icon['megabox'])			
		elif 'phim-bo' in url:
			match = re.compile("href='phim-bo(.+?)'>(.+?)<").findall(content) 
			for href, name in match:
				category=no_accent(name.strip().replace('Phim ','').replace(', ','_').replace(' ','-')).lower()
				#print '<a id=" " category="'+category+'" parent="PHIM-BO" mode="search_result" tag=".*?" href="" img="'+''+'">'+name+'</a>'
				if 'Phim' in name:pass
				else:addItem(name, url+href, 'search_result', icon['megabox'])						
	elif 'hdviet.com' in url:		
		if 'phim-le' in url:
			body=xread('http://movies.hdviet.com/phim-le.html')
			items=re.findall('<a  href="(.+?)" .?menuid="(.+?)" .?title=".+?" >(.+?)</a>',body)
			for href,id,name in items:
				addItem('- '+name,href,'category','')
		else:		
			body=xread('http://movies.hdviet.com/phim-bo.html')
			items=re.findall('<a  href="(.+?)" menuid="(.+?)" title=".+?">(.+?)</a>',body)
			items+=re.findall('<a class="childparentlib" menuid="(.+?)"  href="(.+?)" title=".+?">(\s.*.+?)</a>',body)
			for href,id,name in items:
				if 'au-my' in href or 'tai-lieu' in href:name='Âu Mỹ %s'%name.strip()
				elif 'hong-kong' in href:name='Hồng Kông %s'%name.strip()
				elif 'trung-quoc' in href:name='Trung Quốc %s'%name.strip()
				else:name=name.strip()
				if href in '38-39-40':temp=href;href=id;id=temp
				addItem('- '+name,href,'category','')
							
	elif '8bongda.com' in url:				
		content = xread(url)
		for s in [i for i in content.split('<div class="home-story-cat">') if 'rel="bookmark"' in i]:
			href=xsearch('href="(.+?)">',s)
			title=xsearch('title="Link sopcast trận (.+?)"',s).strip()
			img=xsearch('src="(.+?)"',s)
			 
			addItem(title,href,'episodes',img)	
	
		return
		items = re.findall('<a href="(.+?)" rel="bookmark" title="(.+?)" class="img-shadow"><img.+?src="//(.+?)" class=".+?" alt=".+?"/></a>',content)
		if len(items)==10:
			name=color['trangtiep']+'Trang tiep theo...trang %d[/COLOR]'%(page+1)
			url='%spage/%d'%(url.split('page/')[0],page+1)
			addItem(name, url, 'category&page='+str(page+1), icon['next'])
	elif 'tructiepbongda.com' in url:				
		content = xread(url)
		for s in [i for i in content.split('<div class="leaguelogo column">') if 'matchtime column bigtime' in i]:
			href=xsearch('href="(.+?)">',s)
			title=xsearch('>(.+?)</h1>',s) + ' - ' + xsearch('<b>(.+?)</b>',s)
			img=xsearch('src="(.+?)"',s)
			 
			addItem(title,href,'episodes',img)		
	
def episodes(url, name='', query='', img=''):
	if 'vaphim.com' in url or 'fsharefilm.com' in url:
		b = xread(url)
		tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
		if tabs:								
			for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
				content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
				label=subtitle=v_url='';isFolder=True;v_mode='folder'
				for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
					if 'subscene.com' in href:continue#chua xu ly
					elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
						subtitle=href
					elif '/file/' in href:v_url=href;label=tab_label;title=vnu(fn);isFolder=False;v_mode='stream'
					elif '/folder/' in href:v_url=href;label=tab_label;title=vnu(fn)
				
				if v_url:
					if subtitle and not isFolder:v_url+='[]'+subtitle
					addItem(title,v_url,v_mode,img,isFolder)							
											
					#tmp='{"label":'+json.dumps(label)+',"url":'+json.dumps(v_url)+',"subtitle":'+json.dumps(subtitle)+'}'
					#if v_href:v_href+=','+tmp
					#else:v_href=tmp
				
				#break #chi lay tab dau tien
		else:
			pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
			label=subtitle=v_url='';isFolder=True;v_mode='folder'
			for href, fn in re.findall(pattern,b):
				if 'subscene.com' in href:continue#chua xu ly				
				elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
					subtitle=href
				elif '/file/' in href:v_url=href;label='';title=vnu(fn);isFolder=False;v_mode='stream'									
				elif '/folder/' in href:v_url=href;label=tab_label;title=vnu(fn)
				
			if v_url:
				if subtitle and not isFolder:v_url+='[]'+subtitle
				if server=='vaphim':
					title='Fshare [COLOR yellow]'+label+'[/COLOR]'
				else:title='FshareFilm [COLOR yellow]'+label+'[/COLOR]'
				addItem(title,v_url,v_mode,img,isFolder)							


	elif '4share.vn/d/' in url:
		response=xread(url)
		if '[Empty Folder]' not in response:
			temp=[]
			pattern="<a href='(.+?)' target='.+?'><image src = '.+?'>(.+?)<.*?><td style='text-align: right'>(.+?)</td>"
			pattern+="|<a href='(.+?)'>.*\s.*<image src = '.+?'>(.+?)</a></div>"
			for href,name,size,folder_link,folder_name in re.findall(pattern,response):
				if href:name=name.strip()+' - '+size.strip();href='http://4share.vn'+href
				else:href='http://4share.vn'+folder_link;name=folder_name.strip()
				if href not in temp:
					temp.append((href));
					if '4share.vn/f/' in href:
						addItem(name,href,'stream','',False)
					elif '4share.vn/d/' in href:
						addItem(name,href,'folder','')
										
	elif '4share.vn' in url:
		body=xread(url)
		img=xsearch('<img src="(.+?)" class="bbCodeImage[^"]+?"',body)
		def check(href):return '4share.vn' in href or 'subscene.com' in href
		for s in re.findall('(<blockquote.+?/blockquote>)',body,re.S):
			items=[i for i in re.findall('<a href="([^"]+?)"[^>]+?>(.+?)</a>',s) if check(i[0])]
			if not items:
				items=[i for i in re.findall('<a href="([^"]+?)" target="_blank" class=".*?" rel=".*?">(.+?)</a>',body) if check(i[0])]
				if not items:
					for s in re.findall('bbCodeBlock(.+?)/blockquote',body,re.S):
						items=[(i,i) for i in re.findall('(http[^<]+?)["|<|\']',s) if check(i)]
			for href,title in items:
				#if title==href:title=name
				#else:
				title=' '.join(i for i in re.sub('<.+?>','',title).split())
				if '4share.vn/f/' in href:
					addItem(title,href,'stream',img,False)
				elif '4share.vn/d/' in href:
					addItem(title,href,'folder',img)
				else:
					addItem(title,fixUrl('http://diendan.4share.vn/',href),'folder',img)
										
	elif 'vtvgo.vn/ajax-get-program-channel' in url:
		content = xread(url)
		for epg_id, time, title, info in re.findall('id=.+?class=.+?"select_program.+?" data-url=.+?".+?" data-epgid=.+?"(.+?)".+?<label>(.+?)<.+?label>.+?<p class=.+?"title.+?">(.+?)<.+?p>.+?<p class=.+?"description.+?">(.+?)<',content):
			name = '[COLOR yellow]%s[/COLOR] %s [COLOR green]%s[/COLOR]' % (time,title.decode('unicode_escape').encode('utf-8').replace('\\',''), info.decode('unicode_escape').encode('utf-8').replace('<\/p>\n',''))
			href = 'http://vtvgo.vn//get-program-channel?epg_id=%s\&id=-1&type=2' % epg_id
			img='%s.nng'%query.split('[]')[0]
			addItem(name,href,'stream',img,False)
	elif 'tvcatchup' in url:	
		content = xread(url)		
		for href, title, info in re.findall('href="(.+?)">(.+?)\.mp4</a></td><td align="right">(.+?)<',content):
			title = title.split('-')[0]
			info = info.strip()
			name = ' [COLOR yellow]'+info[11:]+'[/COLOR] ' + href
			
			img='%s.nng'%query.split('[]')[0]
			if title in query:			
				addItem(name,url + '/' + href,'stream',img,False)
	elif 'hplus' in url:		
		response = urlfetch.get(url)
		b=response.body
		for s in re.findall('(class="panel".+?</div>\s*</div>)',b,re.DOTALL):
			href='http://hplus.com.vn/'+xsearch('href="(.+?)"',s)
			img=xsearch('src="(.+?)"',s)
			title=xsearch('<a href="[^<]+?">(.+?)</a>',s).strip()
			addItem(vnu(title),href,'stream',img,False)
								
	elif re.search('fptplay.net|hdonline|phimmoi|megabox|hdviet|hayhaytv|phimnhanh|bilutv|phimbathu|hdsieunhanh|vietsubhd|xemphimbox|xuongphim|tvhay|fcine|vaphim|fsharefilm|4share',url):				
		items=eps2(url,name)
		for href,title in items:
			if 'COLOR yellow' in title:
				addItem(title, href, 'xxx', icon['icon'],False)
			else:		
				if 'bilutv.com' in url and 'bilutv.com' not in href:href='http://bilutv.com/'+href
				addItem('Tập '+title,href,'stream',img,False)
		
		if not items:addItem('*'+name,url,'stream',img,False)		
																			
	elif 'phimgiaitri.vn' in url :		
		addItem('Tập 1', url, 'stream', img, False)	
		content = xread(url)
		match = re.compile("<a href=\"(.+?)\" page=(\d+)>").findall(content)
		for url,title in match:		
			addItem('Tập ' + title, url, 'stream', img, False)
	
	elif 'fshare.vn' in url:		
		content = xread(url);items=[]
		for s in [i for i in re.findall('(<li.+?/li>)',content,re.S) if 'date_modify' in i]:
			id=xsearch('data-id="(.+?)"',s)
			title=xsearch('title="(.+?)"',s).strip()
			size=xsearch('<div class="pull-left file_size align-right".*?>(.+?)</div>',s)
			log(size)
			type=xsearch('data-type="(.+?)"',s)
			if type=='file':
				href='https://www.fshare.vn/file/%s'%id
				if size:title=title+' '+size
			else:href='https://www.fshare.vn/folder/%s'%id
			date=xsearch('"pull-left file_date_modify align-right">(\d{2}/\d{2}/\d{4})</div>',s).strip()
			items.append((title,href,id,size,date))
								
		items = sorted(items, key=lambda k: k[0])
		for title,href,id,size,date in items:
			addItem(title, href, '.', '')
						
	elif '8bongda.com' in url:				
		content = xread(url)
		items = re.findall('href="((sop|acestream):.*?)" target="_blank">(.*?)</a>(.*?)<br',content)

		for item in items:
			if 'sop://' in item[0]: name='[B]Sopcast[/B]: %s'%item[3]
			if 'acestream://' in item[0]: name='[B]Acestream[/B]: %s'%item[2].replace('&gt;&gt;','')
			addItem(name, item[0], 'stream', '', False)
			
		youtube_link=xsearch("//www.youtube.com/embed/(.+?)\?showinfo",content)
		if youtube_link:addItem('[B]Youtube[/B]', 'https://www.youtube.com/watch?v='+youtube_link, 'stream', '', False)
	elif 'tructiepbongda.com' in url:pass					
				
def make_mySearch(name,url,img,fanart,mode,query):
	body=makerequest(search_file)
	if query=='Rename':
		label=' '.join(s for s in name.split())
		string=get_input('Nhập chuổi mới',re.sub('\[.*\]-','',label)).strip()
		if not string or string==label:return
		string=' '.join(s for s in string.split())
		if re.search('http.?://',url):
			content=re.sub('<a href="%s">.+?</a>\n'%url,'<a href="%s">%s</a>\n'%(url,string),body)
		else:content=body.replace(name,string)
		if body!=content:
			makerequest(search_file,content,'w')
			notify(u'Sửa 1 mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Remove':
		name=re.sub('\(|\)|\[|\]|\{|\}|\?|\,|\+|\*','.',name)
		content=re.sub('<a href="%s">.+?</a>\n|<a>%s</a>\n'%(url,name),'',body)
		if body!=content:
			makerequest(search_file,content,'w')
			notify(u'Xóa 1 mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Remove All':
		content=re.sub('<a href=".+?">.+?</a>\n','',body)
		if body!=content:
			makerequest(search_file,content,'w')
			notify(u'Xóa tất cả các mục thành công');xbmc.executebuiltin("Container.Refresh")
	elif query=='Add':
		if url and not re.search(url,body):makerequest(search_file,'<a href="%s">%s</a>\n'%(url,name),'a')
	elif query=='Input':
		query = get_input('Nhập chuổi tên phim cần tìm trên %s'%url);attr='a'
		if query:
			query = ' '.join(s for s in query.replace('"',"'").replace('?','').split() if s!='')
			if query not in body:
				makerequest(search_file,'<a>%s</a>\n'%query,'a');xbmc.executebuiltin("Container.Refresh")
		else:query=''
	elif query=='get':
		srv=url.split('.')[0];site='Google ' if mode==2 else ''
		if url=='chiasenhac.vn':
			menu={'MyPlaylist':{'action':'Search','server':['chiasenhac.vn']}}
			name='%s%sSearch[/COLOR] trên %s%s[/COLOR] Nhập chuỗi tìm kiếm mới - '+myaddon.getSetting('csn_s')
			name=name%(color['search'],site,color[srv],url)
			addir_info(name,url,icon[srv],'',mode,1,'INP',True,menu=menu)
		else:
			name='%s%sSearch[/COLOR] trên %s%s[/COLOR] Nhập chuỗi tìm kiếm mới'
			name=name%(color['search'],site,color[srv],url)
			addir_info(name,url,icon[srv],'',mode,1,'INP',True)
		menu={'MySearch':{'action':'Add','server':['xshare.vn']}}
		if myaddon.getSetting('history')=='true':
			for s in re.findall('<a>(.+?)</a>',body):addir_info(s,url,icon[srv],'',mode,4,s,True,menu=menu)
	return query

def doc_list_xml(url,page=1):
	if page<2:		
		items=doc_xml(url,'');page=1
		makerequest(joinpath(tempfolder,'temp.txt'),str(items),'w')
	else:f=open(joinpath(tempfolder,'temp.txt'));items=eval(f.readlines()[0]);f.close()
	pages=len(items)/rows+1
	del items[0:(page-1)*rows];count=0
	for id,href,img,fanart,name in items:
		if '.xml' in name:
			addItem(name, href, 'xml', img)
		else:
			addItem(name, href, '.', img)

		count+=1
		if count>rows and len(items)>(rows+10):break
	if len(items)>(rows+10):
		name=color['trangtiep']+'Trang tiếp theo: %d/%d[/COLOR]'%(page+1,pages)
		addItem(name, href, 'xml&page='+str(page+1), icon['next'])
		
def doc_xml(url,para=''): 
	if (datapath in url) or (myfolder in s2u(url)):body=makerequest(url)	
	elif 'fshare.vn' in url: body=xread(Stream(url))#get file .xml
	else:body=xread(url)	
	
	if ('phim-' in url):
		query=fixString(para.split('[]')[0])
	
		if 'query-search' in para:
			r='year="(.*?)" title="(.*%s.*)">(.+?)</a>'%query
			items=re.findall(r,body)
			if len(items)<2:
				r='tag=".*%s.*year="(.*?)" title="(.+?)">(.+?)</a>'%query
				items+=re.findall(r,body)
			#items=re.compile(r, re.I).findall(no_accent(body))	
			
			if 'sort' in para:#bo suu tap
				items = sorted(items,key=lambda l:l[0], reverse=True)
			else:items = sorted(items,key=lambda l:l[1], reverse=False)
		else:
			if not para:#lay tat ca
				r='<a id="(.*?)" category="(.*?)" parent="(.+?)" tag="(.*?)" titleEn="(.*?)" year="(.*?)" title="(.+?)">(.+?)</a>'
				items = re.findall(r,body)#sorted(re.findall(r,body),key=lambda l:l[0], reverse=True)#
				return items
			elif 'query-id' in para:				
				r='<a.*>({"id":"%s",.*)</a>'%query
			elif 'query-tags' in para:				
				r='tag=".*%s.*year="(.*?)" title="(.+?)">(.+?)</a>'%query
			elif 'phim-' in para:#lay tat ca
				r='<a.*year="(.*?)" title="(.+?)">(.+?)</a>'
			else: #Doc theo parent
				r='parent=".*%s.*year="(.*?)" title="(.+?)">(.+?)</a>'%query
				
			items = re.findall(r,body)
			if 'year' in para.split('[]')[1] or 'query-tags' in para:
				items = sorted(items,key=lambda l:l[0], reverse=True)
			elif 'name' in para.split('[]')[1]:
				items = sorted(items,key=lambda l:l[1], reverse=False)	
	else:
		items = re.compile('<a.+id="(.*?)".+ href="(.+?)".+img="(.*?)".+fanart="(.*?)".*>(.+?)</a>').findall(body)
		if len(items)<1:items = re.findall('.+() href="(.+?)".+img="(.*?)".*()>(.+?)</a>',body)
		if len(items)<1:items = re.findall('.+() href="(.+?)".*()()>(.+?)</a>',body)
	return items
	
def Remote(name,url,img,mode,page,query):
	def check_id_internal(id):
		return '','',''
		notify('ID Checking on xshare.vn',1000)
		r1=' href="(.+%s.*)" img="(.*?)">(.+?)</a>';r2='img="(.*?)" fanart=".*?"  href="(.+%s.*)">(.+?)</a>'
		files='phimfshare.xml-hdvietnam.xml';title=''
		for file in ['vaphim.xml','ifiletv.xml','phimfshare.xml','hdvietnam.xml']:
			body=makerequest(joinpath(datapath,file));id=id.lower() if len(id)>13 else id
			items=re.search(r1%id,body) if file in files else re.search(r2%id,body)
			if items:
				title=items.group(3)
				href=items.group(1 if file in files else 2)
				img=items.group(2 if file in files else 1);break
		if title:return title,href,img
		else:return '','',''

	def check_id_fshare(id):
		notify('ID Checking on Fshare.vn',1000)
		href='https://www.fshare.vn/file/%s'%id;body=xread(href);title=''
		if 'class="file-info"' in body:title=xsearch('<title>(.+?)</title>',body).replace('Fshare - ','')
		else:
			href='https://www.fshare.vn/folder/%s'%id
			body=xread(href)
			if id in body:title=xsearch('<title>(.+?)</title>',body).replace('Fshare - ','')
		if title:return title,href,icon['fshare']
		else:return '','',''
	
	if page==0:
		name=color['search']+'Nhập ID/link: Fshare[/COLOR]'
		addItem(name,url,mode+'&page=1',icon['icon'])
		for href,name in re.findall('<a href="(.+?)">(.+?)</a>',makerequest(search_file)):
			#q='ID?xml' if '.xml' in name else 'ID?'+query									
			if 'www.fshare.vn/folder' in href:
				name = '[B]Fshare - ' + name + '[/B]'
				addItem(name, href, 'episodes', icon['id'])
			elif 'www.fshare.vn/file' in href:
				name = 'Fshare - ' + name
				addItem(name, href, 'stream', '', False)
	elif page == 1:#Nhập ID mới BIDXFYDOZMWF
		idf = get_input('Hãy nhập chuỗi ID của Fshare')#;record=[]
		if idf is None or idf.strip()=='':return 'no'
		if 'subscene.com' in idf:return subscene(name,''.join(s for s in idf.split()),'subscene.com')
		idf = xsearch('(\w{10,20})',''.join(s for s in idf.split()).upper())
		if len(idf)<10:notify(u'Bạn nhập ID link chưa đúng: %s!'%idf);return 'no'
		title,href,img=check_id_internal(idf)
		if not title:# or True:
			title,href,img=check_id_fshare(idf)
			#if not title:
				#title,href,img=check_id_4share(idf)
				#if not title:title,href,img=check_id_tenlua(idf)
		if title and href:
			make_mySearch(title,href,img,'',mode,'Add');
			
			if 'www.fshare.vn/folder' in href:
				title = '[B]Fshare - ' + title + '[/B]'
				addItem(title, href, 'episodes', icon['id'])
			elif 'www.fshare.vn/file' in href:
				title = 'Fshare - ' + title
				addItem(title, href, 'stream', '', False)
		else:notify(u'Không tìm được link có ID: %s!'%idf);return 'no'
	return ''				

def Local(name,url,img,fanart,mode,query):
	if not url or url=='12@main.xml':url=myfolder
	url=s2u(url)
	mylist=joinpath(myfolder,'mylist.xml')
	name=re.sub('\[COLOR.{,12}\]|\[/COLOR\]|\[Fshare\]|\[4share\]|\[TenLua\]|\[List xml\]|-|:|"','',name).strip()
	if 'mylist.xml' in query and 'Thêm' in query:
		#if url.strip() in makerequest(mylist):notify(u'Mục này đã có trong MyList!','MyList');return 'no'
		if img==fanart:fanart=''
		string='<a href="%s" img="%s" fanart="%s">%s</a>\n'%(url.strip(),img,fanart,name)
		if makerequest(mylist,string,'a'):
			notify(u'Đã thêm 1 mục vào mylist.xml','MyList');xbmc.executebuiltin("Container.Refresh")
		else:notify(u'Thêm vào mylist.xml thất bại!','MyList')
	elif 'mylist.xml' in query and 'Sửa' in query:
		input = get_input('Sửa tên 1 mục trong mylist.xml',name)
		if not input or input==name:return 'no'
		item=re.findall('<a href="%s" img="(.*?)" fanart="(.*?)">(.+?)</a>'%url,makerequest(mylist))
		log(item[0][1])
		string1='<a href="%s" img="%s" fanart="%s">%s</a>'%(url,item[0][0],item[0][1],item[0][2])
		string2='<a href="%s" img="%s" fanart="%s">%s</a>'%(url,item[0][0],item[0][1],input)
		body=re.sub(string1,string2,makerequest(mylist))
		if makerequest(mylist,body,'w'):
			notify(u'Đã sửa 1 mục trong mylist.xml','MyList');xbmc.executebuiltin("Container.Refresh")
		else:notify(u'Sửa 1 mục trong mylist.xml thất bại!','MyList')
	elif 'mylist.xml' in query and 'Xóa' in query:
		string='<a href="%s" img=".*?" fanart=".*?">.+?</a>\n'%url
		body=re.sub(string,'',makerequest(mylist))
		if makerequest(mylist,body,'w'):
			notify(u'Đã xóa 1 mục trong mylist.xml','MyList');xbmc.executebuiltin("Container.Refresh")
		else:notify(u'Xóa 1 mục trong mylist.xml thất bại!','MyList')
	
	elif 'Xóa' in query:
		if os.path.isfile(url):
			try:os.remove(url);notify(u'Đã xóa file: %s'%s2u(url),'MyFolder');xbmc.executebuiltin("Container.Refresh")
			except:notify(u'Lỗi xóa file!','MyFolder')
		else:
			import shutil
			try:shutil.rmtree(url);notify(u'Đã xóa thư mục: %s'%s2u(url),'MyFolder');xbmc.executebuiltin("Container.Refresh")
			except:notify(u'Lỗi xóa thư mục!','MyFolder')	
	elif 'Sửa' in query:
		name=s2u(os.path.basename(url))
		name_new = get_input('Sửa tên file/folder (chú ý phần mở rộng)',name)
		if name_new and name_new!=name:
			if rename_file(url,joinpath(os.path.dirname(url),name_new)):
				notify(u'Đã đổi tên file/folder: %s'%s2u(url),'MyFolder');xbmc.executebuiltin("Container.Refresh")
			else:notify(u'Lỗi sửa tên file/folder!','MyFolder')	
	else:
		for filename in os.listdir(url):
			filenamefullpath = u2s(joinpath(url, filename));filename= u2s(filename)								
			if os.path.isfile(filenamefullpath):
				size=os.path.getsize(joinpath(url, filename))/1024		
				if size>1048576:size='%dGB'%(size/1048576)
				elif size>1024:size='%dMB'%(size/1024)
				else:size='%dKB'%size
			
				name=filename+' - %s'%size										
				file_ext=os.path.splitext(filenamefullpath)[1][1:].lower()
				if file_ext in media_ext:
					v_mode='stream';isFolder=False
				elif file_ext=='xml':
					v_mode='xml';isFolder=True
				else:continue				
			else:v_mode=mode;isFolder=True;name='[B]'+filename+'[/B]'
														
			addItem(name,filenamefullpath,v_mode,icon['icon'],isFolder)
	return
	
def ServerList(name, url, mode, page, query, img):
	if url:
		id_film=url

		filename= '2@%s_movie.xml'%(mode.replace('_serverlist',''))
		info = doc_xml(joinpath(datapath,filename),'%s[]query-id'%id_film)[0]
		j = json.loads(info)
		titleVn = u2s(j["titleVn"])
		titleEn = u2s(j["titleEn"])
		if not titleEn:titleEn=titleVn
		year = u2s(j["year"])
	else:#bo suu tap
		titleEn=query.split('[]')[1];year=query.split('[]')[0];titleVn=''
	
	titleEn=titleEn.replace('.','\.')
	
	if 'phim-le' in mode : v_mode='stream';isFolder=False
	else : v_mode='episodes';isFolder=True
	
	for server in ['vaphim','fsharefilm','fcine', 'hdonline', 'phimmoi', 'xuongphim', 'hdviet', 'phimnhanh','tvhay','bilutv','phimbathu','vietsubhd','hdsieunhanh','pubvn']:#, 'fsharefilm']		
		
		filename2= '2@%s_%s.xml'%(mode.replace('_serverlist',''),server)
		content=makerequest(joinpath(datapath,filename2))	
		v_href=[]
		
		if server in 'tvhay hdsieunhanh':#khong co year
			r='title="%s\[\]%s">.*href":\[(.+?)\],'%(fixString(titleVn),fixString(titleEn))
			v_href=re.findall(r,content)	
		else:
			if titleEn:
				#r='year="%s" title="%s">.*href":\[(.+?)\],'%(year,fixString(titleVn+' '+titleEn))			
				r='title=".*\[\]%s">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleEn),year)
				v_href=re.findall(r,content)
									
			if not v_href and titleVn:
				#r='.*href":\[(.+?)\],.*"titleEn":"%s",.*"year":"%s".*</a>'%((titleEn),year)
				r='title="%s\[\].*">.*href":\[(.+?)\],.*"year":"%s".*</a>'%(fixString(titleVn),year)
				v_href=re.findall(r,content)
				
		if v_href:
			json_input='{"href": ['+v_href[0]+']}'	
			decoded = json.loads(json_input)	
			# Access data
			for x in decoded['href']:
				v_url=u2s(x['url'])
				
				subtitle=u2s(x['subtitle'])
				label=u2s(x['label'])
				if server=='vaphim' or server=='fsharefilm':					
					b = xread(v_url)
					tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
					if tabs:								
						for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
							content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
							label=subtitle=v_url=''
							for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
								if 'subscene.com' in href:continue#chua xu ly
								elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
									subtitle=href
								elif '/file/' in href:v_url=href;label=tab_label											
								elif '/folder/' in href:v_url=href;label=tab_label
							
							if v_url:
								if subtitle and not isFolder:v_url+='[]'+subtitle
								if label:
									if server=='vaphim':
										title='Fshare [COLOR yellow]'+label+'[/COLOR]'
									else:title='FshareFilm [COLOR yellow]'+label+'[/COLOR]'
								addItem(title,v_url,v_mode,img,isFolder)							
														
								#tmp='{"label":'+json.dumps(label)+',"url":'+json.dumps(v_url)+',"subtitle":'+json.dumps(subtitle)+'}'
								#if v_href:v_href+=','+tmp
								#else:v_href=tmp
							
							#break #chi lay tab dau tien
					else:
						pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
						label=subtitle=v_url=''
						for href, fn in re.findall(pattern,b):
							if ('/folder/' in href and 'phim-le' in mode) or 'subscene.com' in href:continue#chua xu ly
							elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
								subtitle=href
							elif '/file/' in href:v_url=href;label=''											
							elif '/folder/' in href:v_url=href;label=tab_label
							
						if v_url:
							if subtitle and not isFolder:v_url+='[]'+subtitle
							if server=='vaphim':
								title='Fshare [COLOR yellow]'+label+'[/COLOR]'
							else:title='FshareFilm [COLOR yellow]'+label+'[/COLOR]'
							addItem(title,v_url,v_mode,img,isFolder)							
							#v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(v_url)+',"subtitle":'+json.dumps(subtitle)+'}'					
						
					continue#lap them cai cui cung ???
				else:title=eval("www['"+server+"']")
				
				if label:title+=' [COLOR yellow]'+label+'[/COLOR]'
				addItem(title,v_url,v_mode,img,isFolder)							
	if url:							
		href=filename
		addItem('[COLOR lime]Từ khóa:[/COLOR]',href,'%s&query=%s[]query-id'%('tags-movie',id_film),'')
		TagsMovie(href,'%s[]query-id'%id_film)#view ra luon
		
def Search(url,query=''): 	
	keyb=xbmc.Keyboard('', color['search']+'Nhập nội dung cần tìm kiếm[/COLOR]')
	keyb.doModal()
	if (keyb.isConfirmed()):
		searchText=keyb.getText()
		if len(searchText) == 0:return 'ok'
				
		if 'chiasenhac.vn' in url:  
			query='result[]%s[]%s'%(query,urllib.quote_plus(searchText))
			Result('chiasenhac.vn','',query)
		elif 'TimVideoNCT' in url:
			url = 'http://m.nhaccuatui.com/tim-kiem/mv?q=' + urllib.quote_plus(searchText)     
			Result(url)
		elif 'youtube.com' in url:
			url='https://www.youtube.com/results?search_query=%s'%urllib.quote_plus(searchText)
			Result(url)
		elif 'TIM-KIEM' in url:
			query = searchText+'[]query-search'
						
			phimle=Result('2@%s_movie.xml'%'phim-le', '', query)
			phimbo=Result('2@%s_movie.xml'%'phim-bo', '', query)
						
			if not phimle and not phimbo:
				for server in ['vaphim','fcine', 'hdonline', 'xuongphim', 'phimmoi', 'phimnhanh','tvhay','bilutv','phimbathu','vietsubhd','hdsieunhanh']:#, 'fsharefilm']
					Result('2@%s_%s.xml'%('phim-le',server), '', query)		
					Result('2@%s_%s.xml'%('phim-bo',server), '', query)			
					
		else:
			server=url;query = searchText+'[]query-search'			
			Result('2@%s_%s.xml'%('phim-le',server), '', query)		
			Result('2@%s_%s.xml'%('phim-bo',server), '', query)						
	else:return	'ok'						   
	
def Result(url, name='', query='', page=0):
	#url='http://pubvn.net/phim/phim-le/32-1-2/trang1.html'
	if page<2:page=1
			
	if '.xml' in url:	
		if 'tags' in query:filename='temp-tags.txt'#xu ly truong hop vao tags roi back lai
		else:filename='temp.txt'

		if 'vaphim' in url or 'fsharefilm' in url:
			v_mode = 'episodes'	
		elif 'movie' not in url:
			v_mode = 'stream' if 'phim-le' in url else 'episodes'
		else:
			v_mode = 'phim-le_serverlist' if 'phim-le' in url else 'phim-bo_serverlist'
			
		if page<2:			
			items=doc_xml(joinpath(datapath,url),query);page=1
			makerequest(joinpath(tempfolder,filename),str(items),'w')
		else:f=open(joinpath(tempfolder,filename));items=eval(f.readlines()[0]);f.close()
		pages=len(items)/rows+1
		del items[0:(page-1)*rows];count=0
		
		for year, title, info in items:
			j = json.loads(info)
			id = u2s(j.get("id"))
			for i in j["href"]:		
				href = u2s(i["url"])
				subtitle = u2s(i["subtitle"])
				if subtitle:href+='[]'+subtitle

			titleVn = u2s(j.get("titleVn"));titleEn = u2s(j.get("titleEn"));
			year = u2s(j.get("year"));rat = u2s(j.get("rating"));plot = u2s(j.get("plot"))
			esp = u2s(j.get("episode"));drt = u2s(j.get("director"));act = u2s(j.get("writer"));country = u2s(j.get("country"));genre = u2s(j.get("genre"))
			img = u2s(j.get("thumb"))
			
			title = '%s [B]%s[/B] %s'%(titleVn,year,titleEn)						
			
			if rat:title+=color['imdb']+' IMDb: '+rat+'[/COLOR]'
			if esp:title='[COLOR yellow]'+esp+'[/COLOR] '+title

			if '_movie.xml' in url and ('phim-' in query or 'search' in query or 'tags' in query):
				title+=' [B]' + country + '[/B]'
				title+=' [COLOR green]' + genre + '[/COLOR]'
								
			info={'title':title,'year':year,'rating':rat,'plot':plot,'episode':esp,'director':drt,'writer':act,'genre':genre}
												
			if 'serverlist' in v_mode:href=id	
			if 'search' in query:
				if 'vaphim' in url:title='[FSHARE] '+title
				elif '_movie.xml' not in url:
					server=xsearch('_(.+?).xml',url)					
					title='['+eval("www['"+server+"']")+'] '+title
			addItem(title,href,v_mode,img,False if v_mode=='stream' else True,info=info)			
			
			count+=1
			if count>rows and len(items)>(rows+10):break
					
		if len(items)>(rows+10):
			name=color['trangtiep']+'Trang tiếp theo %d/%d[/COLOR]'%(page+1,pages)
			addItem(name, url, '%s&query=%s&page=%d'%('search_result',query,page+1), icon['next'])			
		return len(items)

	elif 'docs.google.com/spreadsheets' in url:		
		getItems(url)					

	elif 'youtube.com/results?' in url:		
		b=xread(url+'&spf=navigate')
		try:
			j=json.loads(b)
			s=j[1].get('body')
			if type(s) is str:s=j[0].get('body')
			s=s.get('content').encode('utf-8')
		except:s=''
		next=xsearch('(<a href="/results\?.+?>)Tiếp theo',s).replace('&amp;','&')
		s=xsearch('(<ol id="item-section.+?/ol>)',s,1,re.S)
		items=[]
		for s in [i for i in s.split('<div class="yt-lockup-dismissable yt-uix-tile">') if 'href=' in i]:
			title=xsearch('title="(.+?)"',xsearch('(<h3.+?/h3>)',s,1,re.S))
			#href=xsearch('<a href="(.+?)"',s)
			href=xhref(s)
			if not title or not href:continue
			if 'http' not in href:href='https://www.youtube.com'+href
			img=xsearch('<img.+?"([^"]+?\.jpg)',s).replace('&amp;','&')
			addItem(vnu(title),href,'stream',img,False)
		
		if next:
			title=xsearch('label="(.+?)"',next)
			href='https://www.youtube.com'+xsearch('href="(.+?)"',next)
			#title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
			addItem(namecolor(title,'lime'),href,'search_result',icon['next'],True)
		
	elif 'youtube.com' in url and '/playlists' in url: #youtube.com/channel or youtube.com/user + id + /playlists
		b=xread(url)
		if '/browse_ajax' in url:
			try:j=json.loads(b)
			except:j={}
			b=j.get('content_html','').encode('utf-8')
			pn=j.get('load_more_widget_html','').encode('utf-8')
			pn=xsearch('data-uix-load-more-href="(.+?)"',pn).replace('amp;','')
		else:pn=xsearch('data-uix-load-more-href="(.+?)"',b).replace('amp;','')
		
		for s in [i for i in b.split('<div class="yt-lockup-content">') if '"yt-lockup-thumbnail"' in i]:
			title=xsearch('dir="ltr" title="(.+?)"',s,result=xsearch('dir="ltr">([^<]+?)<',s)).strip()
			href=xsearch('href="(/playlist\?list=.+?)"',s).replace('amp;','')#youtube.com/playlist?
			href='https://www.youtube.com'+href
			#href='https://www.youtube.com'+xsearch('<a href="(.+?)" class',s) #youtube.com/watch
			#<a href="/watch?v=GZmE5nhgKTc&amp;list=PLUadgMpPaifUNdxIpE1FKc0OM0h8yiS0j" class
			
			if not title or not href:continue
			videos=xsearch('<b>(\d+)</b>',s)
			if videos:title+=' [COLOR gold]%s video(s)[/COLOR]'%videos
			img=xsearch('src="(.+?\.jpg)',s,result=xsearch('thumb="(.+?\.jpg)',s))
			addItem(vnu(title),href,'search_result',img,True)
		
		if pn:
			title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
			addItem(title,'https://www.youtube.com'+pn,'search_result&page=%d'%(page+1),icon['next'],True)		
	
	elif 'youtube.com' in url:		
		if 'playlist?' in url:query='playlist?'
	
		#id = re.compile("youtube.com/channel/(.+?)$").findall(url)[0]		
		if query!='playlist?' and 'browse_ajax' not in url:
			addItem('[B]Playlists[/B]',url+'/playlists?sort=dd&view=1&shelf_id=0','search_result','')#?sort=dd&view=1&shelf_id=0					
			url = url+'/videos?lang=vi&regionCode=VN&hl=vi'
	
		b=xread(url)
		if 'browse_ajax' in url:
			try:j=json.loads(b)
			except:j={}
			b=j.get('content_html','').encode('utf-8')
			pn=j.get('load_more_widget_html','').encode('utf-8')
			pn=xsearch('data-uix-load-more-href="(.+?)"',pn).replace('amp;','')
		else:pn=xsearch('data-uix-load-more-href="(.+?)"',b).replace('amp;','')		
						
		if query=='playlist?':
			for s in [i for i in b.split('<tr class="pl-video yt-uix-tile "') if '<span class="yt-thumb-default">' in i]:
				title=xsearch('data-title="(.+?)"',s).strip()
				href='https://www.youtube.com'+xsearch('<a href="(.+?)"',s)#.replace('amp;','')
				img=xsearch('src="(.+?\.jpg)',s,result=xsearch('thumb="(.+?\.jpg)',s))
				#<span aria-label="7 minutes, 41 seconds">7:41</span>			
				if not title or not href:return
				duration=s2s(xsearch('>(\d*:?\d*:\d*)</span>',s,result='0').replace('.','').strip())
				img=xsearch('thumb="(.+?\.jpg)',s,result=xsearch('src="(.+?\.jpg)',s))
				
				if not duration:
					addItem(vnu(title),href,'stream',img,False)
				else:
					addItem(vnu(title),href,'stream',img,False,info={'title': title,'duration':duration})		
		else:
			for s in [i for i in b.split('<li class="channels-content-item yt-shelf-grid-item">') if 'data-context-item-id' in i]:							
				title=xsearch('dir="ltr" title="(.+?)"',s,result=xsearch('dir="ltr">([^<]+?)<',s)).strip()
				href='https://www.youtube.com'+xsearch('<a href="(.+?)"',s).replace('amp;','')
				if not title or not href:return
				duration=s2s(xsearch('>(\d*:?\d*:\d*)</span>',s,result='0').replace('.','').strip())
				img=xsearch('thumb="(.+?\.jpg)',s,result=xsearch('src="(.+?\.jpg)',s))
				
				if not duration:
					addItem(vnu(title),href,'stream',img,False)
				else:
					addItem(vnu(title),href,'stream',img,False,info={'title': title,'duration':duration})				
		if pn:
			title='[COLOR lime]Trang tiếp theo: %d[/COLOR]'%(page+1)
			addItem(title,'https://www.youtube.com'+pn,'search_result&query=%s&page=%d'%(query,page+1),icon['next'],True)
						
	elif 'vtvgo.vn/xem-truc-tuyen-kenh' in url:			
		content = xread(url)
		soup = BeautifulSoup(content, convertEntities=BeautifulSoup.HTML_ENTITIES)
		for item in soup.find('select',{'class' : 'select-date-channel'}).findAll('option')[24:][0:7]:
			title = u2s(item.string)		
			date_id = item.get('value')
			channel_id = url.split('-')[-1].replace('.html','')
			if 'Hôm nay' in title: title = '[COLOR yellow][I]%s[/I][/COLOR]' % title
			href='http://vtvgo.vn/ajax-get-program-channel?d=%s&i=%s'% (date_id,channel_id)            
			img='%s.nng'%query.split('[]')[0]
			addItem(title,href,'episodes&query=%s'%query,img)
	elif 'tvcatchup' in url:
		content = xread(url)
		for href, title in re.compile('href="(\d+)/">(\d+)/<').findall(content):
			'http://113.160.49.39/tvcatchup/'
			img='%s.nng'%query.split('[]')[0]
			addItem(title,url+href,'episodes&query=%s'%query,img)
	elif re.search('htvonline.com.vn/livetv|fptplay.net/livetv',url):	
		tv=television()	
		for title,href,img,isFolder in tv.additems(url):			
			if 'COLOR yellow' in title:
				addItem(title, href, 'xxx', icon['icon'],isFolder)							
			else:addItem(title,href,'episodes' if isFolder else 'stream',img,isFolder)
			
	elif 'hplus' in url:
		response = urlfetch.get(url)
		content = response.body
		match = re.compile('<a href="(http://hplus.com.vn/ti-vi-truc-tuyen/.+?)">\s*.+?(Kênh.+?)</a>').findall(content)
		for href, title in match:
			addItem(title.strip(), href, 'episodes', '')			
				
	elif re.search('hdvietnam.com|chiasenhac|nhaccuatui|fullmatchreplay.com|socceryou.com',url):
		fb=Football()
		for title,href,img,mode,isFolder in fb.additems(url,name,query,page):			
			addItem(title,href,mode,img,isFolder)
				
	elif re.search('fptplay.net|htvonline.com.vn|hdonline|phimmoi|megabox|hdviet.com|hayhaytv|phimgiaitri|phimnhanh|bilutv|phimbathu|hdsieunhanh|vietsubhd|xemphimbox|xuongphim|tvhay|fcine|vaphim|4share.vn|fsharefilm|pubvn',url):
		for title,href,img,isFolder in additems2(url,page):			
			if 'Trang tiếp theo' in title:
				addItem(title, href, img, icon['next'],True)#img='search_result&page=%d'%(page+1)
			else:addItem(title,href,'episodes' if isFolder else 'stream',img,isFolder)			
																					
	elif 'arenavision.in' in url:
		for i in range(30):
			addItem('Arenavision %s (ace)'%(i+1),'http://arenavision.in/av%s'%(str(i+1)),'play_ace','',False)	
			
		for i in range(10):
			addItem('Arenavision S%s (sopcast)'%(i+1),'http://arenavision.in/avs%s'%(str(i+1)),'play_ace','',False)	
	log(url)	

#############################################			
def Stream(url,name='',link='',subfile=''):														

	if 'http://vtvgo.vn//get-program-channel' in url:#truyen hinh xem lai
		content = xread(url)
		link=xsearch('"data":"(.+?.m3u8)",',content).replace('\/','/')

	elif 'fshare.vn' in url or '4share.vn' in url:		
		if '[]' in url:url,subfile=url.split('[]')

		server=url.split("//")[-1].split("www.")[-1].split("/")[0]		
		password=myaddon.getSetting('vipcode')
		content=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'%s/%s%s.py'%(base64.b64decode(x0x0x0x0),server,password))
		if not content:
			notify('Mã code không đúng.')
			return 'no'
		#xrw('code.py',content)
		#execfile(os.path.join(addonDataPath,'code.py'))
		#exec(xrw(os.path.join(addonDataPath,'code.py')))		
		exec(content)
		
		if '/file/' in subfile:
			link_sub=''
			link_sub=getLink(subfile)				
			if link_sub:
				ext=os.path.splitext(link_sub)[1][1:].lower()			
				if ext in ['rar','zip','srt','sub','txt','smi','ssa','ass','nfo']:
					subfile=xshare_download(link_sub)
		
		link=getLink(url)		
		if link:
			ext=os.path.splitext(link)[1][1:].lower()			
			if 'Download' in query:fshare_download(link)
			elif ext in ['rar','zip','srt','sub','txt','smi','ssa','ass','nfo']:
				result=xshare_download(link);return ''
			elif '.xml' in link:return link
			
			url=link
			urltitle=urllib.unquote(os.path.splitext(os.path.basename(url))[0]).lower()
			urltitle='.'+'.'.join(s for s in re.sub('_|\W+',' ',re.split('\d\d\d\d',urltitle)[0]).split())+'.'
			subfile='';items=[]
			for file in os.listdir(subsfolder):
				filefullpath=joinpath(subsfolder,file).encode('utf-8')
				filename=re.sub('vie\.|eng\.','',os.path.splitext(file)[0].lower().encode('utf-8'))				
				#filename=re.split('|'.join(str(i) for i in range(1930,2020)),filename)[0];count=0
				filename=re.split('\d\d\d\d',filename)[0];count=0
				for word in re.sub('_|\W+',' ',filename).split():
					if '.%s.'%word in urltitle:count+=1
				if count:items.append((count,filefullpath))
			for item in items:
				if item[0]>=count:count=item[0];subfile=item[1]			
										
	elif re.search('tv24.vn|fptplay|htvonline|vtvgo|hplus|drive.google|hdviet.com|hayhaytv|hdonline|megabox|phimmoi|phimnhanh|phimgiaitri|xuongphim|fcine|bilutv|phimbathu|vietsubhd|hdsieunhanh|xemphimbox|tvhay',url):
		server=url.split("//")[-1].split("www.")[-1].split("/")[0]
		content=xread(decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'%s/%s.py'%(base64.b64decode(x0x0x0x0),server))
		#content.replace('\r\n', '\n')
		xrw('code.py',content)
		execfile(os.path.join(addonDataPath,'code.py'))
		link,subfile=getLink(url)
																																				
	elif re.search('chiasenhac|nhaccuatui|fullmatchreplay.com|socceryou.com',url):
		fb=Football()
		link=fb.getLink(url)
	else:
		link = url		

	if 'youtube.com' in link:
		#plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=
		link = link.replace('https://www.youtube.com/watch?v=', 'plugin://plugin.video.youtube/?action=play_video&videoid=')
	elif 'sop://' in url:
		link = 'plugin://program.plexus/?mode=2&url=%s&name=%s'%(url,urllib.quote_plus(name)) 
	elif 'acestream://' in url:
		link = 'plugin://program.plexus/?mode=1&url=%s&name=%s'%(url,urllib.quote_plus(name))
		
	if link is None or len(link) == 0:
		notify('Lỗi không lấy được link.');return 'no'
	
	if img:item=xbmcgui.ListItem(path=link, iconImage=img, thumbnailImage=img)
	else:item=xbmcgui.ListItem(path=link)
		
	if 'fshare' in link:item.setInfo('video', {'Title':urllib.unquote(os.path.basename(link))})	
	else:item.setInfo('video', {'Title':name})	
	

	if not subfile and myaddon.getSetting('advertisement') == 'false':
		subfile = decode('ROOT', 'usPDxIx-frezvcPDtMTCvMG_fbfBvH6slJySgw==')+'quangcao.srt'		
	if subsfolder not in subfile:
		content=xread(subfile)
		subfile = os.path.join(addonDataPath,"subs.srt")
		makerequest(subfile,content,'wb')
	item.setSubtitles([subfile])
	#if subfile:xbmc.sleep(2000);xbmc.Player().setSubtitles(subfile)	

	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)		
	return
								
def addItem(name,url,mode,iconimage,isFolder=True, info={}, art={}, menu={}):
	if 'Trang ' not in name:
		if 'xml' in mode or '.xml' in name:
			name='[COLOR yellow][List xml][/COLOR] '+name
		elif 'fshare.vn/file' in url and 'xml' not in mode:
			name='[COLOR yellow][Fshare][/COLOR] '+name
		elif '4share.vn/f/' in url:
			name='[COLOR yellow][4share][/COLOR] '+name

	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		
	if not url:
		mode='xxx';isFolder=False
				
	elif ('4share.vn/f/' in url or 'fshare.vn/file' in url) and 'Trang ' not in name:
		items=list()			
		if url in makerequest(joinpath(myfolder,'mylist.xml')):
			tmp=['Download vào Thư mục cục bộ', 'Sửa tên trong file mylist.xml','Xóa từ file mylist.xml']
		else:
			tmp=['Download vào Thư mục cục bộ', 'Thêm vào file mylist.xml']
			
		for s in tmp:
			p=(sys.argv[0],'stream' if 'Download' in s else 'local',name,url,img,fanart,s)
			command='RunPlugin(%s/?mode=%s&name=%s&url=%s&img=%s&fanart=%s&query=%s)'%(p)
			items.append(( s, command, ))
		liz.addContextMenuItems(items)
		
		if '.xml' in name or 'xml' in mode:mode='xml';isFolder=True
		else:mode='stream';isFolder=False
	elif 'fshare.vn/folder' in url or '4share.vn/d/' in url:		
		mode='folder';isFolder=True
	elif myfolder in s2u(url):
		items=list()								
		for s in ['Sửa tên', 'Xóa']:				
			s=s+' '+('folder' if isFolder and '.xml' not in url else 'file')			
			p=(myaddon.getAddonInfo('id'),'local',name,url,img,fanart,s)
			command='RunPlugin(plugin://%s/?mode=%s&name=%s&url=%s&img=%s&fanart=%s&query=%s)'%(p)					
			items.append(( s, command, ))
		liz.addContextMenuItems(items)

	#q={'name':name,'url':url,'img':img,'fanart':fanart,'mode':mode,'page':page,'query':query}
	#u=sys.argv[0]+'?'+urllib.urlencode(q)		
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
		
	if not info:info={ "Title": name }
	liz.setInfo("video", info)	
	if art:liz.setArt(art)#{"thumb":iconimage,"poster":iconimage,"fanart":iconimage}	
	liz.setProperty("isPlayable", isFolder and "false" or "true")	
			
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
	return True
	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param
### ------------

def GA(title="Home",page="/"):
	'''
	Hàm thống kê lượt sử dụng bằng Google Analytics (GA)
	Parameters
	----------
	title : string
		Tên dễ đọc của view.
	page : string
		Đường dẫn của view.
	'''
	try:
		ga_url    = "http://www.google-analytics.com/collect"
		client_id = open(cid_path).read()
		data      = {
			'v'   : '1',
			'tid' : 'UA-89611577-1', #Thay GA id của bạn ở đây
			'cid' : client_id,
			't'   : 'pageview',
			'dp'  : "CantobuMedia%s" % page,
			'dt'  : "[CantobuMedia] - %s" % title
		}
		http.request(
			ga_url, "POST",
			body=urllib.urlencode(data)
		)
	except:
		pass

# Tạo client id cho GA tracking
# Tham khảo client id tại https://support.google.com/analytics/answer/6205850?hl=vi
device_path = xbmc.translatePath('special://userdata')
if os.path.exists(device_path)==False:
	os.mkdir(device_path)
cid_path = os.path.join(device_path, 'cid')
if os.path.exists(cid_path)==False:
	with open(cid_path,"w") as f:
		f.write(str(uuid.uuid1()))

try:
	myfolder=s2u(myaddon.getSetting('thumuccucbo'))
	if not os.path.exists(myfolder):myfolder=joinpath(datapath,'myfolder')
except:myfolder=joinpath(datapath,'myfolder')
subsfolder=joinpath(addonDataPath,'subs')
params=get_params();page=0;temp=[];mode=url=name=fanart=img=date=query=action=end=text=''

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:img=urllib.unquote_plus(params["img"])
except:pass
try:fanart=urllib.unquote_plus(params["fanart"])
except:pass
try:mode=str(params["mode"])
except:pass
try:page=int(params["page"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass#urllib.unquote

### ------------
log('========================================================================')
log("Mode: %s"%mode)
log("Name: %s"%name)
log("URL: %s"%url[:200])
log("Image: %s"%img)
log("Query: %s"%query)
log("Page: %d"%page)
log('========================================================================')

GA( # tracking
	"%s" % mode,
	"/%s" % url
)

if not mode:	
	for folder in (addonDataPath,datapath,iconpath,myfolder,subsfolder):
		log(folder)
		if not os.path.exists(folder):os.mkdir(folder)
	xmlheader='<?xml version="1.0" encoding="utf-8">\n'
	for i in [(datapath,'search.xml'),(myfolder,'mylist.xml')]:
		file=joinpath(i[0],i[1])
		if not os.path.isfile(file):makerequest(file,xmlheader,'w')
			
	#GA() # tracking			
	strReturn = Home(url,query)				
	xbmcplugin.endOfDirectory(int(sys.argv[1]))				
	
	try:
		exec(xread(strReturn))
		download()	
	except:pass
	
elif mode == 'home':
	strReturn = Home(url,query)
	
	if 'PHIM-' in query:
		try:
			exec(xread(strReturn))
			UpdateDB(query.split('[]')[0])
		except:pass
		
elif mode == 'tags':Tags(url,query)
elif mode == 'tags-movie':TagsMovie(url,query)
elif mode == 'index':Index(url,name,query,page)
elif mode == 'category':Category(url,name,query,page)
elif mode == 'episodes' or mode == 'folder':episodes(url,name,query,img)
elif mode == 'xml':doc_list_xml(url,page)
elif mode == 'local':Local(name,url,img,fanart,mode,query)
elif mode == 'remote':Remote(name,url,img,mode,page,query)
elif mode == 'search':end=Search(url,query)
elif mode == 'search_result':Result(url, name, query, page)
elif mode == 'stream':end=Stream(url,name)
elif mode == 'play':Stream(url,link=url)
elif mode == 'play_ace':
	headers = {"Cookie" : "beget=begetok; has_js=1;"}
	html = xfetch(url,headers=headers).text	
	if 'avs' in url:#sopcast
		match = re.compile('sop://(.+?)"').findall(html)
		url='plugin://program.plexus/?mode=2&url=sop://%s&name=Video'%match[0]
	else:
		match = re.compile('this.loadPlayer\("(.+?)"').findall(html)
		url='plugin://program.plexus/?mode=1&url=acestream://%s&name=Video'%match[0]
		
	xbmc.Player().play(url)		
	
elif 'serverlist' in mode:ServerList(name, url, mode, page, query, img)	
elif mode == 'setting':myaddon.openSettings();end='ok'

try:	
	if not mode and not query:	
		xbmc.executebuiltin('Container.SetViewMode(500)')# Thumbnails		
	elif '2@phim-' in url:
		xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
		xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
		#xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
		xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)	
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		#xbmc.executebuiltin('Container.SetViewMode(504)')# Media info
except:pass	
	
if not end or end not in 'no-ok-fail':xbmcplugin.endOfDirectory(int(sys.argv[1]))