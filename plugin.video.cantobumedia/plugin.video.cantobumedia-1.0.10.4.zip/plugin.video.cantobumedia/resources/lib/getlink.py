# -*- coding: utf-8 -*-
#https://www.facebook.com/groups/vietkodi/

import re
import urllib,urllib2,urlfetch
import os
from time import sleep
from setting import notify, alert, myaddon
import simplejson as json
import random
import xbmc
import requests

VIETMEDIA_HOST = "http://vietmediaf.net/kodi.php"


def log(s):
	if isinstance (s,str):s=s.decode("utf-8")
	message = u'%s'%s
	xbmc.log(msg=message.encode("utf-8"))


def fetch_data(url, headers=None, data=None):
  	if headers is None:

  		headers = { 
    				'User-agent'		: 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                	'Referer'			: 'http://www.google.com'
            }
  	try:

  		if data:
  			response = urlfetch.post(url, headers=headers, data=data)
  		else:
			response = urlfetch.get(url, headers=headers)

		return response

	except Exception as e:
  		print e
  		pass


def get(url):
	if 'fptplay.net' in url:
		return get_fptplay(url)
	if 'www.fshare.vn' in url:
		return get_fshare(url)
	if 'hdonline.vn' in url:
		return get_hdonline(url)
	else:
		return url
		
def get_hdonline(url):
	#Đăng nhập HDONLINE
	url_login = 'http://id.hdonline.vn/dang-nhap.html'
	response = requests.get(url_login)
	#cookie = response.cookiestring;
	s = requests.Session()
	matches = re.search(r"value=\"(.*?)\"", response.content)
	key_login = matches.group(1)

	headers = {'Host': 'id.hdonline.vn', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0', 'Referer': 'http://hdonline.vn/'}
	data = {'primaryKey': key_login, 'username': 'ngocduc1977', 'password': 'servex'}

	s = requests.Session()
	r = s.post(url_login, headers=headers, data=data)
	notify (u'Login thành công'.encode("utf-8"))
		
	attempt = 1
	MAX_ATTEMPTS = 5
		
	while attempt < MAX_ATTEMPTS:
		if attempt > 1: 
			sleep(2)
		url_play = ''
		#print (u'Lấy link lần thứ #%s'.encode("utf-8") % attempt)
		attempt += 1
		
		headers={'User-Agent':'Mozilla/5.0','Referer': 'http://hdonline.vn'}
		response = s.get(url, headers=headers)
		
		if not response:
			return ''

		match = re.search(r'\-(\d+)\.?\d*?\.html$', url)
		if not match:
			return ''
		fid = match.group(1)

		match = re.search(r'\-tap-(\d+)-[\d.]+?\.html$', url)
		if not match:
			ep = 1
		else:
			ep = match.group(1)
		
		match = re.search(r'\|(\w{86}|\w{96})\|', response.content)
		if match:
			token = match.group(1)
			
			match = re.search(r'\|14(\d+)\|', response.content)
			token_key = '14' + match.group(1)
			
			token = token + '-' + token_key

			_x = random.random()
			url_play = ('http://hdonline.vn/frontend/episode/xmlplay?ep=%s&fid=%s&format=json&_x=%s&token=%s' % (ep, fid, _x, token))
			break
		else:
			match = re.search(r'"file":"(.*?)","', response.content)
			if match:
				url_play = 'http://hdonline.vn' + match.group(1).replace('\/','/') + '&format=json'
				url_play = url_play.replace('ep=1','ep=' + str(ep))
				break
	if len(url_play) == 0:
		#print (u'Không lấy được link.')
		return ''

	headers = { 
				'User-Agent' 	: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36',
				'Referer'		: url,
				'Accept'		: 'application/json, text/javascript, */*; q=0.01',
				#'Cookie'		: cookie
			}
	response = s.get(url_play, headers=headers)

	json_data = json.loads(response.content)
	video_url = json_data['file']
	if json_data.get('level') and len(json_data['level']) > 0:
		video_url = json_data['level'][len(json_data['level']) - 1]['file']

	subtitle_url = ''
	if json_data.get('subtitle') and len(json_data['subtitle']) > 0:
		for subtitle in json_data['subtitle']:
			subtitle_url = subtitle['file']
			if subtitle['code'] == 'vi':
				subtitle_url = subtitle['file']
				break

	if len(subtitle_url) > 0:		
		subtitle_url = ('http://data.hdonline.vn/api/vsub.php?url=%s' % subtitle_url)
		return video_url,subtitle_url
	else:
		return video_url,subtitle_url
