# -*- coding: utf-8 -*-
import urllib,urllib2,urlfetch, re, os, json
from time import sleep
from setting import *
from utils import *
from urlfetch import get,post

import random
import xbmc

def log(s):
	if isinstance (s,str):s=s.decode("utf-8")
	message = u'%s'%s
	xbmc.log(msg=message.encode("utf-8"))
	
def gibberishAES(string, key=''):
	import ctypes
	def aa(l,s=4):
		a=[]
		for i in range(0,len(l),s):a.append((l[i:i+s]))
		return a

	def j2p(v):return ctypes.c_int(v).value
	def rshift(val, n): return (val % 0x100000000) >> n

	e = 14
	r = 8
	n = False
		
	def f(e):
		#try:result=urllib.quote(e)
		#except:result=str(e)
		return str(e)
		
	def c(e):
		#try:result=urllib.quote(e, safe='~()*!.\'')
		#except:result=str(e)
		return str(e)

	def t(e):
		f = [0]*len(e)
		if 16 >len(e):
			r = 16 - len(e)
			f = [r, r, r, r, r, r, r, r, r, r, r, r, r, r, r, r]
		for n in range(len(e)):f[n] = e[n]
		return f

	def o(e):
		n = ""
		for r in len(e):n += ("0" if 16 > e[r] else "") + format(e[r], 'x')
		return n

	def u(e, r):
		c = []
		if not r:e=f(e)
		for n in range(len(e)):c.append(ord(e[n]))
		return c

	def i(n):
		if n==128:e = 10; r = 4
		elif n==192:e = 12;r = 6
		elif n==256:e = 14;r = 8

	def b(e):
		n = []
		for r in range(e):n.append(256)
		return n

	def h(n, f):
		d=[];t= 3 if e >= 12 else 2; i = n + f; d.append(L(i));u=[c for c in d[0]]
		for c in range(1,t):d.append(L(d[c - 1] + i));u+=d[c]
		return {'key': u[0 : 4 * r],'iv': u[4 * r : 4 * r + 16]}

	def a1(e, r=False):
		c = ""
		if (r):
			n = e[15]
			#if n > 16:print "Decryption error: Maybe bad key"
			if 16 != n:
				for f in range(16 - n):c += chr(e[f])
		else:
			for f in range(16):c += chr(e[f])
		return c

	def a(e, r=False):
		if not r:c=''.join(chr(e[f])for f in range(16))
		elif 16!=e[15]:c=''.join(chr(e[f]) for f in range(16-e[15]))
		else:c=''
		return c

	def v(e, r, n, f=''):
		r = S(r); o = len(e) / 16; u = [0]*o
		d=[e[16 * t: 16 * (t + 1)] for t in range(o)]
		for t in range(len(d) - 1,-1,-1):
			u[t] = p(d[t], r)
			u[t] = x(u[t], n) if 0 == t else x(u[t], d[t - 1])
		
		i=''.join(a(u[t]) for t in range(o-1))
		i += a(u[o-1], True)
		return i if f else c(i)

	def s(r, f):
		n = False
		t = M(r, f, 0)
		for c in (1, e + 1 ,1):
			t = g(t)
			t = y(t)
			if e > c:t = k(t)
			t = M(t, f, c)
		return t

	def p(r, f):
		n = True
		t = M(r, f, e)
		for c in range(e - 1,-1,-1):
			t = y(t,n)
			t = g(t,n)
			t = M(t, f, c)
			if c > 0 : t = k(t,n)
		return t

	def g(e,n=True):#OK
		f = D if n else B; c = [0]*16
		for r in range(16):c[r] = f[e[r]]
		return c

	def y(e,n=True):
		f = []
		if n: c = [0, 13, 10, 7, 4, 1, 14, 11, 8, 5, 2, 15, 12, 9, 6, 3] 
		else:c =[0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
		for r in range(16):f.append(e[c[r]])
		return f

	def k(e,n=True):
		f = [0]*16
		if (n):
			for r in range(4):
				f[4 * r] = F[e[4 * r]] ^ R[e[1 + 4 * r]] ^ j[e[2 + 4 * r]] ^ z[e[3 + 4 * r]]
				f[1 + 4 * r] = z[e[4 * r]] ^ F[e[1 + 4 * r]] ^ R[e[2 + 4 * r]] ^ j[e[3 + 4 * r]]
				f[2 + 4 * r] = j[e[4 * r]] ^ z[e[1 + 4 * r]] ^ F[e[2 + 4 * r]] ^ R[e[3 + 4 * r]]
				f[3 + 4 * r] = R[e[4 * r]] ^ j[e[1 + 4 * r]] ^ z[e[2 + 4 * r]] ^ F[e[3 + 4 * r]]
		else:
			for r in range(4):
				f[4 * r] = E[e[4 * r]] ^ U[e[1 + 4 * r]] ^ e[2 + 4 * r] ^ e[3 + 4 * r]
				f[1 + 4 * r] = e[4 * r] ^ E[e[1 + 4 * r]] ^ U[e[2 + 4 * r]] ^ e[3 + 4 * r]
				f[2 + 4 * r] = e[4 * r] ^ e[1 + 4 * r] ^ E[e[2 + 4 * r]] ^ U[e[3 + 4 * r]]
				f[3 + 4 * r] = U[e[4 * r]] ^ e[1 + 4 * r] ^ e[2 + 4 * r] ^ E[e[3 + 4 * r]]
		return f	

	def M(e, r, n):#OK
		c = [0]*16
		for f in range(16):c[f] = e[f] ^ r[n][f]
		return c

	def x(e, r):
		f = [0]*16
		for n in  range(16):f[n] = e[n] ^ r[n]
		return f

	def S(n):#r=8;e=14
		o=[[n[4 * f + i] for i in range(4)] for f in range(r)]
		
		for f in range(r,4 * (e + 1)):
			d=[t for t in o[f-1]]
			if 0 == f % r:d = m(w(d)); d[0] ^= K[f / r - 1]
			elif r > 6 and 4 == f % r : d = m(d)
			o.append([o[f - r][t] ^ d[t] for t in range(4)])
		
		u = []
		for f in range(e + 1):
			u.append([])
			for a in range(4):u[f]+=o[4 * f + a]
		return u

	def m(e):
		return [B[e[r]] for r in range(4)]

	def w(e):
		e.insert(4,e[0])
		e.remove(e[4])
		return e

	def A(e, r):return [int(e[n:n+r], 16) for n in range(0,len(e),r)]

	def C(e):
		n=[0]*len(e)
		for r in range(len(e)):n[e[r]] = r
		return n

	def I(e, r):
		f=0
		for n in range(8):
			f = f ^ e if 1 == (1 & r) else f
			e = j2p(283 ^ e << 1) if e > 127 else j2p(e << 1)
			r >>= 1
		return f

	def O(e):
		n = [0]*256
		for r in range(256):n[r] = I(e, r)
		return n

	B = A("637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16", 2)
	D = C(B)
	K = A("01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591", 2)
	E = O(2)
	U = O(3)
	z = O(9)
	R = O(11)
	j = O(13)
	F = O(14)

	def G(e, r, n):
		c = b(8); t = h(u(r, n), c); a = t.key; o = t.iv; d = [83, 97, 108, 116, 101, 100, 95, 95]+c
		e = u(e, n)
		f = l(e, a, o)
		f = d+f
		return T.encode(f)

	def H(e, r, n=''):
		f = decode(e)
		c = f[8 : 16]
		t = h(u(r, n), c)
		a = t['key']
		o = t['iv']
		f = f[16 : len(f)]
		return v(f, a, o, n)

	def decode(r):#OK
		def indexOfchar(n):
			try:a=e.index(r[n])
			except:a=-1
			return a
		
		e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
		r=r.replace('\n','');f=[];c=[0]*4
		for n in range(0,len(r),4):
			for i in range(len(c)):c[i]=indexOfchar(n+i)
			f.append(j2p(c[0]<<2|c[1]>>4))
			f.append(j2p((15&c[1])<<4|c[2]>>2))
			f.append(j2p((3&c[2])<<6|c[3]))
		return f[0:len(f)-len(f)%16]

	def L(e):
		def r(e, r):return j2p(e << r) | j2p(rshift(e, 32-r))

		def n(e, r):
			c = 2147483648 & e
			t = 2147483648 & r
			n = 1073741824 & e
			f = 1073741824 & r
			a = (1073741823 & e) + (1073741823 & r)
			i = 2147483648^a^c^t
			j = 3221225472^a^c^t
			k = 1073741824^a^c^t
			return j2p(i if n & f else ((j if 1073741824 & a else k) if n | f else a^c^t))		

		def f(e, r, n):return j2p(e & r) | j2p(~e & n)

		def c(e, r, n):return j2p(e & n) | j2p(r & ~n)

		def t(e, r, n):return e ^ r ^ n

		def a(e, r, n):return r ^ (e | ~n)

		def o(e, c, t, a, o, d, u):
			e = n(e, n(n(f(c, t, a), o), u))
			return n(r(e, d), c)

		def d(e, f, t, a, o, d, u):
			e = n(e, n(n(c(f, t, a), o), u))
			return n(r(e, d), f)

		def u(e, f, c, a, o, d, u):
				e = n(e, n(n(t(f, c, a), o), u))
				return n(r(e, d), f)

		def i(e, f, c, t, o, d, u):
			e = n(e, n(n(a(f, c, t), o), u))
			return n(r(e, d), f)

		def b(e):
			n=len(e); f = n + 8; c = (f - f % 64) / 64; t = 16 * (c + 1); a = [0]*t; o = 0
			for d in range(n):r = (d - d % 4) / 4; o = 8 * (d % 4);	a[r] = a[r] | j2p(e[d] << o)
			d+=1
			r = (d - d % 4) / 4
			o = 8 * (d % 4)
			a[r] = a[r] | j2p(128 << o)
			a[t - 2] = j2p(n << 3)
			a[t - 1] = j2p(rshift(n,29))
			return a

		def h(e):
			f = []
			for n in range(4):
				r = j2p(255 & rshift(e, 8 * n))
				f.append(r)
			return f

		m = A("67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391", 8)
		S = [];  S = b(e); y = m[0]; k = m[1]; M = m[2]; x = m[3]; l = 0
		for l in range(0,len(S),16):
			v = y
			s = k
			p = M
			g = x
			y = o(y, k, M, x, S[l + 0], 7, m[4])
			x = o(x, y, k, M, S[l + 1], 12, m[5])
			M = o(M, x, y, k, S[l + 2], 17, m[6])
			k = o(k, M, x, y, S[l + 3], 22, m[7])
			y = o(y, k, M, x, S[l + 4], 7, m[8])
			x = o(x, y, k, M, S[l + 5], 12, m[9])
			M = o(M, x, y, k, S[l + 6], 17, m[10])
			k = o(k, M, x, y, S[l + 7], 22, m[11])
			y = o(y, k, M, x, S[l + 8], 7, m[12])
			x = o(x, y, k, M, S[l + 9], 12, m[13])
			M = o(M, x, y, k, S[l + 10], 17, m[14])
			k = o(k, M, x, y, S[l + 11], 22, m[15])
			y = o(y, k, M, x, S[l + 12], 7, m[16])
			x = o(x, y, k, M, S[l + 13], 12, m[17])
			M = o(M, x, y, k, S[l + 14], 17, m[18])
			k = o(k, M, x, y, S[l + 15], 22, m[19])
			y = d(y, k, M, x, S[l + 1], 5, m[20])
			x = d(x, y, k, M, S[l + 6], 9, m[21])
			M = d(M, x, y, k, S[l + 11], 14, m[22])
			k = d(k, M, x, y, S[l + 0], 20, m[23])
			y = d(y, k, M, x, S[l + 5], 5, m[24])
			x = d(x, y, k, M, S[l + 10], 9, m[25])
			M = d(M, x, y, k, S[l + 15], 14, m[26])
			k = d(k, M, x, y, S[l + 4], 20, m[27])
			y = d(y, k, M, x, S[l + 9], 5, m[28])
			x = d(x, y, k, M, S[l + 14], 9, m[29])
			M = d(M, x, y, k, S[l + 3], 14, m[30])
			k = d(k, M, x, y, S[l + 8], 20, m[31])
			y = d(y, k, M, x, S[l + 13], 5, m[32])
			x = d(x, y, k, M, S[l + 2], 9, m[33])
			M = d(M, x, y, k, S[l + 7], 14, m[34])
			k = d(k, M, x, y, S[l + 12], 20, m[35])
			y = u(y, k, M, x, S[l + 5], 4, m[36])
			x = u(x, y, k, M, S[l + 8], 11, m[37])
			M = u(M, x, y, k, S[l + 11], 16, m[38])
			k = u(k, M, x, y, S[l + 14], 23, m[39])
			y = u(y, k, M, x, S[l + 1], 4, m[40])
			x = u(x, y, k, M, S[l + 4], 11, m[41])
			M = u(M, x, y, k, S[l + 7], 16, m[42])
			k = u(k, M, x, y, S[l + 10], 23, m[43])
			y = u(y, k, M, x, S[l + 13], 4, m[44])
			x = u(x, y, k, M, S[l + 0], 11, m[45])
			M = u(M, x, y, k, S[l + 3], 16, m[46])
			k = u(k, M, x, y, S[l + 6], 23, m[47])
			y = u(y, k, M, x, S[l + 9], 4, m[48])
			x = u(x, y, k, M, S[l + 12], 11, m[49])
			M = u(M, x, y, k, S[l + 15], 16, m[50])
			k = u(k, M, x, y, S[l + 2], 23, m[51])
			y = i(y, k, M, x, S[l + 0], 6, m[52])
			x = i(x, y, k, M, S[l + 7], 10, m[53])
			M = i(M, x, y, k, S[l + 14], 15, m[54])
			k = i(k, M, x, y, S[l + 5], 21, m[55])
			y = i(y, k, M, x, S[l + 12], 6, m[56])
			x = i(x, y, k, M, S[l + 3], 10, m[57])
			M = i(M, x, y, k, S[l + 10], 15, m[58])
			k = i(k, M, x, y, S[l + 1], 21, m[59])
			y = i(y, k, M, x, S[l + 8], 6, m[60])
			x = i(x, y, k, M, S[l + 15], 10, m[61])
			M = i(M, x, y, k, S[l + 6], 15, m[62])
			k = i(k, M, x, y, S[l + 13], 21, m[63])
			y = i(y, k, M, x, S[l + 4], 6, m[64])
			x = i(x, y, k, M, S[l + 11], 10, m[65])
			M = i(M, x, y, k, S[l + 2], 15, m[66])
			k = i(k, M, x, y, S[l + 9], 21, m[67])
			y = n(y, v)
			k = n(k, s)
			M = n(M, p)
			x = n(x, g)
		return h(y)+h(k)+h(M)+h(x)

		
	def recode(b):
		def getcode(s):
			w, i, s, e=s.split(',')
			a=b=c=0;d=[];f=[]
			while True:
				if a < 5:f.append(w[a])
				elif a < len(w):d.append(w[a])
				a+=1
				
				if  b < 5 :f.append(i[b])
				elif  b < len(i):d.append(i[b])
				b+=1
				
				if  c < 5:f.append(s[c])
				elif  c < len(s):d.append(s[c])
				c+=1
				
				if len(w) + len(i) + len(s) + len(e) == len(d) + len(f) + len(e):break

			k=''.join(s for s in d);m=''.join(s for s in f);b=0;o=[]
			for a in range(0,len(d),2):
				n = -1
				if ord(m[b]) % 2:n = 1
				o.append(chr(int(k[a:a+2], 36) - n))
				b+=1
				if b >= len(f):b = 0
			return ''.join(s for s in o)
		l=0
		while l<5 or 'decodeLink' not in b:
			try:b=getcode(xsearch("(\w{100,},\w+,\w+,\w+)",b.replace("'",'')));l+=1
			except:break
		return b
	
	return H(string, key) if key else recode(string)
	
def resolu(s):
	s=s.replace('HDG','').replace('HD','1080').replace('SD','640').replace('large','640').replace('medium','480').replace('small','360')
	result=xsearch('(\d+)',s)
	return result if result else '240'
	
def dl(l):#Direct link
	o=make_request(l,resp='o',maxr=5);h=''
	try:s=int(o.headers.get('content-length'))
	except:s=0
	s=0 if s<10**7 else s
	if s and o.history:h=o.history[-1].headers['location']
	elif s:h=l
	return h

color={'trangtiep':'[COLOR lime]','cat':'[COLOR green]','search':'[COLOR red]','phimbo':'[COLOR tomato]','phimle':'[COLOR yellow]','imdb':'[COLOR yellow]','namphathanh':'[COLOR yellow]','theloai':'[COLOR green]','quocgia':'[COLOR blue]'}

hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}		
def make_request(url,headers=hd,resp='b',maxr=0):
	try:
		if maxr==0:response=get(url,headers=headers)#,timeout=2)
		else:response=get(url,headers=headers,max_redirects=maxr)#,timeout=2)
		if resp=='o':resp=response
		else:
			if resp=='j':resp=response.json
			elif resp=='s':resp=response.status
			elif resp=='u':resp=response.text
			elif resp=='c':resp=response.cookiestring
			else:resp=response.body
			response.close()
	except:
		if resp=='j':resp=dict()
		elif resp=='s':resp=500
		else:resp=''
		if 'vaphim.com' not in url:
			link=xsearch('//(.{5,20}\.\w{2,3})',s2u(url))
			if not link:link=url
			notify(u'Lỗi kết nối tới: %s!'%xsearch('//(.{5,20}\.\w{2,3})',s2u(url)),'make_request')
		print 'Lỗi kết nối tới: %s!'%u2s(url);
	return resp#unicode:body=response.text		
		
def json_rw(file,dicts={},key=''):
	if dicts:makerequest(joinpath(datapath,file),json.dumps(dicts),'w')
	else:
		try:dicts=json.loads(makerequest(joinpath(datapath,file)))
		except:dicts={}
		if key:dicts=dicts.get(key,())
	return dicts

		
class fshare:    
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 Gecko/20100101 Firefox/44.0','x-requested-with':'XMLHttpRequest'}

	def fetch_data2(self,url,headers='',data=None):
		try:response=urlfetch(url,headers=self.hd,data=data)
		except:response= None
		return response

	def fetch_data(self,url, headers=None, data=None):
		if headers is None:
			headers = self.hd
		try:
			if data:
				response = urlfetch.post(url, headers=headers, data=data)
			else:
				response = urlfetch.get(url, headers=headers)
			return response
		except:return None
			
	def getLink(self,url,username='', password=''):
		login_url = 'https://www.fshare.vn/login'
		logout_url = 'https://www.fshare.vn/logout'
		download_url = 'https://www.fshare.vn/download/get'

		#username = myaddon.getSetting('usernamef')
		#password = myaddon.getSetting('usernamef')

		try:
			url_account = 'http://www.aku.vn/linksvip'
			headers = { 
				'Referer'			: 'http://aku.vn/linksvip',
				'User-Agent'		: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
			}
			response = self.fetch_data('http://www.aku.vn/linksvip',headers=headers,data={ 'url_download' : url })
			if response.status==404:response = self.fetch_data('http://aku.vn/linksvip',headers=headers,data={ 'url_download' : url })
			link_match=re.search("<a href=http://download(.*?)\starget=_blank", response.body)
			if link_match:
				return 'http://download' + link_match.group(1)

		except Exception as e:
			pass


		#print 'username: '+username
		#print 'password: '+password
			
		if len(username) == 0  or len(password) == 0:
			alert(u'Bạn chưa nhập tài khoản fshare'.encode("utf-8"))
			return
		

		
		response = self.fetch_data(login_url)
		if not response:
			return
		
		csrf_pattern = '\svalue="(.+?)".*name="fs_csrf"'

		csrf=re.search(csrf_pattern, response.body)
		fs_csrf = csrf.group(1)

		headers = { 
					'User-Agent' 	: 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
					'Cookie'		: response.cookiestring
				}
		
		data = {
				"LoginForm[email]"		: username,
				"LoginForm[password]"	: password,
				"fs_csrf"				: fs_csrf
			}

		response = self.fetch_data(login_url, headers, data)
		headers['Cookie'] = response.cookiestring
		headers['Referer'] = url
		direct_url = ''
		attempt = 1
		MAX_ATTEMPTS = 5
		file_id = os.path.basename(url)
		if response and response.status == 302:
			notify (u'Đăng nhập fshare thành công'.encode("utf-8"))
			while attempt < MAX_ATTEMPTS:
				if attempt > 1: sleep(2)
				notify (u'Lấy link lần thứ #%s'.encode("utf-8") % attempt)
				attempt += 1

				response = self.fetch_data(url, headers, data)
				if response.status == 200:
					csrf=re.search(csrf_pattern, response.body)
					fs_csrf = csrf.group(1)
					data = {
							'fs_csrf'					: fs_csrf,
							'ajax'						: 'download-form',
							'DownloadForm[linkcode]'	: file_id
						}
					
					response=self.fetch_data(download_url, headers, data);
					
					json_data = json.loads(response.body)
					
					if json_data.get('url'):
						direct_url = json_data['url']
						break
					elif json_data.get('msg'):
						notify(json_data['msg'].encode("utf-8"))
				elif response.status == 302:
					direct_url = response.headers['location']
					break
				else:
					notify (u'Lỗi khi lấy link, mã lỗi #%s. Đang thử lại...'.encode("utf-8") % response.status) 

			response = self.fetch_data(logout_url, headers)
			if response.status == 302:
				notify (u'Đăng xuất fshare thành công'.encode("utf-8"))
		else:
			notify (u'Đăng nhập không thành công, kiểm tra lại tài khoản'.encode("utf-8"))
		if len(direct_url) > 0:
			notify (u'Đã lấy được link'.encode("utf-8"))
		else:
			notify (u'Không được link, bạn vui lòng kiểm tra lại tài khoản'.encode("utf-8"))
			
		return direct_url
	
class fptPlay:#from resources.lib.servers import fptPlay;fpt=fptPlay(c)
	def __init__(self):
		self.hd={'User_Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest','X-KEY':'123456'}
		self.hd['referer']='https://fptplay.net/'
		
	def detail(self,s):
		title=vnu(xsearch('title="([^"]+?)"',s))
		if not title:title=vnu(xsearch('alt="([^"]+?)"',s))
		label=' '.join(re.findall('<p[^<]*?>(.+?)</p>',s))+title
		dir=True if 'tập' in (title+label).lower() else False
		if xsearch('(\d+/\d+)',label):dir=True;title+=' [COLOR blue]%s[/COLOR]'%xsearch('(\d+/\d+)',label)
		if 'thuyếtminh' in (title+label).replace(' ','').lower():title='[COLOR blue]TM[/COLOR] '+title
		if 'phụđề' in (title+label).replace(' ','').lower():title='[COLOR green]PĐ[/COLOR] '+title
		href=xsearch('href="([^"]+?)"',s)
		if not href:href=xsearch('data-href="(.+?)"',s)
		if 'Đang diễn ra' in s:dir=None
		img=xsearch('src="([^"]+?\.jpg)',s)
		if not img:
			img=xsearch('data-original="([^"]+?\.jpg)',s)
			if not img:img=xsearch('data-original="([^"]+?\.png)',s)
		return title,href,img,dir
			
	def eps(self,url,page):
		data='film_id=%s&page=%d'%(xsearch('(\w{20,30})',url),page);items=[]
		b=xread('https://fptplay.net/show/episode',self.hd,data)
		for s in [i for i in re.findall('(<li.+?/li>)',b,re.S) if '"title_items"' in i]:
			title=xsearch('title="(.+?)"',s)
			epi=xsearch('<p class="title_items">.+? (\d+)',s)
			if epi:title=epi+'-'+title
			if 'phụđề' in title.replace(' ','').lower():title='[COLOR green]PĐ[/COLOR] '+title
			elif 'thuyếtminh' in title.replace(' ','').lower():title='[COLOR blue]TM[/COLOR] '+title
			#href=xsearch('(\w{20,30})',xsearch('href="(.+?)"',s))+'?'+xsearch('id="episode_(\d{1,4})"',s)
			href=xsearch('href="(.+?)"',s)
			items.append((vnu(title),href))

		if '&rsaquo;&rsaquo;' in b:items.append(('[COLOR lime]Các tập tiếp theo ...[/COLOR]',''))
		return items	
	
	def getLink(self,url,epi='1'):			
		#Kiểm tra live tivi 
		match = re.search(r'\/livetv\/(.*)$', url)
		if match:
			id = match.group(1)
			data=urllib.urlencode({'id':id,'type':'newchannel','quality':'3','episode':epi,'mobile':'web'})
			body=xread('https://fptplay.net/show/getlinklivetv',self.hd,data)
			return json.loads(body).get('stream')+'|User-Agent=Mozilla/5.0'
									
		match = re.search(r'\-([\w]+)\.html', url)
		if not match:return ''
		id = match.group(1)
		
		match = re.search(r'#tap-([\d]+)$', url)		
		if match:epi = match.group(1)
		else:epi = 1	
		
		data=urllib.urlencode({'id':id,'type':'newchannel','quality':'3','episode':epi,'mobile':'web'})
		body=xread('https://fptplay.net/show/getlink',self.hd,data)
		link=json.loads(body).get('stream')+'|User-Agent=Mozilla/5.0'
		return link
	

def	getInfo(id,href,titleVn,titleEn,img,year,eps='',quocgia='',theloai='',daodien='',dienvien='',thoiluong='',IMDb='',desc=''):
	info='{'
	info+='"id":"%s"'%id
	info+=',"href":[%s]'%href
	info+=',"titleVn":'+json.dumps(titleVn)		
	info+=',"titleEn":'+json.dumps(titleEn)
	info+=',"thumb":'+json.dumps(img)	
	info+=',"year":'+json.dumps(year)	
	info+=',"episode":'+json.dumps(eps)	
	
	info+=',"country":'+json.dumps(quocgia)
	info+=',"genre":'+json.dumps(theloai)
	info+=',"writer":'+json.dumps(daodien)
	info+=',"director":'+json.dumps(dienvien)
	info+=',"duration":'+json.dumps(thoiluong)
	info+=',"rating":'+json.dumps(IMDb)				
	info+=',"plot":'+json.dumps(desc)
	info+='}'
	info=info.replace('/','\/')	
	
	return info
		
class hayhayvn:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.hayhaytv.vn/dieu-khoan-su-dung.html'}

	def getLink(self,url):
		tap=xsearch('-Tap-(\d+)-',url)
		if tap:tap='_'+tap
		if '/show-' in url:url='http://www.hayhaytv.vn/getsourceshow/%s'%(xsearch('-(\w+)\.html',url)+tap)
		else:url='http://www.hayhaytv.vn/getsource/%s'%(xsearch('-(\w+)\.html',url)+tap)
		b=xread(url,self.hd)
		try:items=ls([(i.get('file','').replace('\\',''),rsl(i.get('label',''))) for i in eval(b)])
		except:items=[]
		return items
		
		
	def getLink2(self,url):
		b=xread(url)
		link=xsearch('file.{,5}"(.+?)"',b);sub=''
		if link:sub=xsearch("var track.{,5}'(.+?)'",b)
		else:
			url='http://www.hayhaytv.vn/getsource/%s'%xsearch("FILM_KEY = '(.+?)'",b)
			b=xread(url,self.hd)
			try:j=eval(b)
			except:j=[]
			links=[(i.get('file').replace('\\',''),i.get('label')) for i in j]
			for href,r in ls([(i[0],rsl(i[1])) for i in links]):
				g=xget(href)
				if g:link=g.geturl();break
		return link,sub
		
class hdonline:
	def __init__(self):
		self.home='http://hdonline.vn'

	def additems(self,body,mode,page):
		items=[]
		for content in re.findall('<li>\s*<div class="tn-bxitem">(.+?)</li>',body,re.S):
			titleVn=xsearch('<p class="name-en">(.+?)</p>',content).strip()
			titleEn=xsearch('<p class="name-vi">(.+?)</p>',content).strip()
			
			href=xsearch('<a href="(.+?)"',content).strip()

			IMDb=xsearch('<p>Đánh giá:(.+?)</p>',content).strip()
			year=xsearch('<p>Năm sản xuất:(.+?) </p>',content).strip()
			
			#lay desc truc tiep thau </li> = <div class="clearfix"> o content
			#desc=xsearch('<div class="tn-contentdecs mb10">(.+?)</div>',content,1,re.DOTALL)											
			
			href='http://hdonline.vn'+href
			img=xsearch('<img src="(.+?)"',content).strip()

			if 'Cinderella Girls 2nd Season' in titleVn:titleVn='The iDOLM@STER Cinderella Girls 2nd Season'
			if 'Cinderella Girls 2nd Season' in titleEn:titleEn='The iDOLM@STER Cinderella Girls 2nd Season'
			if titleVn==titleEn:titleEn=''
			if titleEn:title = titleVn + ' (' + titleEn + ')'
			else:title = titleVn
			if year in title:title=title.replace(year,'').strip()			

			eps = xsearch('Số Tập: (.+?) </p>',content)				
			
			b = xread(href)
			desc=xsearch('itemprop="description">(.+?)</div>',b,1,re.DOTALL)
			desc=re.sub('<(.+?)>','',desc).replace('\n','')

			v_theloai=xsearch('<li>Thể loại:(.+?)</li>',b)
			theloai=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_theloai))
			
			v_quocgia=xsearch('<li>Quốc gia:(.+?)</li>',b)
			quocgia=', '.join(i for i in re.findall('<a href=".+?">Phim (.+?)</a>',v_quocgia))
			
			thoiluong=xsearch('<li>Thời lượng: (.+?)</li>',b).strip()
			
			v_daodien=xsearch('Đạo diễn: .*?">(.+?)</li>',b).strip()				
			daodien=', '.join(i.strip() for i in re.findall('<a href=".+?">(.+?)</a>',v_daodien))			
			dienvien=', '.join(i.strip() for i in re.findall('<a href=".+?" class="tn-pcolor1">(.+?)</a>',b))
									
			id= 'hdonline-'+xsearch('-(\d+?)\.html',href)
			href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
			info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)													
			
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))				
			items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))			
		return items
		
	def eps(self,id,page):
		page=1;items=[]
		while True:		
			b=xread('http://hdonline.vn/episode/ajax?film=%s&episode=&page=%d&search='%(id,page))
			items+=[('http://hdonline.vn'+j[0],j[1]) for j in re.findall('href="(.+?)".*data-order="(.+?)"',b)]
			page+=1			
			
			pn=xsearch('<a class="active"[^<]+>\d+</a><[^<]+>(\d+)</a>',b)
			if not pn:break
			
		return items

class TVHay:				
	def __init__(self):
		self.home='http://tvhay.org/'
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://tvhay.org/'}

	def dataLink(self,b):
		def dec(s):
			w,i,s,e = s.split(',')
			a=b=c=0;d=[];f=[]
			while (True):
				if a<5:f.append(w[a])
				elif a<len(w):d.append(w[a])
				a+=1
				if b<5:f.append(i[b])
				elif b<len(i):d.append(i[b])
				b+=1
				if c<5:f.append(s[c])
				elif c<len(s):d.append(s[c])
				c+=1
				if len(w)+len(i)+len(s)+len(e)==len(d)+len(f)+len(e):break

			b=0;k=[];h=''.join(f);g=''.join(d)
			for a in range(0,len(d),2):
				m=1 if ord(h[b])%2 else -1
				k.append(chr(int(g[a:a+2],36)-m))
				b+=1
				if b>=len(f):b=0
			return ''.join(k)
	
		s=xsearch("('\w+?','\w+?','\w+?','\w+?')",b).replace("'","")
		s=xsearch("(\w{100,},\w+,\w+,\w+)",dec(s).replace("'",''))
		s=xsearch("(\w{100,},\w+,\w+,\w+)",dec(s).replace("'",''))
		return xsearch('link:"(.+?)"',dec(s)).replace('/&/g', '%26')
	
	def dec_(self, w, i, s, e):
		for s in range(0,len(w),2):
			i+=chr(int(w[s:s+2],36))
		return i
	
	def getDataOnline(self,code,linkData):
		try:exec(code);data=get_data(linkData)
		except:data=''
		return data
	
	def getData(self,linkData):
		def hexs(string):
			s = ''
			for i in range(1,len(string)+1):
				s += str(ord(string[i - 1]))
			s = hex(int(s)).lstrip('0x').rstrip('L')
			return s

		now=str(int(urllib2.time.time()))
		md5=urllib2.hashlib.md5(now+"$%$#$#%#%$#@#@#^%").hexdigest()
		cs=md5[:11]+now+md5[21:32]
		
		ss=cs[:27]+chr(21)*3
		num=0;numf=1.0;j=30
		for i in range(1,j+1):
				num = j + ord(ss[i - 1]) * i
				numf = numf * num
		i="%.f"%numf
		try:j=str(int(round(float(i[:15]+','+i[15:]))))
		except:
			try:j=str(int(round(float(i[:15]+'.'+i[15:]))))
			except:j=''
		string=re.sub('\.\d+','.%s'%j[1:15],str(numf).upper())
		
		s=''
		for i in range(1,len(string)+1):
			s+=hexs(string[i-1:i+2])
		string=s

		s=''
		for i in range(20,len(string)-16,2):
			s = s + string[i - 1]
		sc=s.upper()
		data='link=%s&cs=%s&sc=%s'%(linkData,cs,sc)
		return data	
	
	def googleLink(self,linkData,method=0):
		b=key='';loop=0
		if not method:
			key=xread('http://tvhay.org/tvhayplayer/clientfix.js')
			try:key=eval(xsearch('var \w+=(\[".+?"\]);',key))[23]
			except:key=''
			if not key:return ''
		
		while linkData and not b and loop < 3:
			if method==0:
				now=str(int(urllib2.time.time()))
				md5=urllib2.hashlib.md5(now+key).hexdigest()
				cs=md5[:11]+now+md5[21:32]
				data='link=%s&cs=%s'%(linkData,cs)
			elif method==1:data=self.getData(linkData)
			else:
				code=xread('http://textuploader.com/d5217/raw')
				data=self.getDataOnline(code,linkData)

			b=xread('http://tvhay.org/tvhayplayer/plugins/gkpluginsphp.php',self.hd,data)
			if not b:
				if loop:mess('Retry ... %d'%(loop+1))
				loop+=1;xbmc.sleep(3000)
		
		try:j=json.loads(b).get('link','')
		except:j=''
		if isinstance(j, unicode):link=j
		else:link=googleItems(j)
		return link
		
	def additems(self,url):				
		b=xread(url);items=[]
		for s in re.findall('(<div class="inner">.+?</li>)',b,re.DOTALL):
			title=xsearch('title="(.+?)"><span',s)
			titleVn=xsearch('Xem phim </span>(.+?)</a>',s)
			titleEn=xsearch('<div class="name2">\s*(.+?)</div>',s).strip()			
			year=xsearch('<div class="year">\s*(.+?)</div>',s).strip()
			label=xsearch('<div class="status">\s*(.+?)</div>',s).strip()
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)						
			href=xsearch('href="(.+?)"',s);img=xsearch('src=".+?url=(.+?)"',s)
			
			if not img:
				s=[i[1] for i in items if i[0]==href]
				if s:img=s[0]
			
			if href:items.append((title,href,img,False))
			
		last=xsearch('<a class="last" href="(.+?)">',b)		
		if last:
			pages=xsearch('/(\d+)/',last)

			href=xsearch('rel="next" href="(.+?)">',b)			
			page=xsearch('/(\d+)/',href)
			title='[COLOR lime]Trang tiếp theo: %s/%s[/COLOR]'%(page,pages)
			items.append((title,href,'image',True))

		return items
		
	def getLink(self,url):
		if url.startswith('http:'):
			if 'http://tvhay.org/xem-phim' not in url:
				url=xsearch('href="([^<]+?)" class="btn-watch"',xread(url))
		b=xreadc(url)
		self.hd['Cookie']=b.split('xshare')[1]
		linkData=self.dataLink(b)#;xbmc.log(linkData)
		link='';method=0
		while not link and method < 3:
			link=self.googleLink(linkData,method)
			method+=1
		return link		
						
class BiluTV:		
	def __init__(self):
		self.home='http://bilutv.com/'
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36'}
		
	def additems(self,url,page=0):		
		body=xread(url);items=[]
		
		cl='film-item '
		for s in re.findall('(<li class="%s.+?</li>)'%cl,body,re.DOTALL):
			href=self.home+xsearch('href="/(.+?)"',s)
			img=xsearch('original="(.+?)"',s)
			titleVn=xsearch('<p class="name">(.+?)</p>',s)
			titleEn=xsearch('<p class="real-name">(.+?)</p>',s)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			#quality=xsearch('<span class="label-quality">(.+?)</span>',s)
			label=xsearch('<label class="current-status">(.+?)</label>',s)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
												
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False

			#if 'Thuyết Minh' in label:title='[COLOR blue]TM[/COLOR] '+title
		
			if page:
				id= 'bilutv-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:							
			pn=re.search('<a href="/[^<]+?" >(\d+)</a></li><li><a href="/([^<]+?)" class="navigation next" rel="next">',body)
			if pn:
				href=self.home+pn.group(2);pages=pn.group(1)
				title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%pages
				items.append((title,href,'image',True))
			else:
				pn=re.search('<a href="[^<]+?" >(\d+)</a></li><li><a href="([^<]+?)" class="navigation next" rel="next">',body)
				if pn:
					href=url.split('?')[0]+pn.group(2);pages=pn.group(1)
					title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%pages
					items.append((title,href,'image',True))
											
		return items

	def eps(self,url):	
		if '/xem-phim/' not in url:
			body=make_request(url)
			fanart=xsearch('<img alt=".*?" src="(.+?)"',body)
			url=xsearch('<a href="(.*?/xem-phim/.+?)">',body)
			if self.home not in url:url=self.home+url
		
		body = xread(url)
		server=xsearch('(<ul class="choose-server">.+?/ul>)',body,1,re.DOTALL)		
		
		if server and re.search('class="list-episode"',body):		
			for href,title in re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server):
				if re.search('Thuyet Minh',no_accent(title)):
					body = xread(self.home+href)
					s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)					
					return re.findall('href="(.+?)">(.+?)</a>',s)
		elif server:		
			return re.findall('<a href="/(.+?)".*>([^<]+?)</a>',server)			
		
		s=xsearch('(<ul class="list-episode".+?/ul>)',body,1,re.S)
		items=re.findall('href="(.+?)">(.+?)</a>',s)
		return items		
		
	def getLink(self,url):
		if '/xem-phim/' not in url:
			url=xsearch('<a class="btn-see btn btn-danger" href="/(.+?)"',xread(url))
			if self.home not in url:url=self.home+url
		
		b=xread(url)
		if "/cdn-cgi/l/chk_jschl" in b:mess('DDoS protection by CloudFlare','bilutv.com');return
		elif 'Vì lý do bản quyền' in b:mess(u'Vì lý do bản quyền! BiluTV không cập nhật phim này nữa');return
		
		link=''
		try:
			keyAES='bilutv.com4590481877'
			L=re.findall("decodeLink\('(.+?)', *(\d+?)\)[^}]+?label: *'(.+?)'",b,re.S)
			if L:L=[(urllib.unquote(gibberishAES(i, keyAES+j)),resolu(l)) for i,j,l in L]
			else:
				j=json.loads(xsearch('playerSetting[^{]+({.+?});',b))
				modelId=j.get('modelId','')
				def abc(i):return urllib.unquote(gibberishAES(i.get('file',''), keyAES+modelId))
				L=[(abc(i),resolu(i.get('label',''))) for i in j.get('sources')]
			L=sorted(L, key=lambda k: int(k[1]),reverse=True)
			for href,label in L:
				link=test_link(href)
				if link:break
		except:pass
		
		return link
		
class PhimBatHu:
	def __init__(self):
		self.home='http://phimbathu.com'
		
	def additems(self,url,page=0):
		b=xread(url);items=[]

		s=xsearch('(id="content".+?class="right-content")',b,1,re.DOTALL)
		for i in re.findall('(<li class="item.+?/li>)',s,re.DOTALL):
			titleVn=xsearch('title="(.+?)"',i)
			titleEn=xsearch('class="name-real">\s*<span>(.+?)</span>',i)
			if not titleEn:
				year=xsearch('( \(\d{4}\))',titleVn)
				if not year:year=xsearch('( \d{4})',titleVn)
				titleVn=titleVn.replace(year,'')
			else:
				year=xsearch('( \(\d{4}\))',titleEn)							
				if not year:year=xsearch('( \d{4})',titleEn)
				titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			label=xsearch('"label">(.+?)<',i)
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			#if re.search('.huyết .inh',i):title='[COLOR blue]TM[/COLOR] '+title
			href=xsearch('href="(.+?)"',i)
			if '//' not in href:href='http://phimbathu.com'+href
			img=xsearch('src="(.+?)"',i,result=xsearch('data-original="(.+?)"',i))
							
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False

			
			if page:
				id= 'phimbathu-'+xsearch('-(\d+?)\.html',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:
			pn=xsearch('<a href="([^<]+?)" class="navigation next"',s)
			if pn:
				pages=xsearch('>(\d+?)</a></li><li><a href="[^<]+?" class="navigation next"',s)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,'http://phimbathu.com'+pn,'image',True))
			
		return items
		
	def getLink(self,url):		
		def getLink2(s,key):#chonserver values="Thuyết minh|VietSub|Không"
			try:j=json.loads(xsearch('"sources":(\[[^\]]+?\])',s))
			except:j={}
			for i in j:
				try:i['file']=urllib.unquote(gibberishAES(i.get('file',''),key))
				except:pass
			link=googleItems(j,'file','label')
			return link	
	
		if '/xem-phim/' not in url:
			url='http://phimbathu.com'+xsearch('"btn-see btn btn-info adspruce-streamlink" href="(.+?)"',xread(url))
		
		b=xread(url)
		key="phimbathu.com4590481877"+xsearch("'film_id':'(.+?)'",b)				
		
		servers=re.findall('(<a.+?/a>)',xsearch('<ul class="choose-server">(.+?)</ul>',b,1,re.S))		
		for s in servers:
			link=getLink2(xread(self.home+xsearch('href="(.+?)"',s)),key)
			if link:break
						
		if not link:
			s=xsearch('<ul class="server-backup"(.+?)</ul>',b,1,re.S)
			for s in re.findall('link="([^"]+?)"',s):
				href=self.home+urllib.unquote(gibberishAES(s,key))			
				b=xread(href)
				try:link=googleItems(json.loads(b),'file','label')
				except:pass
				if link:break
			
		return link		
		
class VietSubHD:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		#self.urlhome='http://hdsieunhanh.com/'		

	def additems(self,url,page=0):
		b=xread(url);items=[]
		if '/videos' in url:p='(<span class="video.+?/a>)'
		else:p='(<a class="poster".+?/div>)'

		for s in re.findall(p,b,re.S):
			title=xsearch('title="(.+?)"',s)
			titleEn=xsearch('</a> <dfn>(.+?)</dfn>',s)
			titleVn=title.replace(' - '+titleEn,'')
			year=xsearch('</dfn> <dfn>(.+?)</dfn>',s)			
			label=xsearch('<span class="status">(.+?)</span>',s)			
			
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)			

			href=xsearch('href="(.+?)"',s)
			img=xsearch('url=([^<]+jpg)',s)
			img=img.replace('w35-h35','w180-h240').replace('Poster.','')
			if re.search('Tap|Full',no_accent(label)):
				isFolder=True
			else:isFolder=False
		
			if page:
				id= 'vietsubhd-'+xsearch('-(\d+?)\/',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,[]))
			else:items.append((title,href,img,isFolder))
		
		if not page:			
			pn=xsearch('class="current".+?<a href="([^"]+?)"[^<]*?>\d+<',b)
			if pn:
				pages=xsearch('-(\d+)\.html" title="Trang cuối">',b)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,pn,'image',True))
			
		return items

	def getLink(self,url):
		href='http://www.vietsubhd.com/ajaxload'
		s=xread(href,data='NextEpisode=1&%s'%url)
		#link=xsearch('link:"(.+?)"',self.decode(s))
		link=xsearch('link:"(.+?)"',s)
		b=xread('http://www.vietsubhd.com/gkphp/plugins/gkpluginsphp.php',data='link=%s'%link)
		try:j=json.loads(b)
		except:j={}
		if j.get('link') and isinstance(j.get('link'),unicode):link=j.get('link')
		elif j.get('link') and isinstance(j.get('link'),list):link=googleItems(j.get('link'))
		elif j.get('list') and isinstance(j.get('list'),list):
			m=[]
			try:
				for n in j.get('list'):
					for k in n.get('link'):m.append(k)
			except:pass
			link=googleItems(m)
		else:link=''
		return link		
		

class HDSieuNhanh:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		self.urlhome='http://hdsieunhanh.com/'		

	def eps(self,url):
		content=xread(url)
		s=xsearch('(<ul class="list_episode".+?/ul>)',content,1,re.DOTALL)
		return re.findall('href="(.+?)">(.+?)</a>',s)
		
	def additems(self,url,page=0):
		content=xread(url);items=[]		
		for s in [i for i in content.split('<div class="block-base movie">') if 'data-id' in i]:
			title=xsearch('alt="(.+?)"',s)
			titleEn=xsearch('class="film-name"><h2>(.+?)</h2>',s)
			titleVn=xsearch('</h2>(.+?)</a>',s).strip()
			href=xsearch('href="(.+?)"',s)
			#if 'html' not in href:href=self.urlhome+href
			img=xsearch('src="(.+?)"',s).replace('amp;','')
			rate=xsearch('"rate">([^<]+?)</span>',s)
			if rate:title='%s [COLOR green]%s[/COLOR]'%(title,rate)
			eps=' '.join(re.sub('<[^<]+?>','',xsearch('(<span class="label-range">.+?<strong>\d+?</strong>)',s)).split())
			if '"tag bitrate1 "' in s:title='%s [COLOR lime]CAM[/COLOR]'%title
			elif '"tag bitrate0 "' in s:title='%s [COLOR lime]HD[/COLOR]'%title
			if eps:title='%s [COLOR gold](%s)[/COLOR]'%(title,eps);isFolder=True
			else:isFolder=False
		
		
			if page:
				id= 'hdsieunhanh-'+xsearch('-(\d+?)\.html',href);year=''
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year)
						
				items.append(('%03d'%(page),titleVn,'[]','[]',titleEn,year,info))
			else:items.append((title,href,img,isFolder))
		
		if not page:				
			pn=xsearch('<a href="([^"]+?)">Sau</a>',content)
			if pn:
				pn=self.urlhome+pn.replace('amp;','')
				pages=xsearch('=(\d+)">Cuối</a></li></ul>',content)
				title='[COLOR lime]Trang tiếp theo: .../%s[/COLOR]'%pages
				items.append((title,pn,'image',True))
		
		return items
		
	def getLink(self,url):
		tap=xsearch('-Tap-(\d+)-',url)
		if tap:tap='_'+tap
		hd=self.hd;hd['Referer']=self.urlhome
		url='http://hdsieunhanh.com/getsource/%s'%(xsearch('-(\w+)\.html',url)+tap)
		#print url,hd
		try:j=json.loads(xread(url,hd)).get('sources',[])
		except:j=[]
		items=ls([(i.get('file'),rsl(i.get('label'))) for i in j])
		return items		
		
class hdviet:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,body,mode):
		items=[]
	
		pattern='<li class="mov-item".+?href="(.+?)".+?src="(.+?)".+?title="Phim (.+?)".+?<span(.+?) data-id="(.+?)">'	
		data=re.findall(pattern,body,re.DOTALL);listitems=list()
		for href,img,title,detail,id_film in data:
			epi=xsearch('"labelchap2">(\d{1,3})</span>',detail);title=unescape(title)
			res=xsearch('id="fillprofile" class="icon-(.+?)11">',detail)
			res='[COLOR gold]SD[/COLOR]' if 'SD' in res else '[COLOR gold]HD[/COLOR]%s'%res
			phim18=xsearch('class="children11".+?>(.+?)</label></span>',detail)
			TM=xsearch('id="fillaudio" class="icon-(.+?)">',detail)
			TM='%s[COLOR green]%s[/COLOR][COLOR red]%s[/COLOR]'%(res,TM,phim18)
			plot=xsearch('<span class="cot1">(.+?)</span>',detail)
			year=xsearch('<span class="chil-date".+?>(.*?)</label></span>',detail)
			act=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dien-vien/.+?">(.+?)</a>',detail))
			drt=', '.join(s for s in re.findall('<a href="http://movies.hdviet.com/dao-dien/.+?">(.+?)</a>',detail))
			IMDb=xsearch('<span class="fl-left">.+?<span>(.+?)</span>',detail)
			upl=xsearch('<span class="fl-right">.+?<span>(.+?)</span>',detail)

			if '(' in title and ')' in title:title=title.replace('(','[B]').replace(')','[/B]')
			if IMDb:title+=color['imdb']+' IMDb: '+IMDb+'[/COLOR]'			
			
			href='hdviet.com|'+str(id_film)
			
			#if 'moicapnhat' in mode:
				#title+='[B]'+quocgia+'[/B] '
				#title+=color['theloai']+theloai+'[/COLOR]'

			
			isFolder=True
			v_mode=''
			titleVn=title
			titleEn=title
			if epi:
				title = '(' + epi + ') ' + title
				v_mode='episodes';
			else:v_mode='stream';isFolder=False
					
			items.append((title,href,'%s&query=%s'%(v_mode,titleVn+'[]'+titleEn+'[]'+str(year)),img,isFolder))					
			
		return items
		
	def getResolvedUrl(self,id_film,loop=0):#Phim le/phim chieu/ke doi dau thien ac		
		data=json_rw('hdviet.cookie')
		token = data.get('access_token')
		#token = '22bb07a59d184383a3c0cd5e3db671fc'
		#id_film=id_film.replace('_e','&ep=')
		direct_link='https://api-v2.hdviet.com/movie/play?accesstokenkey=%s&movieid=%s'%(token,id_film)		
				
		result=xread(direct_link)
		try:links=json.loads(result)["r"]
		except:links=dict()
		
		#try:print json.dumps(links,indent=2,ensure_ascii=True)
		#except:pass			
		
		link=links.get('LinkPlay')
		#if not link:return '',''
		#elif '0000000000000000000000' in link:
			#data=login_hdviet();links=getlinkhdviet(data.get('access_token'),id_film);link=links.get('LinkPlay')	
		
		if link:
			#max_resolution='_1920_' if myaddon.getSetting('hdvietresolution')=='1080' else '_1280_'
			max_resolution='_1920_'
			resolutions=['_1920_','_1885_','_1876_','_1866_','_1792_','_1280_','_1024_','_800_','_640_','_480_']
			if '_e' in id_film:link=re.sub('%s_e\d{1,3}_'%id_film.split('_')[0],'%s_'%id_film,link)
			
			r=''.join([s for s in resolutions if s in link]);response=''
			if r:
				href=link[:link.rfind(r)]+link[link.rfind(r):].replace(r,'%s')
				for i in resolutions:
					if i>max_resolution:continue
					response=make_request(href%i)
					if len(response)>0:link=href%i;break
			else:
				href=link.replace('playlist.m3u8','playlist_h.m3u8')
				response=make_request(href)
				if not response or '#EXT' not in response:
					for s in range(1,6):
						#print re.sub('http://n0\d.vn-hd.com','http://n0%d.vn-hd.com'%s,href)
						if 'http://n0%d'%s in href:continue
						elif re.search('http://n0\d.vn-hd.com',href):
							response=make_request(re.sub('http://n0\d.vn-hd.com','http://n0%d.vn-hd.com'%s,href))
						if response and  '#EXT' in response:break
				if not response:response=make_request(link)
			
			if response and '#EXT' in response:
				items=re.findall('RESOLUTION=(\d+?)x.*\s(.+m3u8)',response)
				if items:
					res=0;hr=''
					for r,h in items:
						#print r,h
						if int(r)>res:res=int(r);hr=h
					if hr and 'http://' in hr:link=hr
					else:link=os.path.dirname(link)+'/'+hr
				else:
					items=re.findall('(.+m3u8)',response)
					if items and 'http://' in items[0]:link=items[len(items)-1]#;print items[0]
					elif items:link=os.path.dirname(link)+'/'+items[0]
				
			else:link=''
		if not link:return '',''
		audio=links.get('AudioExt',list());audioindex=-1;linksub=''
		if not audio:pass
		elif len(audio)>1:
			#audio_choice=myaddon.getSetting('hdvietaudio')
			audio_choice='Hỏi khi xem-'
			if audio_choice=='Hỏi khi xem':
				title=u'[COLOR green]Chọn Audio[/COLOR]';line1= u'[COLOR yellow]Vui lòng chọn Audio[/COLOR]'
				audioindex=notify_yesno(title,line1,'',audio[0].get("Label",'0'),audio[1].get("Label",'1'))
			else:audioindex=0 if u2s(audio[0].get("Label")) in audio_choice else 1
			if 'Thuyết' not in u2s(audio[audioindex].get("Label")):linksub='yes'#bật cờ download sub
			try:link=link+'?audioindex=%d'%(int(audio[audioindex].get("Index",'0'))-1)
			except:pass
		elif u2s(audio[0].get("Label"))=='Thuyết Minh':audioindex=0
		if audioindex<0 or linksub:
			for source in ['Subtitle','SubtitleExt','SubtitleExtSe']:
				try:linksub=links[source]['VIE']['Source']
				except:linksub=''
				if linksub:break
		#print 'getResolvedUrl: %s - %s'%(link,linksub)
		return link,linksub					

class megabox:		
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,body,mode,page):
		items=[]
		
		for content in re.findall('<div class="item">(.+?)</div><!--',body,re.S):
			item=re.search('src="(.+?)">\s*.*<span class="features">\s*</span>\s*</a>\s*<div class="meta">\s*<h3 class="H3title">\s*<a href="(.+?)">(.+?)</a>',content)
			if item:
				#title=item.group(3)
				href=item.group(2)
				img=item.group(1)							
				
				thoiluong = xsearch('Thời lượng:</strong>(.+?)</li>',content).strip()
				IMDb = xsearch('<span class=\'rate\'>(.+?)</span>',content).strip()
				title=xsearch('<h3 class=\'H3title\'>(.+?)</h3>',content).strip()
				title=vnu(title)				
				id=xsearch('-(\d+?)\.html',href)
				if id == '15740':year='1978'
				else:year = xsearch('Năm phát hành:.*(\d{4})</li>',content).strip()
				if year in title:title=title.replace(year,'').strip()
				quocgia=xsearch('Quốc gia:</strong> (.+?)</li>',content).strip()
				daodien=xsearch('Đạo diễn:</strong> (.+?)</li>',content).strip()
				dienvien=xsearch('Diễn viên:</strong> (.+?)</li>',content).strip()					
			
				theloai=xsearch('Thể loại:</strong> (.+?)</li>',content).strip()
				theloai=theloai.replace('Ma k','K').replace('Khoa học v','V').replace('Sử thi','Lịch sử')
				
				desc=xsearch('<div class=\'des\'>(.+?)</div>',content)
				
				try:					
					titleVn = title.split(" (")[0]
					titleEn = title.split(" (")[1].replace(')','')
					#title = titleVn + ' - ' + titleEn												
				except:titleVn=title;titleEn=''

				eps = xsearch('class=.esp.><i>(.+?)</span>',content).replace('</i>','')					

				id= 'megabox-'+id
				href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)						
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))											
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))											
		return items		

	def getLink2(self,url):	
		url='/'.join((os.path.dirname(url),urllib.quote(os.path.basename(url))))
		body=make_request(url,resp='o',maxr=5);link=xsearch("changeStreamUrl\('(.+?)'\)",body.body)
		if not link:
			link = xsearch("\'(https://www.youtube.com/watch\?v=.+?)\'",body.body)
			link = link.replace('https://www.youtube.com/watch?v=', 'plugin://plugin.video.youtube/?action=play_video&videoid=')
		else:
			hd['Cookie']=body.cookiestring;href='http://phim.megabox.vn/content/get_link_video_lab'
			maxspeedlink=make_post(href,{'Referer':url},data={"link":"%s"%link},resp='j')
			if maxspeedlink.get('link'):
				link=maxspeedlink.get('link')+'|'+urllib.urlencode(hd)
			 
		return link		
		
	def getLink(self,url):		
		url='/'.join((os.path.dirname(url),urllib.quote(os.path.basename(url))))
		content = make_request(url)
		links = re.compile('var iosUrl = "(.+?)";').findall(content)
		  
		link=''
		if len(links) > 0:
			link = links[0]
		if 'youtube' in link:
			link = url.replace('https://www.youtube.com/watch?v=', 'plugin://plugin.video.youtube/?action=play_video&videoid=')
		else:
			link = link.replace('media21.megabox.vn', '113.164.28.47')
			link = link.replace('media22.megabox.vn', '113.164.28.48')		
			link = link+'|'+urllib.urlencode(hd)
		return link
		
class phimnhanh:				
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}
		
	def additems(self,body,mode,page):
		items=[]

		hrefs=[]
		for  s in re.findall('(<li  class="serial">.+?</li>)',body,re.DOTALL):
			href=xsearch('href="(.+?)"',s)
			if href not in hrefs:hrefs.append(href)
			else:continue
			#title=xsearch('title="(.+?)"',s)
			titleVn=xsearch('<span class="title display">(.+?)</span>',s)
			titleEn=xsearch('<span class="title real">(.+?) \(',s)
			year=xsearch('<span class="title real">.+? \((.+?)\)</span>',s)
			img=xsearch('data-original="(.+?)"',s)
			label=xsearch('<span class="m-label q">(.+?)</span>',s)
			lang=xsearch('<span class="m-label lang">(.+?)</span>',s)
			IMDb=xsearch('<span class="m-label imdb"><span class="rate">(.+?)</span>',s)
			ep=xsearch('<span class="m-label ep">(.+?)</span>',s)
			if 'tập' in ep:eps=ep;thoiluong=''
			else:thoiluong=ep;eps=''
			
			if titleEn:title = titleVn + ' (' + titleEn + ')'
			else:title = titleVn
			if year in title:title=title.replace(year,'').strip()
			
			b=xread(href)		

			v_theloai=xsearch('<p>Thể loại:(.+?)</p>',b)
			theloai=', '.join(i.replace('Kinh Dị - Ma','Kinh Dị').replace('Tâm Lý - Tình Cảm','Tâm Lý, Tình Cảm') for i in re.findall('<a href=".+?" title="(.+?)">',v_theloai))						
			
			v_quocgia=xsearch('<p>Quốc gia:(.+?)</p>',b)
			quocgia=', '.join(i.replace('Mỹ - Châu Âu','Âu-Mỹ') for i in re.findall('<a href=".+?" title="(.+?)">',v_quocgia))
			
			v_daodien=xsearch('<p>Đạo diễn:(.+?)</p>',b)
			daodien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_daodien))
			v_dienvien=xsearch('<p>Diễn viên:(.+?)</p>',b)
			dienvien=', '.join(i for i in re.findall('<a href=".+?" title="(.+?)">',v_dienvien))		
												
			desc=''#xsearch('<p>(.+?)<br></p>',b,1,re.DOTALL)

			
			id= 'phimnhanh-'+xsearch("javascript:download\('(.+?)'",b)
			href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
			info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)											
												
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
			items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
						
		return items	
			
		np=xsearch('<a href="([^>]+?)" rel="next">',body)
		if np:
			np=np.replace('amp;','');pn=xsearch('page=(\d+?)\Z',np)
			ps=xsearch('<a href="[^>]+?">(\d+?)</a></li> <li><a href="[^>]+?" rel="next">',body)
			t=color['trangtiep']+' Trang tiep theo...trang %s/%s[/COLOR]'%(pn,ps)
			#addir_info(t,np,ico,'',mode,page+1,query,True)
			
	def getLink(self,url):					
		
		a=make_request(url.replace('/phim/','/xem-phim/'))
		link=xsearch('playlist: "(.+?)"',a);a=make_request(link)
		for s in re.findall('(label="\d+p")',a):a=re.sub(s,'label="'+xsearch('label="(\d+)p"',s)+'"',a)
		a=a.replace('hd1080','1080').replace('hd720','720').replace('large','640').replace('medium','480')
		items=re.findall('file[^"]+"(.+?)"[^"]+"(\d+)"',a)
		items=sorted(items, key=lambda k: int(k[1]),reverse=True)		
		if items:
			link=''
			for href,label in items:
				response=make_request(href.replace('amp;',''),resp='o')
				if response and response.status==302:
					href=response.headers.get('location')
					if make_request(href,resp='s')==200:link=href;break
				if not link:xbmc.sleep(1000)
		else:
			link=xsearch('file="(.+?)"',a).replace('amp;','')
			if link and '.youtube.com' in link:
				link = link.replace('https://www.youtube.com/watch?v=', 'plugin://plugin.video.youtube/?action=play_video&videoid=')
		
		return link

		
class phimmoi:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.phimmoi.net'}

	def additems(self,body,mode,page):
		items=[]
		
		for s in re.findall('(<li class="movie-item">.+?</li>)',body,re.DOTALL):
			#title=xsearch('title="(.+?)"',s)
			titleVn=xsearch('<span class="movie-title-1">(.+?)</span>',s)
			titleEn=xsearch('<span class="movie-title-2">(.+?)</span>',s)
			if '(' in titleVn and ')' in titleVn:titleVn=titleVn.replace(' (', ' - ').replace(')', '')			
			if '(' in titleEn and ')' in titleEn:titleEn=titleEn.replace(' (', ' - ').replace(')', '')
			#duration=xsearch('>(\d{1,3}.?phút)',s)
			#label=xsearch('"ribbon">(.+?)</span>',s)
			href=xsearch('href="(.+?)"',s)
			if 'phimmoi.net' not in href:href='http://www.phimmoi.net/'+href
			img=xsearch('url=(.+?)%',s)
			
			b=xread(href)
			thoiluong = xsearch('Thời lượng:</dt><dd class="movie-dd">(.+?)</dd>',b)
			IMDb = xsearch('<dd class="movie-dd imdb">(.+?)</dd>',b)			
			quocgia=', '.join(i for i in re.findall('<a class="country" href=".+?" title=".+?">(.+?)</a>',b))
														
			theloai = ', '.join(i for i in re.findall('<a class="category" href=".+?" title="(.+?)">',b,re.S) if 'lẻ' not in i and 'bộ' not in i)#Phim bộ Hàn 
			theloai=theloai.replace('Phim Bí ẩn-Siêu nhiên','Phim Bí ẩn').replace('Phim hồi hộp-Gây cấn','Phim hồi hộp')
			theloai=theloai.replace('Phim tình cảm-Lãng mạn','Phim tình cảm').replace('Phim ','')
						
			desc=xsearch('id="film-content"><p>(.+?)\s*</p>',b,1,re.DOTALL)#<br><br>
			desc=re.sub('<(.+?)>','',desc)

			if 'Năm:</dt><dd class="movie-dd">' in b:
				year = xsearch('Năm:</dt><dd class="movie-dd">.+?(\d{1,4})</a>',b,1,re.DOTALL)
			elif 'Ngày phát hành:</dt><dd class="movie-dd">' in b:
				year = xsearch('Ngày phát hành:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)
			else:
				year = xsearch('Ngày ra rạp:</dt><dd class="movie-dd">.+?/.+?/(.+?)</dd>',b,1,re.DOTALL)			
			
			if '(' in titleVn: titleVn=titleVn.replace('(','- ').replace(')','')
			if '(' in titleEn: titleEn=titleEn.replace('(','- ').replace(')','')
			title = titleVn + ' (' + titleEn + ')'
			if year in title:title=title.replace(year,'').strip()
			#title=title.replace('(phần 2)','- phần 2')
						
			eps=xsearch('Tập ?(\d{,4}/\d{,4}|\?/\d{,4}|\d{,4})',s)
			if not eps:
				epi=xsearch('class="eps">Trọn bộ ?(\d{1,4}) ?tập</div>',s)
				if epi:eps='%s/%s'%(epi,epi)
			else:epi=eps.split('/')[0]
			try:epi=int(epi)
			except:epi=0
			
			daodien=', '.join(i for i in re.findall('<a class="director" href=".+?" title="(.+?)">',b))
			dienvien=', '.join(i for i in re.findall('<span class="actor-name-a">(.+?)</span>',b))
			
			if xsearch('<dd class="movie-dd status">Trailer',b,0):continue						
			
			id= 'phimmoi-'+xsearch('-(\d+?)\/',href)
			href='{"label":"","url":'+json.dumps(href)+',"subtitle":""}'
			info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)
						
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))						
			items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))																
		return items
		
	def getLink(self,url):							
		url=url if '.html' in url else url+'xem-phim.html'
		
		b=xread(url,self.hd)
		if not b:b=xread(url,self.hd)
		alert=xsearch('<div class="alert-heading">(.+?)</div>',b)
		href=xsearch('src="([^<]*?episodeinfo.+?)"',b).replace('javascript','json')
		b=xread(href,self.hd)
		if not b:b=xread(href,self.hd)
		try:j=json.loads(b)
		except:j={}
		links=j.get('medias',[]);error=j.get('error','')
		if error:mess(error)
		elif alert:mess(alert)
		link=''
		if links:
			items=ls([(i.get('url'),rsl(i.get('resolution'))) for i in links])
			for href,label in items:
				link=xcheck(gibberishAES(href,'PhimMoi.Net://%s'%j.get('requestId')))
				if link:break
		return link
			
		
	def getLink2(self,url):					
		body=make_request(url if '.html' in url else url+'xem-phim.html')
		
		u=xsearch('src="([^<]*?episodeinfo.+?)"',body)
		if 'http://' not in u:u='http://www.phimmoi.net/'+u
		hd['Referer']=url
		b=make_request(u,hd)
		c=xsearch("_responseJson='(.+?)'",b)
		try:d=json.loads(c.replace('\\',''))
		except:d={}
		
		href='';height=width=0
		for i in d.get('medias',[]):
			if i.get('height',0)>height:height=i.get('height');href=i.get('url')
			if i.get('width',0)>width:width=i.get('width');href=i.get('url')
		if href:
			s=make_request(href,resp='o')
			if s and s.status==302:
				href=s.headers.get('location')		
		
		return href
		
		#server quoc te khac
		content=xsearch('<div class="list-server">(.+?)</div>',body,1,re.DOTALL).replace('\n','')
		for label,subcontent in re.findall('class="server-title">(.+?)</h3>(.+?)</ul>',content):
			for href,title in re.findall('href="(.+?)">(.+?)</a>',subcontent):
				addir_info('2-%s %s'%(label,title),urlhome+href,img,'',mode,page,'pm_play')

class Fcine:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','X-Requested-With':'XMLHttpRequest'}
		self.cookie=''

	def additems(self,url,page=0):
		b=xread(url,self.hd).replace('\\n','').replace('\\t','').replace('\\r','');items=[]
		try:j=json.loads(b)
		except:j={}
		s = j.get('rows','').encode('utf-8')
		
		S=re.findall('(<div class="esnList_item".+?/ul>)',s,re.S)
		if not S:S=re.findall('(<li.+?/li>)',s,re.S)
		for s in S:
			title=xsearch("title='(.+?)'",s,result=xsearch('title="(.+?)"',s)).replace('&#039;',"'")
			titleVn=xsearch('<div class="ipsTruncate ipsTruncate_line ipsType_blendLinks ipsType_light".+?>\s*(.+?)</div>',s)			
			titleEn=xsearch('<div class="ipsTruncate ipsTruncate_line" data-ipsTruncate.+?>\s*(.+?)</div>',s).replace('&#039;',"'")
			year=xsearch('( \(\d{4}\))',titleEn)							
			if not year:year=xsearch('( \d{4})',titleEn)
			titleEn=titleEn.replace(year,'')							
			year=year.replace(' (','').replace(')','').strip()
			if 'HDRip.png' in s:label='HDRip'
			elif 'Bluray.png' in s:label='Bluray'
			elif 'WEBrip.png' in s:label='WEBrip'
			elif 'WEB-DL.png' in s:label='WEB-DL'
			elif 'DVDrip.png' in s:label='DVDrip'
			else:label=''						
			title = '%s [B]%s[/B] %s [COLOR green]%s[/COLOR]'%(titleVn,year,titleEn,label)
			
			href=xsearch('href="(.+?)"',s)
			if not title or not href:continue
						
			img=xsearch('src="(.+?)"',s);eps=''
					
			if True:
				body=xread(href)
								
				thoiluong = xsearch('Độ dài:</strong> </span>\s*<span class=\'ipsDataItem_main\' style="padding-left: 10px;">(.+?)</span>',body)
				IMDb = ''
				
				quocgia=xsearch('Quốc gia:</strong> </span>\s*<span class=\'ipsDataItem_main\' style="padding-left: 10px;">(.+?)</span>',body)
				daodien=xsearch('Đạo diễn:</strong> </span>\s*<span class=\'ipsDataItem_main\' style="padding-left: 10px;">(.+?)</span>',body)
				dienvien=xsearch('Diễn viên:</strong> </span>\s*<span class=\'ipsDataItem_main\' style="padding-left: 10px;">(.+?)</span>',body)
				theloai=xsearch('Thể loại:</strong> </span>\s*<span class=\'ipsDataItem_main\' style="padding-left: 10px;">(.+?)</span>',body)
												
				desc=xsearch("Nội dung phim</div></div>\s*<div class='ipsPad_half' style='background:#CFCFCF;'>(.+?)<br>",body)
				log(desc)
				break
									
				id= 'fcine-'+xsearch('view/(\d+?)-',href)
				href='{"label":'+json.dumps(label)+',"url":'+json.dumps(href)+',"subtitle":""}'
				info=getInfo(id,href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)
				
				tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
				items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
			else:items.append((title,href,img,False))
		
		if not page:		
			pagination=j.get('pagination','').replace('&amp;','&').encode('utf-8')
			p=xsearch("data-page='(\d+)' data-ipsTooltip title='Next page'",pagination)
			if p:
				href=xsearch("href='([^']+?)' data-page='%s'"%p,pagination)
				title='[COLOR lime]Trang tiếp theo: %s[/COLOR]'%p
				if href:items.append((title,href+'&listResort=1','image',True))
			
		return items
		
	def getLink(self,url):
		b=xread(url+'?area=online',{'Cookie':self.cookie})
		items=[]
		for s in re.findall('(<ul class="ipsButton_split".+?/ul)',b,re.S):
			server=xsearch('<li.+?>(.+?)</li>',s)
			href=xsearch('href="(.+?)"',s).replace('&amp;','&')
			if not server or not href:continue
			default='ipsButton_important' in s
			items.append((server,href,default))
		
		if len(items)<2:pass
		elif len(items)>1:
			serverChoice=xselect("Chọn server bạn muốn xem phim này",[i[0] for i in items])
			if serverChoice>=0 and not items[serverChoice][2]:
				b=xread(items[serverChoice][1],{'Cookie':self.cookie})
		
		sub=xsearch('kind="captions" src="(.+?)"',b)
		s=xsearch('(<video.+?/video>)',b.replace('&amp;','&'),1,re.S)
		link=xcheck(ls(re.findall('src="(.+?)".+?data-res="(.+?)"',s)))
		return link,sub						

class vaphim:		
	def additems(self,body,mode,page,query):
		items=[]
		pattern='<a data=.+?src="(.+?)[\?|\"].+?<h3.+?><a href="(.+?)" rel=.+?>(.+?)</a></h3>'
		for img,href,title in re.findall(pattern,body,re.DOTALL):
			title=title.replace('</br>','<br />').replace('<br/>','<br />')
			b = xread(href);v_b=re.sub('<(.+?)>','',b.replace('<br />','[]'))		
		
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')			
			else:year = xsearch('Năm sản xuất:(.+?)\[\]',v_b).strip()
			try:
				titleVn=title.split(' <br /> ')[0].strip()
				titleEn=title.split(' <br /> ')[1].strip()										
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)					
			
			thoiluong = xsearch('Thời lượng:(.+?)\[\]',v_b).strip()
			IMDb = xsearch('Đánh giá:(.+?)/10.*',v_b).strip()
			
			quocgia=xsearch('Quốc gia:(.+?)\[\]',v_b).strip()			
			daodien=xsearch('Đạo diễn:(.+?)\[\]',v_b).strip()
			dienvien=xsearch('Diễn viên:(.+?)\[\]',v_b).strip()				
			dienvien = dienvien.replace('-trong-vai:-','')
			
			theloai=xsearch('Thể loại:(.+?)\[\]',v_b).strip()
			
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
			
			desc=vnu(xsearch('Nội dung:</span></strong></h2>\s*<p>(.+?)</p>',b))
					
			eps = ""
																													
			tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
			if tabs:								
				for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
					content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
					label=subtitle=url=''
					for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
						if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
						elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
							subtitle=href
						elif '/file/' in href:url=href;label=tab_label											
						elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
					if url:
						v_url='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'
						if v_href:v_href+=','+v_url
						else:v_href=v_url
					
					#break #chi lay tab dau tien
			else:
				pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
				label=subtitle=url=''
				for href, fn in re.findall(pattern,b):
					if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
					elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
						subtitle=href
					elif '/file/' in href:url=href;label=''											
					elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
				if url:v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'


			id= 'vaphim-'+xsearch('#tabs-(.+?)-',b)
			info=getInfo(id,v_href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)				
							
			if v_href:items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
											
		return items
	
class fsharefilm:		
	def additems(self,body,mode,page,query):
		items=[]
		for href in re.findall('<div class="movie col-xs-6 col-sm-4 col-md-3 col-lg-3">\s*<a class="wrap-movie-img" href="(.+?)">',body,re.S):						
			b = xread(href)
			if 'Phim Bộ' in xsearch('<ol class="breadcrumb">(.+?)</ol>',b,1,re.DOTALL):#query=='phim-le' and 
				continue
			
			title=xsearch('"name": "(.+?)",',b)
			title=title.replace(' &#8211; ','<br />')
			
			year = xsearch('(\(\d{1,4}-\d{1,4}\))',title)
			if not year: year = xsearch('(\(\d{4}\))',title)
			if not year: year = xsearch('(\d{4})',title)
			if year:
				title=title.replace(year,'').replace('()','')
				year = year.replace('(','').replace(')','')
			else:year = xsearch('<b>Năm Phát Hành:</b></p>\s*<p class="info">(.+?)</p>',b).strip()			
			
			try:
				titleVn=title.split('<br />')[0]
				titleEn=title.split('<br />')[1]
			except:titleVn=title;titleEn=''						
			titleVn=vnu(titleVn);titleEn=vnu(titleEn)
			
			img=xsearch('"url":"(.+?.jpg)"',b)
	
			thoiluong = ''#xsearch('Thời lượng:</strong> (.+?)</li>',b).strip()
			IMDb = xsearch('<b>IMDB:</b></p>\s*<p class="info">(.+?)/10</p>',b).strip()			
			quocgia=xsearch('<b>Quốc Gia:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			daodien=xsearch('<b>Đạo Diễn:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			dienvien=xsearch('<b>Diễn Viên:</b></p>\s*<p class="info">(.+?), </p>',b).strip()
			dienvien=dienvien.replace('-trong-vai:-','')
									
			v_theloai=xsearch('<b>Thể Loại:</b></p>\s*<p class="info">(.+?)</p>',b).strip()
			theloai=', '.join(i.replace('Phim','') for i in re.findall('<a href=".+?" rel="category tag">(.+?)</a>',v_theloai))
			
			desc=xsearch('<h2>\s*<p>Cốt Truyện</h2>(.+?)</p>',b)			
			
			eps = ""
			
			tabs=re.findall('#(tabs-.+?)" >(.+?)<',b);v_href=''
			if tabs:								
				for tab,tab_label in sorted(tabs,key=lambda k: k[1],reverse=False):#lay 1080					
					content=xsearch('<div id="%s">(.+?)</div>'%tab,b,1,re.DOTALL)					
					label=subtitle=url=''
					for href, fn in re.findall('href="(.+?)".*?>(.+?)</a>',content):#<a title="" href co truong hop nay
						if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
						elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
							subtitle=href
						elif '/file/' in href:url=href;label=tab_label											
						elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
					if url:
						v_url='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'
						if v_href:v_href+=','+v_url
						else:v_href=v_url
					
					#break #chi lay tab dau tien
			else:
				pattern='([\w|/|:|\.]+?fshare\.vn.+?|[\w|/|:|\.]+?subscene\.com.+?)[&|"|\'].+?>(.+?)</a>'
				label=subtitle=url=''
				for href, fn in re.findall(pattern,b):
					if ('/folder/' in href and 'phim-le' == query) or 'subscene.com' in href:continue#chua xu ly
					elif u2s(fn).lower() in ['phụ đề việt', 'sub việt']:
						subtitle=href
					elif '/file/' in href:url=href;label=''											
					elif '/folder/' in href and 'phim-bo' == query:url=href;label=tab_label
					
				if url:v_href='{"label":'+json.dumps(label)+',"url":'+json.dumps(url)+',"subtitle":'+json.dumps(subtitle)+'}'					

			id= 'fsharefilm-'+xsearch('#tabs-(.+?)-',b)
			info=getInfo(id,v_href,titleVn,titleEn,img,year,eps,quocgia,theloai,daodien,dienvien,thoiluong,IMDb,desc)				
													
			tag = '%s[]%s'%(fixString(daodien), fixString(dienvien))
			if v_href:items.append(('%03d'%(page),titleVn,'%s[]%s'%(fixString(quocgia), fixString(theloai)),tag,titleEn,year,info))
		return items

class television:	
	def getLink(self,url):
		response = urlfetch.get(url)
		match = re.search(re.compile(r'iosUrl\s=\s\"(.*?)\"'), response.body)
		linklive = match.group(1)
		xbmc.log(linklive)
		cookie=response.cookiestring;
		headers = { 
					'User-Agent'		: 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0',
					'Cookie'			: cookie,
					'Referer'			: url,
					'X-Requested-With'	: 'XMLHttpRequest'					
				}
		data={'url':linklive,'type':'1'}
		response = urlfetch.post('http://hplus.com.vn/content/getlinkvideo/',data=data, headers=headers)
		if not response:
			return ''
		video_url = response.content
		xbmc.log(video_url)
		return video_url							
		
class hdvietnam:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Referer':'http://www.hdvietnam.com/forums/'}
		self.urlhome='http://www.hdvietnam.com/'
						
	def forums(self,url):
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		
		content=xread(url,self.hd).split('<div class="titleBar">')[-1]
		items=[]
		for s in [i for i in re.findall('(<li id="thread.+?/li>)',content,re.S) if 'class="sticky"' not in i]:
			id=xsearch('id="thread-(.+?)"',s)
			
			b=xsearch('<h3 class="title">(.+?)</h3>',s,1,re.DOTALL)
			
			href=self.urlhome+xsearch('<a href="(.+?)"',b)				
			title=xsearch('data-previewUrl=".*">(.+?)</a>',b)
			#img=xsearch('<img src="(.+?)"',content)
			items.append((id,cleans(title),href))
			
		pn=xsearch('<a href="(.+?)" class="text">Ti.+ &gt;</a>',content)
		if pn:
			pn=self.urlhome+pn
			items.append(('pageNext','[COLOR lime]Trang tiếp theo: %s[/COLOR]'%xsearch('/page-(\d+)',pn),pn))
		return items
		
	def threads(self,url):
		def cleans(s):return ' '.join(re.sub('&#\w+;|amp;|<','',s).split())#<[^<]+?>|\{[^\{]+\}|\[[^\[]+?\]|
		def srv(link):return [i for i in srvs if i in link]
		#srvs=['fshare.vn','4share.vn','tenlua.vn','subscene.com','phudeviet.org','youtube.com']
		srvs=['fshare.vn', 'docs.google.com']
		items=[]
		def getTitle(title,href,s):
			t=title
			if [i for i in srvs if i in title] or not title:
				title=xsearch('<b>Ðề: (.+?)</b>',s)
				if not title:
					title=' '.join(xsearch('<div style="text-align: center".+?>(\w[^<]+?)<',s).split())
			elif 'download' in title.strip().lower():
				title=xsearch('class="internalLink">([^<]+?)<',s[s.find(href)-500:])
				if not title:title=xsearch('<title>(.+?)</title>',content)
			if not title:title=t
			title=cleans(title)
			return title
		
		content=xread(url,self.hd)
		for s in re.findall('(<li id="post-.+?/li>)',content,re.S):
			img=xsearch('<img src="([^"]+?)" class="',s)
			if not img:img=xsearch('<img src="(.+?jpg)"',s)
			i=s
			while 'header-' in img and 'ogo' not in img:
				i=i[i.find(img)+10:]
				img=xsearch('<img src="(.+?jpg)"',i)
			
			i=re.findall('<a href="([^"]+?)" target="_blank"[^<]+?>(.+?)</a>',s)
			i= [(getTitle(title,href,s),href,img) for href,title in i if srv(href)]
			if i:items+=i
			else:items+=[('',i,img) for i in re.findall('(http[\w|:|/|\.|\?|=|&|-]+)',s.replace('amp;','')) if srv(i)]
			
		temp=[];list=[]
		for i in items:
			if i[1] not in temp:temp.append(i[1]);list.append(i)
		return list
			