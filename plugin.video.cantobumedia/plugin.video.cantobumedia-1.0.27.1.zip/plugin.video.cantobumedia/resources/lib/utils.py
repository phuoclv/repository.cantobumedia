# -*- coding: utf-8 -*-

import xbmc,xbmcplugin,xbmcgui,xbmcaddon,urllib,urllib2,re,os,unicodedata,base64, contextlib, zipfile
import urlfetch

import datetime,time

myaddon=xbmcaddon.Addon()
addonDataPath=xbmc.translatePath(myaddon.getAddonInfo('profile'))
iconpath=os.path.join(addonDataPath,'icon');datapath=os.path.join(addonDataPath,'data')
search_file=os.path.join(addonDataPath,"search.xml")
rows=100
tempfolder=xbmc.translatePath('special://temp')
addons_folder = xbmc.translatePath('special://home/addons')

try:
	myfolder=s2u(myaddon.getSetting('thumuccucbo'))
	if not os.path.exists(myfolder):myfolder=os.path.join(datapath,'myfolder')
except:myfolder=os.path.join(datapath,'myfolder')

icon={}
for item in ['fshare', 'fptplay', 'hdonline', 'vuahd', 'hdviet', 'hayhaytv', 'dangcaphd', 'megabox', 'phimmoi', 'phimnhanh', 'phimgiaitri', 'fsharefilm', 'vaphim', 'next', 'icon', 'id']:
	icon.setdefault(item,os.path.join(iconpath,'%s.png'%item))

danhmuc={'[]':'[]','hanh-dong':'Hành động','kinh-di':'Kinh dị','hai':'Hài','hoat-hinh':'Hoạt hình','vo-thuat':'Võ thuật','tam-ly':'Tâm lý','tinh-cam':'Tình cảm','kiem-hiep':'Kiếm hiệp','chien-tranh':'Chiến tranh','hinh-su':'Hình sự','vien-tuong':'Viễn tưởng','khoa-hoc':'Khoa học','tai-lieu':'Tài liệu','phieu-luu':'Phiêu lưu','gia-dinh':'Gia đình','am-nhac':'Âm nhạc','the-thao':'Thể thao','lich-su':'Lịch sử','han-quoc':'Hàn Quốc','thai-lan':'Thái Lan','my':'Mỹ','trung-quoc':'Trung Quốc','hong-kong':'Hồng Kông','an-do':'Ấn Độ','nhat-ban':'Nhật Bản','philippines':'Philippines','phap':'Pháp','au-my':'Âu-Mỹ','quoc-gia-khac':'Quốc Gia khác', 'bi-an':'Bí ẩn','than-thoai':'Thần thoại','kich-tinh':'Kịch tính','vien-tay':'Viễn tây','tv-show':'TV-Show', 'nga':'Nga', 'canada':'Canada', 'anh':'Anh','tay-ban-nha':'Tây Ban Nha','duc':'Đức','uc':'Úc','ireland':'Ireland','hungary':'Hungary','chau-au':'Châu Âu','chau-a':'Châu Á','dai-loan':'Đài Loan','co-trang':'Cổ Trang'}

media_ext=['aif','iff','m3u','m3u8','m4a','mid','mp3','mpa','ra','wav','wma','3g2','3gp','asf','asx','avi','flv','mov','mp4','mpg','mkv','m4v','rm','swf','vob','wmv','bin','cue','dmg','iso','mdf','toast','vcd','ts','flac','m2ts','dtshd','nrg']	

www={'hdonline':'HDOnline','megabox':'MegaBox','phimmoi':'PhimMoi','phimnhanh':'PhimNhanh','fsharefilm':'FshareFilm','vaphim':'VaPhim','tvhay':'TVHay','bilutv':'BiluTV','fcine':'Fcine','phimbathu':'PhimBatHu','vietsubhd':'VietSubHD','hdsieunhanh':'HDSieuNhanh','xuongphim':'XuongPhim','hdviet':'HDViet','pubvn':'pubvn.net','xemphimbox':'xemphimbox.com'}
color={'trangtiep':'[COLOR lime]','cat':'[COLOR green]','search':'[COLOR red]','phimbo':'[COLOR tomato]','phimle':'[COLOR yellow]','imdb':'[COLOR yellow]','namphathanh':'[COLOR yellow]','theloai':'[COLOR green]','quocgia':'[COLOR blue]'}

hd={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/600.1.4 Gecko/20100101 Firefox/41.0'}	

def xfetch(url, headers=None, data=None):
  	if headers is None:headers = {'User-agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0','Referer':'http://www.google.com'}
  	try:
  		if data:response = urlfetch.post(url, headers=headers, data=data)
  		else:response = urlfetch.get(url, headers=headers)
		return response
	except:pass			
		
x0x0x0x0='Y29kZQ=='

def alert(message,title="Cantobu Media"):
	xbmcgui.Dialog().ok(title,"",message)

def notify(message, title="", timeout=5000, image=None):
  	if image is None:
		home = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')).decode("utf-8")	
    	image = xbmc.translatePath(os.path.join(home, "icon.png"))
		
	if not title:title="[B]Cantobu Media[/B]"	
	xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", "%s", "%s")' % (title, message, timeout, image)).encode("utf-8"))
	
def encode2(key, clear):
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = (ord(clear[i]) + ord(key_c)) % 256
        enc.append(enc_c)
    return base64.urlsafe_b64encode(bytes(enc))

def decode2(key, enc):
    dec = []
    enc = base64.urlsafe_b64decode(enc)
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + enc[i] - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

def encode(key, clear):
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
        enc.append(enc_c)
    return base64.urlsafe_b64encode("".join(enc))
	
def decode(key, enc):
    dec = []
    enc = base64.urlsafe_b64decode(enc)
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
			
		
def log(s):xbmc.log(u2s(s))

def checkupdate(filename,hours=1,folder=datapath,xdict=dict()):
	filecheck=joinpath(folder,filename);timeformat='%Y%m%d%H'
	filetime=os.path.getmtime(filecheck) if os.path.isfile(filecheck) else 0
	last_update=datetime.datetime.fromtimestamp(filetime).strftime(timeformat)
	timenow=datetime.datetime.now().strftime(timeformat)
	return (int(timenow)-int(last_update))>hours	
				
def strVnEn(str1, str2):
	try:
		str = str1.lower()
		if str == '': return
		if type(str).__name__ == 'unicode': str = str.encode('utf-8')
		items = ["á","à","ả","ạ","ã","â","ấ","ầ","ẩ","ậ","ẫ","ă","ắ","ằ","ẳ","ặ","ẵ","đ","í","ì","ỉ","ị","ĩ","é","è","ẻ","ẹ","ẽ","ê","ế","ề","ể","ệ","ễ","ó","ò","ỏ","ọ","õ","ô","ố","ồ","ổ","ộ","ỗ","ơ","ớ","ờ","ở","ợ","ỡ","ú","ù","ủ","ụ","ũ","ư","ứ","ừ","ử","ự","ữ","ý","ỳ","ỷ","ỵ","ỹ"]
		for item in items:			
			if item in str :
				return str2, str1 + ' - ' + str2
		return str1, str2 + ' - ' + str1
	except: pass	
		
def fixString(string):
	try:		
		for a, b in {'&#39;':'','&amp;':'','&':'',':':'',' ':'-','+':'-'}.iteritems():
			string = string.strip().replace(a, b)
	except:string=''		
	return no_accent(string).lower()

def fixUrl2(domain,url):return domain+url if 'http:' not in url else url	

def fixUrl(domain,url):
	if url.startswith('http'):return url
	elif url.startswith('/'):return domain+url[1:]
	else:return domain+url

	
def test_link(url):
	try:o=urllib2.urlopen(url);link=o.geturl();o.close()
	except:link=''
	return link
			
			
def filetime(fn):#return hour
	fn=urllib2.os.path.join(addonDataPath,fn)
	t=urllib2.os.path.getmtime(fn) if urllib2.os.path.isfile(fn) else 0
	return int((urllib2.time.time()-t)/600)
	
def get_setting(name):return myaddon.getSetting(name)
def set_setting(name,value):myaddon.setSetting(name,value)
def mess(message='',title='',timeShown=5000):
	if not message:xbmc.executebuiltin("Dialog.Close(all, true)")
	else:
		title=': [COLOR blue]%s[/COLOR]'%title if title else ''
		s0='[COLOR green][B]Xshare[/B][/COLOR]'+title
		s1='[COLOR red]%s[/COLOR]'%message if '!' in message else u'[COLOR gold]%s[/COLOR]'%message
		xbmc.executebuiltin((u'XBMC.Notification(%s,%s,%s,%s)'%(s0,s1,timeShown,iconpath)).encode("utf-8"))

def mess_yesno(title='[COLOR green]Xshare[/COLOR]', line1='', line2='',no='No',yes='Yes'):
	dialog=xbmcgui.Dialog()#dialog.yesno(heading, line1[, line2, line3,nolabel,yeslabel])
	return dialog.yesno(title,line1,line2,nolabel=no,yeslabel=yes)

		
def xselect(label,choices):
	dialog = xbmcgui.Dialog()
	return dialog.select(label, choices)

def googleLinks(s):
	def rsl(s):
		s=s.upper()
		e=re.sub('\D','',s)
		arr=[('HDG',''),('HD','1080'),('SD','640'),('LARGE','640'),('MEDIUM','480'),
			('AUTO','640'),('org','240')]
		s=''.join(re.sub(i[0],i[1],s) for i in arr if i[0] in s)
		if not s and not e:s='0'
		return e+re.sub('\D','',s)

	if isinstance(s,basestring):
		items=re.findall('file\W+(\w.+?)["|\'| ].+?label\W+(\w.+?)["|\'| ]',s)#;xbmc.log(s)
		if not items:
			items=re.findall('label\W+(\w.+?)["|\'| ].+?src\W+(\w.+?)["|\'| ]',s)
			items=[(i[1],i[0]) for i in items]
	elif isinstance(s,list):items=s
	else:items=[]
	
	items=[(i[0].replace('\\/','/'),rsl(i[1])) for i in items]
	reverse=True if get_setting('resolut')=='Max' else False
	items=sorted(items, key=lambda k: int(k[1]),reverse=reverse)
	
	link=''
	for href,label in items:
		resp=xget(href)#;xbmc.log(href)
		if resp:link=href;break
	return link
	
def googleItems(j,link='link',label='label'):
	try:l=[(i.get(link),rsl(i.get(label))) for i in j]
	except:
		try:l=[(i.get(link),rsl(i.get('type'))) for i in j]
		except:
			try:l=[(i.get('file'),rsl(i.get('type'))) for i in j]
			except:l=j
	#elif isinstance(j,list):l=j
	link=''#;xbmc.log('111 '+str(l))
	try:
		l=ls(l)
		for href,label in l:
			href=href.replace('\\','').strip()
			resp=xget(href)#;xbmc.log(href)
			if resp:link=href;break
		if not link:link=l[0][0]
	except:pass
	return link

def googlevideo(s,label='label',src='file'):
	link=''
	items=re.findall('%s\W*(\w+?)\W.+?%s\W+(.+?)["|\| ]'%(label,src),s);xbmc.log(str(len(items)))
	for href,label in ls([(i[1].replace('\\/','/'),rsl(i[0])) for i in items]):
		resp=xget(href)#;xbmc.log(href)
		if resp:link=resp.geturl();break
	if not link:
		try:link=l[0][0]
		except:pass
	return link
	
def rsl(s):
	s=str(s).replace('HDG','').replace('HD','1080').replace('SD','640').replace('large','640').replace('medium','480')
	s=s.replace('Auto','640').replace('AUTO','640')
	result=xsearch('(\d+)',s)
	return result if result else '240'

def ls(l):
	l=sorted(l, key=lambda k: int(k[1]),reverse=True)
	return l

def namecolor(name,c=''):return '[COLOR %s]%s[/COLOR]'%(c,name) if c else urllib2.re.sub('\[[^\[]+?\]','',name)
def xrw(fn,s=''):
	fn=urllib2.os.path.join(addonDataPath,fn)
	try:
		if s:f=open(fn,'w');f.write(s);s=fn
		else:f=open(fn);s=f.read()
		f.close()
	except:s=''
	return s

def xread(url,headers={'User-Agent':'Mozilla/5.0'},data=None,timeout=30):
	req=urllib2.Request(url,data,headers)
	try:
		res=urllib2.urlopen(req, timeout=timeout)
		hd=dict(res.headers.items())
		cookie=hd.get('set-cookie','')
		encoding=hd.get('content-encoding','')
		if encoding=='gzip':
			import StringIO,gzip
			buf=StringIO.StringIO(res.read())
			f=gzip.GzipFile(fileobj=buf)
			b=f.read()
		else:b=res.read()
		res.close()
	except:b=''
	return b

def makerequest(file,body='',attr='r'):
	file=s2u(file)
	if attr=='r':
		try:f=open(file);body=f.read();f.close()
		except:body=''
	else:
		try:f=open(file,attr);f.write(body);f.close()
		except:mess(u'Lỗi ghi file: %s!'%s2u(os.path.basename(file)),'makerequest');body=''
	return body

def xreadc(url,c=''):
	cookie=urllib2.HTTPCookieProcessor()
	opener=urllib2.build_opener(cookie)
	urllib2.install_opener(opener)
	opener.addheaders=[('User_Agent','Mozilla/5.0')]
	if c:opener.addheaders=[('Cookie',c)]
	try:
		o=opener.open(url);b=o.read();o.close()
		b+='xshare%s'%';'.join('%s=%s'%(i.name,i.value) for i in cookie.cookiejar)
	except:b=''
	return b	
	
def xget(url,hd={'User-Agent':'Mozilla/5.0'},data=None,timeout=30):#d=res.info().dict
	try:res=urllib2.urlopen(urllib2.Request(url,data,hd),timeout=timeout)
	except:res=None
	return res#res.info().get('content-length')
	
def xget2(url,data=None,timeout=30):#b.getcode();b.headers.get('Set-Cookie');b.geturl()
	try:b=urllib2.urlopen(url,data,timeout)
	except:b=None
	return b

def xcheck(item,hd={'User-Agent':'Mozilla/5.0'},data=None,timeout=30):
	def check(url):
		req=urllib2.Request(url,data,hd)
		try:b=urllib2.urlopen(req,timeout=timeout);link=b.geturl();b.close()
		except:link=''
		return link
	link=''
	if type(item) in (str,unicode):link=check(item)
	elif type(item)==list:
		try:
			for href,title in item:
				link=check(href)
				if link:break
		except:mess('Link checked fail !','xshare')
	return link
	
def get_input(title=u"", default=u""):
	result = ''
	keyboard = xbmc.Keyboard(default, title)
	keyboard.doModal()
	if keyboard.isConfirmed():result = keyboard.getText().strip()
	else:result = ''
	return result

def xsearch(pattern,string,group=1,flags=0,result=''):
	try:s=urllib2.re.search(pattern,string,flags).group(group)
	except:s=result
	return s

def fmn(n):
	try:s=format(int(n), "8,d").replace(',','.').strip()
	except:s=str(n)
	return s

def no_accent(s):
	s=re.sub(u'Đ','D',s2u(s));s=re.sub(u'đ','d',s)
	return unicodedata.normalize('NFKD', unicode(s)).encode('ASCII', 'ignore')
	
def vnu(s):
	dic={'&Aacute;':'Á','&aacute;':'á','&Agrave;':'À','&agrave;':'à','&Acirc;':'Â','&acirc;':'â','&Atilde;':'Ã','&atilde;':'ã','&Egrave;':'È','&egrave;':'è','&Eacute;':'É','&eacute;':'é','&ecirc;':'ê','&Ecirc;':'Ê','&Ograve;':'Ò','&ograve;':'ò','&Oacute;':'Ó','&oacute;':'ó','&Ocirc;':'Ô','&ocirc;':'ô','&otilde;':'õ','&Uacute;':'Ú','&uacute;':'ú','&Ugrave;':'Ù','&ugrave;':'ù','&Igrave;':'Ì','&igrave;':'ì','&Iacute;':'Í','&iacute;':'í','&Yacute;':'Ý','&yacute;':'ý','&nbsp;':' ','&#8211;':'-','&#8220;':'"','&#8221;':'"','&#8217;':"'",'&#215;':'x','&amp;':'&','&#038;':"&",'&#039;':"'",'&#39;':"'",'quot;':'"','&quot;':'"','<strong>':'','</strong>':''}
	for i in dic:s=s.replace(i,dic.get(i))
	return ' '.join(re.sub('&.+;',xsearch('&(\w).+;',i),i) for i in s.split())
	
def s2u(s):return s.decode('utf-8') if isinstance(s,str) else s
def u2s(s):return s.encode('utf-8') if isinstance(s,unicode) else s
def xhref(s,p=''):return xsearch('href="(.+?)"',s,result=xsearch(p,s))
def xtitle(s,p=''):return ' '.join(xsearch('title="(.+?)"',s,result=xsearch(p,s)).split())
def ximg(s,p=''):return xsearch('src="(.+?)"',s,result=xsearch(p,s))

def s2s(s):#string to seconds; module youtube.com
	def n(i):
		try:j=int(i)
		except:j=0
		return j
	s=s.split(':')
	if len(s)>2:i=n(s[0])*3600+n(s[1])*60+n(s[2])
	elif len(s)>1:i=n(s[0])*60+n(s[1])
	else:i=n(s[0])
	return i


def leechInfo(link):
	href='http://vnz-leech.com/checker/check.php?links=%s'
	headers={'Referer':'http://vnz-leech.com/checker/','User-Agent':'Mozilla/5.0'}
	b=xread(href%''.join(link.split()),headers)
	try:j=json.loads(b.replace('(','').replace(')',''))
	except:j={}
	def geti(j,i):return j.get(i,'').encode('utf-8')
	result='',''
	if j.get('status','')=='good_link':
		title='%s (%s)'%(geti(j,'filename'),geti(j,'filesize'))
		href=geti(j,'link')
		if title and href:result=title,href
	return result

def siteInfo(url):
	if '4share.vn/f/' in url.lower():
		url='http://4share.vn/f/%s/'%xsearch('/f/(\w+)',url)
		title,url=leechInfo(url)
	elif '4share.vn/d/' in url.lower():
		url='http://4share.vn/d/%s/'%xsearch('/d/(\w+)',url)
		b=xread(url)
		if '[Empty Folder]' in b:title=''
		else:title=xsearch("<title>(.+?)</title>",b).replace('4Share.vn - ','')
	elif 'fshare.vn' in url.lower():
		id=siteName(url).upper();link='https://www.fshare.vn/%s/'+id
		url=link%('file' if '/file/' in url.lower() else 'folder')
		b=xread(url)#,{'User-Agent':'Mozilla/5.0','x-requested-with':'XMLHttpRequest'})
		if b and '/file/' in url:
			s=xsearch('(<div class="file-info".+?data-owner)',b,1,re.S)
			m=xsearch('(<i class="fa fa-file.+?/div>)',s,1,re.S)
			title=' '.join(re.sub('<[^>]+?>','',m).split())
			if title:
				size=xsearch('(<i class="fa fa-hdd.+?/div>)',s,1,re.S)
				title=title+' '+re.sub('<[^>]+?>| ','',size)
			elif not xsearch('(<title>Lỗi 404</title>)',b):title,url=leechInfo(url)
		elif b:
			p='(<span class="glyphicon glyphicon-info.+?/div>)'
			size=re.sub('<[^>]+?>|Số lượng|:','',xsearch(p,b,1,re.S)).strip()
			if size and size>'0':
				title=xsearch('(<title>.+?</title>)',b)
				title='%s %s file(s)'%(' '.join(re.sub('<[^>]+?>|Fshare|-','',title).split()),size)
			else:title=''
		else:title,url=leechInfo(url)
	if not title:url=''
	return title,url

##########################
def joinpath(p1,p2):
	try:p=os.path.join(p1,p2)
	except:p=os.path.join(p1,s2u(p2))
	return p
	
def json_rw(file,dicts={},key=''):
	if dicts:makerequest(joinpath(datapath,file),json.dumps(dicts),'w')
	else:
		try:dicts=json.loads(makerequest(joinpath(datapath,file)))
		except:dicts={}
		if key:dicts=dicts.get(key,())
	return dicts

def sets(lists):
	temp=list()
	for s in lists:
		if s not in temp:temp.append(s)
	return temp

def folders(folder,result=list()):#get files fullpath from folder and subfolders
	for f in os.listdir(folder):
		f=joinpath(folder,f)
		if os.path.isdir(f):folders(f,result)
		else:result.append(f)
	return result

def delete_files(folder,mark=''):
	temp='ok'
	for file in os.listdir(folder):
		if os.path.isfile(joinpath(folder,file)) and (not mark or mark in file):
			try:os.remove(joinpath(folder,file))
			except:temp='';pass
	return temp

def delete_folder(folder):
	for file in os.listdir(folder):
		try:
			files=joinpath(folder,file)
			if os.path.isdir(files):delete_folder(files);os.rmdir(files)
			#for f in os.listdir(files):
			#	os.remove(joinpath(files,f))
			else:os.remove(files)
		except:pass

def rename_file(sf,df,kq='ok'):
	try:
		if os.path.isfile(df):os.remove(df)
		os.rename(sf,df)
	except:kq='';pass
	return kq

def xshare_download(direct_link):
	subsfolder=joinpath(addonDataPath,'subs')

	response=xfetch(direct_link)
	if not response:return 'fail'
	detail=response.headers
	size=int(detail.get('content-length',0))
	filename=detail.get('content-disposition','').split('=')
	if len(filename)>1:filename=filename[1].replace('"','').replace("'","")
	else:filename=os.path.basename(direct_link)
	ext=os.path.splitext(filename)[1][1:].lower()
		
	temp_path=joinpath(addonDataPath,'temp');mediafile=False
	if not os.path.exists(temp_path):os.mkdir(temp_path)
	else:delete_folder(temp_path)
	tempfile=joinpath(temp_path,'tempfile.%s'%ext)
	
	if size<1024**2:#sub file
		delete_folder(subsfolder)
		content=makerequest(tempfile,response.body,"wb")
	else:content=''
	if not content:return 'no'
	
	sub_ext = [".srt", ".sub", ".txt", ".smi", ".ssa", ".ass"];sub_list=[];p=',|"|\''	
	if content[0] in 'R-P':
		xbmc.sleep(1000);xbmc.executebuiltin('XBMC.Extract("%s")'%tempfile,True)		
		for filefullpath in folders(temp_path):
			file=os.path.basename(filefullpath)
			if os.path.isfile(filefullpath) and os.path.splitext(filefullpath)[1] in sub_ext:
				if re.search('english|eng\.|\.eng',filename.lower()) and rename_file(filefullpath,joinpath(subsfolder,'Eng.%s'%re.sub(p,'',file))):
					mess(u'Đã download sub vào Subsfolder','Subs Downloader') 
				elif re.search('vietnam|vie\.|\.vie',filename.lower()) and rename_file(filefullpath,joinpath(subsfolder,'Vie.%s'%re.sub(p,'',file))):
					mess(u'Đã download sub vào Subsfolder','Subs Downloader') 
				elif rename_file(filefullpath,joinpath(subsfolder,re.sub(p,'',file))):
					mess(u'Đã download sub vào Subsfolder','Subs Downloader')
	elif rename_file(tempfile,joinpath(subsfolder,'Vie.%s'%filename)):
		mess(u'Đã download sub vào Subsfolder','Subs Downloader')					
	return 'no'
	
def fshare_download(direct_link):
	myfolder=s2u(myaddon.getSetting('thumuccucbo'))
	if len(myfolder) == 0 and False:		
		notify('Cài đặt đường dẫn lưu trữ trong mục [COLOR red][B]Cấu hình[/B][/COLOR].')
		xbmcaddon.Addon(id='plugin.video.cantobumedia').openSettings('thumuccucbo')
	
	if len(myfolder) > 0 or True:
		progress=xbmcgui.DialogProgress()
		progress.create("[COLOR orangered]Xshare Download File[/COLOR]","Initializing Downloader...")
		try:
			req=urllib2.urlopen(direct_link)
			info=req.info().dict
			blocksize=1024*1024
			size=0
			size_total=int(info.get('content-length','1'))
			size_s='Dung lượng: '+fmn(size_total)+' Bytes. Xshare downloading ...'
			filename=info.get('content-disposition').split('=')[1].replace('"','')
			file_downloaded=os.path.join(myfolder,filename)
			string="Downloaded thành công"
			with open(file_downloaded, 'wb') as f:
				while True:
					chunk = req.read(blocksize)
					if not chunk:break
					elif xbmc.abortRequested or progress.iscanceled():
						string="Downloaded bị dừng bắt buộc  ..."
						break
					else:
						f.write(chunk)
						size+=len(chunk)
						i=size*100/size_total
						progress.update(i,size_s,'File Name: '+filename,' ')
		except:string="Downloaded đã thất bại  ..."
		progress.close()
		dialog=xbmcgui.Dialog()
		req='[COLOR red]Xshare[/COLOR] [COLOR green]XBMC[/COLOR] [COLOR blue]HDVideo[/COLOR]'
		dialog.ok(req,string)	